; Auto-generated. Do not edit!


(cl:in-package uvdar_gazebo_plugin-msg)


;//! \htmlinclude LedMessage.msg.html

(cl:defclass <LedMessage> (roslisp-msg-protocol:ros-message)
  ((link_name
    :reader link_name
    :initarg :link_name
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (data_frame
    :reader data_frame
    :initarg :data_frame
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil)))
)

(cl:defclass LedMessage (<LedMessage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LedMessage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LedMessage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_gazebo_plugin-msg:<LedMessage> is deprecated: use uvdar_gazebo_plugin-msg:LedMessage instead.")))

(cl:ensure-generic-function 'link_name-val :lambda-list '(m))
(cl:defmethod link_name-val ((m <LedMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:link_name-val is deprecated.  Use uvdar_gazebo_plugin-msg:link_name instead.")
  (link_name m))

(cl:ensure-generic-function 'data_frame-val :lambda-list '(m))
(cl:defmethod data_frame-val ((m <LedMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:data_frame-val is deprecated.  Use uvdar_gazebo_plugin-msg:data_frame instead.")
  (data_frame m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LedMessage>) ostream)
  "Serializes a message object of type '<LedMessage>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'link_name) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'data_frame))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LedMessage>) istream)
  "Deserializes a message object of type '<LedMessage>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'link_name) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data_frame) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data_frame)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LedMessage>)))
  "Returns string type for a message object of type '<LedMessage>"
  "uvdar_gazebo_plugin/LedMessage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LedMessage)))
  "Returns string type for a message object of type 'LedMessage"
  "uvdar_gazebo_plugin/LedMessage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LedMessage>)))
  "Returns md5sum for a message object of type '<LedMessage>"
  "042e3abb244246d18581c1cc4a592ef9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LedMessage)))
  "Returns md5sum for a message object of type 'LedMessage"
  "042e3abb244246d18581c1cc4a592ef9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LedMessage>)))
  "Returns full string definition for message of type '<LedMessage>"
  (cl:format cl:nil "std_msgs/String link_name~%bool[] data_frame~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LedMessage)))
  "Returns full string definition for message of type 'LedMessage"
  (cl:format cl:nil "std_msgs/String link_name~%bool[] data_frame~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LedMessage>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'link_name))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data_frame) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LedMessage>))
  "Converts a ROS message object to a list"
  (cl:list 'LedMessage
    (cl:cons ':link_name (link_name msg))
    (cl:cons ':data_frame (data_frame msg))
))
