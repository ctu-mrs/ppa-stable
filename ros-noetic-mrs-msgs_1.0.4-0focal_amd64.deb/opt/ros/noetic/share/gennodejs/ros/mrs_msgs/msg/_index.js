
"use strict";

let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FuturePoint = require('./FuturePoint.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let BigDofecStatus = require('./BigDofecStatus.js');
let OusterInfo = require('./OusterInfo.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let BoolStamped = require('./BoolStamped.js');
let PathReference = require('./PathReference.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let TrackerCommand = require('./TrackerCommand.js');
let VelocityReference = require('./VelocityReference.js');
let BumperStatus = require('./BumperStatus.js');
let EulerAngles = require('./EulerAngles.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let ControlError = require('./ControlError.js');
let AloamgarmDebug = require('./AloamgarmDebug.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let ReferenceList = require('./ReferenceList.js');
let Reference = require('./Reference.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let UavState = require('./UavState.js');
let EstimatorInput = require('./EstimatorInput.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let ControllerStatus = require('./ControllerStatus.js');
let TrackerStatus = require('./TrackerStatus.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let UavStatus = require('./UavStatus.js');
let UavStatusShort = require('./UavStatusShort.js');
let CustomTopic = require('./CustomTopic.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let Se3Gains = require('./Se3Gains.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let Path = require('./Path.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let MavrosState = require('./MavrosState.js');
let MavrosDiagnostics = require('./MavrosDiagnostics.js');
let GpsDiagnostics = require('./GpsDiagnostics.js');
let HeartbeatDiagnostics = require('./HeartbeatDiagnostics.js');
let BatteryDiagnostics = require('./BatteryDiagnostics.js');
let SystemDiagnostics = require('./SystemDiagnostics.js');
let Gpvtg = require('./Gpvtg.js');
let TersusMessageHeader = require('./TersusMessageHeader.js');
let Time = require('./Time.js');
let GpsData = require('./GpsData.js');
let Gpgga = require('./Gpgga.js');
let Gpgsv = require('./Gpgsv.js');
let Range = require('./Range.js');
let RtkFixType = require('./RtkFixType.js');
let RangeInformation = require('./RangeInformation.js');
let Bestpos = require('./Bestpos.js');
let Gpgst = require('./Gpgst.js');
let GPSFix = require('./GPSFix.js');
let Trackstat = require('./Trackstat.js');
let Gpgsa = require('./Gpgsa.js');
let RtkGps = require('./RtkGps.js');
let GpsStatus = require('./GpsStatus.js');
let TrackstatChannel = require('./TrackstatChannel.js');
let Satellite = require('./Satellite.js');
let Gprmc = require('./Gprmc.js');
let Bestvel = require('./Bestvel.js');
let BacaProtocol = require('./BacaProtocol.js');
let SerialRaw = require('./SerialRaw.js');
let ParachuteDiagnostics = require('./ParachuteDiagnostics.js');
let GripperDiagnostics = require('./GripperDiagnostics.js');
let TarotGimbalState = require('./TarotGimbalState.js');
let GimbalPRY = require('./GimbalPRY.js');
let GripperDiagnostics = require('./GripperDiagnostics.js');
let ParachuteDiagnostics = require('./ParachuteDiagnostics.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let Histogram = require('./Histogram.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let ImagePointsWithFloatStamped = require('./ImagePointsWithFloatStamped.js');
let Int32MultiArrayStamped = require('./Int32MultiArrayStamped.js');
let Point2DWithFloat = require('./Point2DWithFloat.js');
let SxdDiagnostics = require('./SxdDiagnostics.js');
let SxdMeasurement = require('./SxdMeasurement.js');
let SxdHistogram = require('./SxdHistogram.js');
let NimbroTest = require('./NimbroTest.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let Sphere = require('./Sphere.js');
let Track = require('./Track.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let TrackStamped = require('./TrackStamped.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let Float64Stamped = require('./Float64Stamped.js');
let Float64 = require('./Float64.js');
let ImageLabeled = require('./ImageLabeled.js');
let StringStamped = require('./StringStamped.js');
let SpawnerDiagnostics = require('./SpawnerDiagnostics.js');
let PathfinderDiagnostics = require('./PathfinderDiagnostics.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let PclToolsDiagnostics = require('./PclToolsDiagnostics.js');
let Llcp = require('./Llcp.js');
let RadarData = require('./RadarData.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');

module.exports = {
  MpcPredictionFullState: MpcPredictionFullState,
  FuturePoint: FuturePoint,
  FutureTrajectory: FutureTrajectory,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  LandoffDiagnostics: LandoffDiagnostics,
  BigDofecStatus: BigDofecStatus,
  OusterInfo: OusterInfo,
  EstimatorCorrection: EstimatorCorrection,
  ControllerDiagnostics: ControllerDiagnostics,
  BoolStamped: BoolStamped,
  PathReference: PathReference,
  GainManagerDiagnostics: GainManagerDiagnostics,
  EstimationDiagnostics: EstimationDiagnostics,
  DynamicsConstraints: DynamicsConstraints,
  TrajectoryReference: TrajectoryReference,
  TrackerCommand: TrackerCommand,
  VelocityReference: VelocityReference,
  BumperStatus: BumperStatus,
  EulerAngles: EulerAngles,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  ControlError: ControlError,
  AloamgarmDebug: AloamgarmDebug,
  UavManagerDiagnostics: UavManagerDiagnostics,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  VelocityReferenceStamped: VelocityReferenceStamped,
  ReferenceList: ReferenceList,
  Reference: Reference,
  ReferenceStamped: ReferenceStamped,
  UavState: UavState,
  EstimatorInput: EstimatorInput,
  EstimatorOutput: EstimatorOutput,
  ControllerStatus: ControllerStatus,
  TrackerStatus: TrackerStatus,
  EstimatorDiagnostics: EstimatorDiagnostics,
  UavStatus: UavStatus,
  UavStatusShort: UavStatusShort,
  CustomTopic: CustomTopic,
  NodeCpuLoad: NodeCpuLoad,
  Se3Gains: Se3Gains,
  ReferenceWithVelocity: ReferenceWithVelocity,
  Path: Path,
  PathWithVelocity: PathWithVelocity,
  MavrosState: MavrosState,
  MavrosDiagnostics: MavrosDiagnostics,
  GpsDiagnostics: GpsDiagnostics,
  HeartbeatDiagnostics: HeartbeatDiagnostics,
  BatteryDiagnostics: BatteryDiagnostics,
  SystemDiagnostics: SystemDiagnostics,
  Gpvtg: Gpvtg,
  TersusMessageHeader: TersusMessageHeader,
  Time: Time,
  GpsData: GpsData,
  Gpgga: Gpgga,
  Gpgsv: Gpgsv,
  Range: Range,
  RtkFixType: RtkFixType,
  RangeInformation: RangeInformation,
  Bestpos: Bestpos,
  Gpgst: Gpgst,
  GPSFix: GPSFix,
  Trackstat: Trackstat,
  Gpgsa: Gpgsa,
  RtkGps: RtkGps,
  GpsStatus: GpsStatus,
  TrackstatChannel: TrackstatChannel,
  Satellite: Satellite,
  Gprmc: Gprmc,
  Bestvel: Bestvel,
  BacaProtocol: BacaProtocol,
  SerialRaw: SerialRaw,
  ParachuteDiagnostics: ParachuteDiagnostics,
  GripperDiagnostics: GripperDiagnostics,
  TarotGimbalState: TarotGimbalState,
  GimbalPRY: GimbalPRY,
  GripperDiagnostics: GripperDiagnostics,
  ParachuteDiagnostics: ParachuteDiagnostics,
  ProfilerUpdate: ProfilerUpdate,
  Histogram: Histogram,
  ObstacleSectors: ObstacleSectors,
  SpeedTrackerCommand: SpeedTrackerCommand,
  ImagePointsWithFloatStamped: ImagePointsWithFloatStamped,
  Int32MultiArrayStamped: Int32MultiArrayStamped,
  Point2DWithFloat: Point2DWithFloat,
  SxdDiagnostics: SxdDiagnostics,
  SxdMeasurement: SxdMeasurement,
  SxdHistogram: SxdHistogram,
  NimbroTest: NimbroTest,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  TrackArrayStamped: TrackArrayStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  Sphere: Sphere,
  Track: Track,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  TrackStamped: TrackStamped,
  ImageLabeledArray: ImageLabeledArray,
  Float64Stamped: Float64Stamped,
  Float64: Float64,
  ImageLabeled: ImageLabeled,
  StringStamped: StringStamped,
  SpawnerDiagnostics: SpawnerDiagnostics,
  PathfinderDiagnostics: PathfinderDiagnostics,
  UInt16Stamped: UInt16Stamped,
  PclToolsDiagnostics: PclToolsDiagnostics,
  Llcp: Llcp,
  RadarData: RadarData,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiStatus: HwApiStatus,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiCapabilities: HwApiCapabilities,
  HwApiRcChannels: HwApiRcChannels,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiAltitude: HwApiAltitude,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
};
