// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class EstimatorInput {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.control_acceleration = null;
      this.control_hdg_rate = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('control_acceleration')) {
        this.control_acceleration = initObj.control_acceleration
      }
      else {
        this.control_acceleration = new geometry_msgs.msg.Vector3();
      }
      if (initObj.hasOwnProperty('control_hdg_rate')) {
        this.control_hdg_rate = initObj.control_hdg_rate
      }
      else {
        this.control_hdg_rate = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EstimatorInput
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [control_acceleration]
    bufferOffset = geometry_msgs.msg.Vector3.serialize(obj.control_acceleration, buffer, bufferOffset);
    // Serialize message field [control_hdg_rate]
    bufferOffset = _serializer.float64(obj.control_hdg_rate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EstimatorInput
    let len;
    let data = new EstimatorInput(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [control_acceleration]
    data.control_acceleration = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset);
    // Deserialize message field [control_hdg_rate]
    data.control_hdg_rate = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/EstimatorInput';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8756fee487290057802d05d69b4226ca';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    
    # unbiased acceleration caused by controller's action
    geometry_msgs/Vector3 control_acceleration
    
    # heading rate caused by the controller's action
    float64 control_hdg_rate
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EstimatorInput(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.control_acceleration !== undefined) {
      resolved.control_acceleration = geometry_msgs.msg.Vector3.Resolve(msg.control_acceleration)
    }
    else {
      resolved.control_acceleration = new geometry_msgs.msg.Vector3()
    }

    if (msg.control_hdg_rate !== undefined) {
      resolved.control_hdg_rate = msg.control_hdg_rate;
    }
    else {
      resolved.control_hdg_rate = 0.0
    }

    return resolved;
    }
};

module.exports = EstimatorInput;
