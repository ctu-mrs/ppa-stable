
"use strict";

let PolynomialSegment = require('./PolynomialSegment.js');
let PolynomialSegment4D = require('./PolynomialSegment4D.js');
let PolygonWithHolesStamped = require('./PolygonWithHolesStamped.js');
let Point2D = require('./Point2D.js');
let PolynomialTrajectory = require('./PolynomialTrajectory.js');
let PolygonWithHoles = require('./PolygonWithHoles.js');
let PointCloudWithPose = require('./PointCloudWithPose.js');
let Polygon2D = require('./Polygon2D.js');
let PolynomialTrajectory4D = require('./PolynomialTrajectory4D.js');

module.exports = {
  PolynomialSegment: PolynomialSegment,
  PolynomialSegment4D: PolynomialSegment4D,
  PolygonWithHolesStamped: PolygonWithHolesStamped,
  Point2D: Point2D,
  PolynomialTrajectory: PolynomialTrajectory,
  PolygonWithHoles: PolygonWithHoles,
  PointCloudWithPose: PointCloudWithPose,
  Polygon2D: Polygon2D,
  PolynomialTrajectory4D: PolynomialTrajectory4D,
};
