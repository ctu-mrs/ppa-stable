// Auto-generated. Do not edit!

// (in-package uvdar_gazebo_plugin.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class LedMessage {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.link_name = null;
      this.data_frame = null;
    }
    else {
      if (initObj.hasOwnProperty('link_name')) {
        this.link_name = initObj.link_name
      }
      else {
        this.link_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('data_frame')) {
        this.data_frame = initObj.data_frame
      }
      else {
        this.data_frame = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LedMessage
    // Serialize message field [link_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.link_name, buffer, bufferOffset);
    // Serialize message field [data_frame]
    bufferOffset = _arraySerializer.bool(obj.data_frame, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LedMessage
    let len;
    let data = new LedMessage(null);
    // Deserialize message field [link_name]
    data.link_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [data_frame]
    data.data_frame = _arrayDeserializer.bool(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.link_name);
    length += object.data_frame.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_gazebo_plugin/LedMessage';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '042e3abb244246d18581c1cc4a592ef9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String link_name
    bool[] data_frame
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LedMessage(null);
    if (msg.link_name !== undefined) {
      resolved.link_name = std_msgs.msg.String.Resolve(msg.link_name)
    }
    else {
      resolved.link_name = new std_msgs.msg.String()
    }

    if (msg.data_frame !== undefined) {
      resolved.data_frame = msg.data_frame;
    }
    else {
      resolved.data_frame = []
    }

    return resolved;
    }
};

module.exports = LedMessage;
