(cl:in-package nimbro_service_transport-msg)
(cl:export '(HOST-VAL
          HOST
          REMOTE-VAL
          REMOTE
          REMOTE_PORT-VAL
          REMOTE_PORT
          CALL_ID-VAL
          CALL_ID
          SERVICE-VAL
          SERVICE
          STATUS-VAL
          STATUS
))