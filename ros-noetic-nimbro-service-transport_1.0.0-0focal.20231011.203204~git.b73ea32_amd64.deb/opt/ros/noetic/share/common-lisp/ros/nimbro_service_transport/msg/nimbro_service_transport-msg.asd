
(cl:in-package :asdf)

(defsystem "nimbro_service_transport-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "ServiceStatus" :depends-on ("_package_ServiceStatus"))
    (:file "_package_ServiceStatus" :depends-on ("_package"))
  ))