(cl:defpackage nimbro_service_transport-srv
  (:use )
  (:export
   "ADDTWOINTS"
   "<ADDTWOINTS-REQUEST>"
   "ADDTWOINTS-REQUEST"
   "<ADDTWOINTS-RESPONSE>"
   "ADDTWOINTS-RESPONSE"
  ))

