; Auto-generated. Do not edit!


(cl:in-package uvdar_gazebo_plugin-msg)


;//! \htmlinclude CamInfo.msg.html

(cl:defclass <CamInfo> (roslisp-msg-protocol:ros-message)
  ((scoped_name
    :reader scoped_name
    :initarg :scoped_name
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (parent_name
    :reader parent_name
    :initarg :parent_name
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (sensor_id
    :reader sensor_id
    :initarg :sensor_id
    :type std_msgs-msg:UInt64
    :initform (cl:make-instance 'std_msgs-msg:UInt64))
   (publish_topic
    :reader publish_topic
    :initarg :publish_topic
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (f
    :reader f
    :initarg :f
    :type std_msgs-msg:Float64
    :initform (cl:make-instance 'std_msgs-msg:Float64))
   (occlusions
    :reader occlusions
    :initarg :occlusions
    :type std_msgs-msg:Bool
    :initform (cl:make-instance 'std_msgs-msg:Bool)))
)

(cl:defclass CamInfo (<CamInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CamInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CamInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_gazebo_plugin-msg:<CamInfo> is deprecated: use uvdar_gazebo_plugin-msg:CamInfo instead.")))

(cl:ensure-generic-function 'scoped_name-val :lambda-list '(m))
(cl:defmethod scoped_name-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:scoped_name-val is deprecated.  Use uvdar_gazebo_plugin-msg:scoped_name instead.")
  (scoped_name m))

(cl:ensure-generic-function 'parent_name-val :lambda-list '(m))
(cl:defmethod parent_name-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:parent_name-val is deprecated.  Use uvdar_gazebo_plugin-msg:parent_name instead.")
  (parent_name m))

(cl:ensure-generic-function 'sensor_id-val :lambda-list '(m))
(cl:defmethod sensor_id-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:sensor_id-val is deprecated.  Use uvdar_gazebo_plugin-msg:sensor_id instead.")
  (sensor_id m))

(cl:ensure-generic-function 'publish_topic-val :lambda-list '(m))
(cl:defmethod publish_topic-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:publish_topic-val is deprecated.  Use uvdar_gazebo_plugin-msg:publish_topic instead.")
  (publish_topic m))

(cl:ensure-generic-function 'f-val :lambda-list '(m))
(cl:defmethod f-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:f-val is deprecated.  Use uvdar_gazebo_plugin-msg:f instead.")
  (f m))

(cl:ensure-generic-function 'occlusions-val :lambda-list '(m))
(cl:defmethod occlusions-val ((m <CamInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:occlusions-val is deprecated.  Use uvdar_gazebo_plugin-msg:occlusions instead.")
  (occlusions m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CamInfo>) ostream)
  "Serializes a message object of type '<CamInfo>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'scoped_name) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'parent_name) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'sensor_id) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'publish_topic) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'f) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'occlusions) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CamInfo>) istream)
  "Deserializes a message object of type '<CamInfo>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'scoped_name) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'parent_name) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'sensor_id) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'publish_topic) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'f) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'occlusions) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CamInfo>)))
  "Returns string type for a message object of type '<CamInfo>"
  "uvdar_gazebo_plugin/CamInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CamInfo)))
  "Returns string type for a message object of type 'CamInfo"
  "uvdar_gazebo_plugin/CamInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CamInfo>)))
  "Returns md5sum for a message object of type '<CamInfo>"
  "4b6c64f789f4ff6271665f4075e2ece7")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CamInfo)))
  "Returns md5sum for a message object of type 'CamInfo"
  "4b6c64f789f4ff6271665f4075e2ece7")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CamInfo>)))
  "Returns full string definition for message of type '<CamInfo>"
  (cl:format cl:nil "std_msgs/String scoped_name~%std_msgs/String parent_name~%std_msgs/UInt64 sensor_id~%std_msgs/String publish_topic~%std_msgs/Float64 f~%std_msgs/Bool occlusions~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/UInt64~%uint64 data~%================================================================================~%MSG: std_msgs/Float64~%float64 data~%================================================================================~%MSG: std_msgs/Bool~%bool data~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CamInfo)))
  "Returns full string definition for message of type 'CamInfo"
  (cl:format cl:nil "std_msgs/String scoped_name~%std_msgs/String parent_name~%std_msgs/UInt64 sensor_id~%std_msgs/String publish_topic~%std_msgs/Float64 f~%std_msgs/Bool occlusions~%~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/UInt64~%uint64 data~%================================================================================~%MSG: std_msgs/Float64~%float64 data~%================================================================================~%MSG: std_msgs/Bool~%bool data~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CamInfo>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'scoped_name))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'parent_name))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'sensor_id))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'publish_topic))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'f))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'occlusions))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CamInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'CamInfo
    (cl:cons ':scoped_name (scoped_name msg))
    (cl:cons ':parent_name (parent_name msg))
    (cl:cons ':sensor_id (sensor_id msg))
    (cl:cons ':publish_topic (publish_topic msg))
    (cl:cons ':f (f msg))
    (cl:cons ':occlusions (occlusions msg))
))
