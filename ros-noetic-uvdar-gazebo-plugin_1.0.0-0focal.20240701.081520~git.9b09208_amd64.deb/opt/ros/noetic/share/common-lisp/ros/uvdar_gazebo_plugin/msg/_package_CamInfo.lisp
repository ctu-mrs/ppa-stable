(cl:in-package uvdar_gazebo_plugin-msg)
(cl:export '(SCOPED_NAME-VAL
          SCOPED_NAME
          PARENT_NAME-VAL
          PARENT_NAME
          SENSOR_ID-VAL
          SENSOR_ID
          PUBLISH_TOPIC-VAL
          PUBLISH_TOPIC
          F-VAL
          F
          OCCLUSIONS-VAL
          OCCLUSIONS
))