set(uvdar_gazebo_plugin_MESSAGE_FILES "msg/LedInfo.msg;msg/CamInfo.msg;msg/LedMessage.msg")
set(uvdar_gazebo_plugin_SERVICE_FILES "")
