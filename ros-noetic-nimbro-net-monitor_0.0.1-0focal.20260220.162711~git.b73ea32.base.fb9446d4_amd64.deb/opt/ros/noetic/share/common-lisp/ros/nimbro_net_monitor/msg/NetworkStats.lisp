; Auto-generated. Do not edit!


(cl:in-package nimbro_net_monitor-msg)


;//! \htmlinclude NetworkStats.msg.html

(cl:defclass <NetworkStats> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (host
    :reader host
    :initarg :host
    :type cl:string
    :initform "")
   (interfaces
    :reader interfaces
    :initarg :interfaces
    :type (cl:vector nimbro_net_monitor-msg:InterfaceStats)
   :initform (cl:make-array 0 :element-type 'nimbro_net_monitor-msg:InterfaceStats :initial-element (cl:make-instance 'nimbro_net_monitor-msg:InterfaceStats))))
)

(cl:defclass NetworkStats (<NetworkStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <NetworkStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'NetworkStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_net_monitor-msg:<NetworkStats> is deprecated: use nimbro_net_monitor-msg:NetworkStats instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <NetworkStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:header-val is deprecated.  Use nimbro_net_monitor-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'host-val :lambda-list '(m))
(cl:defmethod host-val ((m <NetworkStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:host-val is deprecated.  Use nimbro_net_monitor-msg:host instead.")
  (host m))

(cl:ensure-generic-function 'interfaces-val :lambda-list '(m))
(cl:defmethod interfaces-val ((m <NetworkStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:interfaces-val is deprecated.  Use nimbro_net_monitor-msg:interfaces instead.")
  (interfaces m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <NetworkStats>) ostream)
  "Serializes a message object of type '<NetworkStats>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'host))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'host))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'interfaces))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'interfaces))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <NetworkStats>) istream)
  "Deserializes a message object of type '<NetworkStats>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'host) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'interfaces) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'interfaces)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_net_monitor-msg:InterfaceStats))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<NetworkStats>)))
  "Returns string type for a message object of type '<NetworkStats>"
  "nimbro_net_monitor/NetworkStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'NetworkStats)))
  "Returns string type for a message object of type 'NetworkStats"
  "nimbro_net_monitor/NetworkStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<NetworkStats>)))
  "Returns md5sum for a message object of type '<NetworkStats>"
  "532eb758d517f6f2e41f9a76040729f4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'NetworkStats)))
  "Returns md5sum for a message object of type 'NetworkStats"
  "532eb758d517f6f2e41f9a76040729f4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<NetworkStats>)))
  "Returns full string definition for message of type '<NetworkStats>"
  (cl:format cl:nil "~%Header header~%~%# Name of the machine the node is running on~%string host~%~%# Statistics for each network interface~%InterfaceStats[] interfaces~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: nimbro_net_monitor/InterfaceStats~%~%# Name of the network interface~%string interface_name~%~%# Max. available bandwidth (e.g. ethernet link speed)~%# This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.~%uint64 max_bits_per_second~%~%# Duplex?~%bool duplex~%~%# Total used TX Bandwidth in bit/s~%float64 tx_bandwidth~%~%# Total used RX Bandwidth in bit/s~%float64 rx_bandwidth~%~%PeerStats[] peers~%~%================================================================================~%MSG: nimbro_net_monitor/PeerStats~%# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'NetworkStats)))
  "Returns full string definition for message of type 'NetworkStats"
  (cl:format cl:nil "~%Header header~%~%# Name of the machine the node is running on~%string host~%~%# Statistics for each network interface~%InterfaceStats[] interfaces~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: nimbro_net_monitor/InterfaceStats~%~%# Name of the network interface~%string interface_name~%~%# Max. available bandwidth (e.g. ethernet link speed)~%# This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.~%uint64 max_bits_per_second~%~%# Duplex?~%bool duplex~%~%# Total used TX Bandwidth in bit/s~%float64 tx_bandwidth~%~%# Total used RX Bandwidth in bit/s~%float64 rx_bandwidth~%~%PeerStats[] peers~%~%================================================================================~%MSG: nimbro_net_monitor/PeerStats~%# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <NetworkStats>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'host))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'interfaces) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <NetworkStats>))
  "Converts a ROS message object to a list"
  (cl:list 'NetworkStats
    (cl:cons ':header (header msg))
    (cl:cons ':host (host msg))
    (cl:cons ':interfaces (interfaces msg))
))
