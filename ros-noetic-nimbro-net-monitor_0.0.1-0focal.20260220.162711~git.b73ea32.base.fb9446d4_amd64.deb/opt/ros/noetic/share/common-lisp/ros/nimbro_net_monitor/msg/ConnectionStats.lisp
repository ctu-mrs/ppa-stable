; Auto-generated. Do not edit!


(cl:in-package nimbro_net_monitor-msg)


;//! \htmlinclude ConnectionStats.msg.html

(cl:defclass <ConnectionStats> (roslisp-msg-protocol:ros-message)
  ((topic
    :reader topic
    :initarg :topic
    :type cl:string
    :initform "")
   (local_node
    :reader local_node
    :initarg :local_node
    :type cl:string
    :initform "")
   (destination
    :reader destination
    :initarg :destination
    :type cl:string
    :initform "")
   (direction
    :reader direction
    :initarg :direction
    :type cl:fixnum
    :initform 0)
   (transport
    :reader transport
    :initarg :transport
    :type cl:string
    :initform "")
   (bits_per_second
    :reader bits_per_second
    :initarg :bits_per_second
    :type cl:integer
    :initform 0))
)

(cl:defclass ConnectionStats (<ConnectionStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ConnectionStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ConnectionStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_net_monitor-msg:<ConnectionStats> is deprecated: use nimbro_net_monitor-msg:ConnectionStats instead.")))

(cl:ensure-generic-function 'topic-val :lambda-list '(m))
(cl:defmethod topic-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:topic-val is deprecated.  Use nimbro_net_monitor-msg:topic instead.")
  (topic m))

(cl:ensure-generic-function 'local_node-val :lambda-list '(m))
(cl:defmethod local_node-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:local_node-val is deprecated.  Use nimbro_net_monitor-msg:local_node instead.")
  (local_node m))

(cl:ensure-generic-function 'destination-val :lambda-list '(m))
(cl:defmethod destination-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:destination-val is deprecated.  Use nimbro_net_monitor-msg:destination instead.")
  (destination m))

(cl:ensure-generic-function 'direction-val :lambda-list '(m))
(cl:defmethod direction-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:direction-val is deprecated.  Use nimbro_net_monitor-msg:direction instead.")
  (direction m))

(cl:ensure-generic-function 'transport-val :lambda-list '(m))
(cl:defmethod transport-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:transport-val is deprecated.  Use nimbro_net_monitor-msg:transport instead.")
  (transport m))

(cl:ensure-generic-function 'bits_per_second-val :lambda-list '(m))
(cl:defmethod bits_per_second-val ((m <ConnectionStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:bits_per_second-val is deprecated.  Use nimbro_net_monitor-msg:bits_per_second instead.")
  (bits_per_second m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<ConnectionStats>)))
    "Constants for message type '<ConnectionStats>"
  '((:DIR_IN . 0)
    (:DIR_OUT . 1))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'ConnectionStats)))
    "Constants for message type 'ConnectionStats"
  '((:DIR_IN . 0)
    (:DIR_OUT . 1))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ConnectionStats>) ostream)
  "Serializes a message object of type '<ConnectionStats>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'topic))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'topic))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'local_node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'local_node))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'destination))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'destination))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'direction)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'transport))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'transport))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'bits_per_second)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ConnectionStats>) istream)
  "Deserializes a message object of type '<ConnectionStats>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'topic) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'topic) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'local_node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'local_node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'destination) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'destination) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'direction)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'transport) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'transport) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'bits_per_second)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ConnectionStats>)))
  "Returns string type for a message object of type '<ConnectionStats>"
  "nimbro_net_monitor/ConnectionStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ConnectionStats)))
  "Returns string type for a message object of type 'ConnectionStats"
  "nimbro_net_monitor/ConnectionStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ConnectionStats>)))
  "Returns md5sum for a message object of type '<ConnectionStats>"
  "b24299a1a38da64ecf65a30e5e6ffb39")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ConnectionStats)))
  "Returns md5sum for a message object of type 'ConnectionStats"
  "b24299a1a38da64ecf65a30e5e6ffb39")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ConnectionStats>)))
  "Returns full string definition for message of type '<ConnectionStats>"
  (cl:format cl:nil "~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ConnectionStats)))
  "Returns full string definition for message of type 'ConnectionStats"
  (cl:format cl:nil "~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ConnectionStats>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'topic))
     4 (cl:length (cl:slot-value msg 'local_node))
     4 (cl:length (cl:slot-value msg 'destination))
     1
     4 (cl:length (cl:slot-value msg 'transport))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ConnectionStats>))
  "Converts a ROS message object to a list"
  (cl:list 'ConnectionStats
    (cl:cons ':topic (topic msg))
    (cl:cons ':local_node (local_node msg))
    (cl:cons ':destination (destination msg))
    (cl:cons ':direction (direction msg))
    (cl:cons ':transport (transport msg))
    (cl:cons ':bits_per_second (bits_per_second msg))
))
