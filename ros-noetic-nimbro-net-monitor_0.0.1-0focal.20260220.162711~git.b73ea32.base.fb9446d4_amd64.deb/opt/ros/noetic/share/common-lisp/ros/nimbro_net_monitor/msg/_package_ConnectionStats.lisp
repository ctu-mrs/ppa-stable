(cl:in-package nimbro_net_monitor-msg)
(cl:export '(TOPIC-VAL
          TOPIC
          LOCAL_NODE-VAL
          LOCAL_NODE
          DESTINATION-VAL
          DESTINATION
          DIRECTION-VAL
          DIRECTION
          TRANSPORT-VAL
          TRANSPORT
          BITS_PER_SECOND-VAL
          BITS_PER_SECOND
))