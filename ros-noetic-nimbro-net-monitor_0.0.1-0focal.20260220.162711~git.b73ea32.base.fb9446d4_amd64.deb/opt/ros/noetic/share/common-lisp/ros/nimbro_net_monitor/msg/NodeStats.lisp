; Auto-generated. Do not edit!


(cl:in-package nimbro_net_monitor-msg)


;//! \htmlinclude NodeStats.msg.html

(cl:defclass <NodeStats> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (connections
    :reader connections
    :initarg :connections
    :type (cl:vector nimbro_net_monitor-msg:ConnectionStats)
   :initform (cl:make-array 0 :element-type 'nimbro_net_monitor-msg:ConnectionStats :initial-element (cl:make-instance 'nimbro_net_monitor-msg:ConnectionStats))))
)

(cl:defclass NodeStats (<NodeStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <NodeStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'NodeStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_net_monitor-msg:<NodeStats> is deprecated: use nimbro_net_monitor-msg:NodeStats instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <NodeStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:name-val is deprecated.  Use nimbro_net_monitor-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'connections-val :lambda-list '(m))
(cl:defmethod connections-val ((m <NodeStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:connections-val is deprecated.  Use nimbro_net_monitor-msg:connections instead.")
  (connections m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <NodeStats>) ostream)
  "Serializes a message object of type '<NodeStats>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'connections))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'connections))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <NodeStats>) istream)
  "Deserializes a message object of type '<NodeStats>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'connections) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'connections)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_net_monitor-msg:ConnectionStats))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<NodeStats>)))
  "Returns string type for a message object of type '<NodeStats>"
  "nimbro_net_monitor/NodeStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'NodeStats)))
  "Returns string type for a message object of type 'NodeStats"
  "nimbro_net_monitor/NodeStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<NodeStats>)))
  "Returns md5sum for a message object of type '<NodeStats>"
  "c1b56686774bc600364b7269d328c496")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'NodeStats)))
  "Returns md5sum for a message object of type 'NodeStats"
  "c1b56686774bc600364b7269d328c496")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<NodeStats>)))
  "Returns full string definition for message of type '<NodeStats>"
  (cl:format cl:nil "~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'NodeStats)))
  "Returns full string definition for message of type 'NodeStats"
  (cl:format cl:nil "~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <NodeStats>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'connections) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <NodeStats>))
  "Converts a ROS message object to a list"
  (cl:list 'NodeStats
    (cl:cons ':name (name msg))
    (cl:cons ':connections (connections msg))
))
