; Auto-generated. Do not edit!


(cl:in-package nimbro_net_monitor-msg)


;//! \htmlinclude PeerStats.msg.html

(cl:defclass <PeerStats> (roslisp-msg-protocol:ros-message)
  ((host
    :reader host
    :initarg :host
    :type cl:string
    :initform "")
   (nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector nimbro_net_monitor-msg:NodeStats)
   :initform (cl:make-array 0 :element-type 'nimbro_net_monitor-msg:NodeStats :initial-element (cl:make-instance 'nimbro_net_monitor-msg:NodeStats))))
)

(cl:defclass PeerStats (<PeerStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PeerStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PeerStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_net_monitor-msg:<PeerStats> is deprecated: use nimbro_net_monitor-msg:PeerStats instead.")))

(cl:ensure-generic-function 'host-val :lambda-list '(m))
(cl:defmethod host-val ((m <PeerStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:host-val is deprecated.  Use nimbro_net_monitor-msg:host instead.")
  (host m))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <PeerStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:nodes-val is deprecated.  Use nimbro_net_monitor-msg:nodes instead.")
  (nodes m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PeerStats>) ostream)
  "Serializes a message object of type '<PeerStats>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'host))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'host))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'nodes))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PeerStats>) istream)
  "Deserializes a message object of type '<PeerStats>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'host) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_net_monitor-msg:NodeStats))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PeerStats>)))
  "Returns string type for a message object of type '<PeerStats>"
  "nimbro_net_monitor/PeerStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PeerStats)))
  "Returns string type for a message object of type 'PeerStats"
  "nimbro_net_monitor/PeerStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PeerStats>)))
  "Returns md5sum for a message object of type '<PeerStats>"
  "64ae0985e3286e89c73486f400101243")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PeerStats)))
  "Returns md5sum for a message object of type 'PeerStats"
  "64ae0985e3286e89c73486f400101243")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PeerStats>)))
  "Returns full string definition for message of type '<PeerStats>"
  (cl:format cl:nil "# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PeerStats)))
  "Returns full string definition for message of type 'PeerStats"
  (cl:format cl:nil "# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PeerStats>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'host))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PeerStats>))
  "Converts a ROS message object to a list"
  (cl:list 'PeerStats
    (cl:cons ':host (host msg))
    (cl:cons ':nodes (nodes msg))
))
