; Auto-generated. Do not edit!


(cl:in-package nimbro_net_monitor-msg)


;//! \htmlinclude InterfaceStats.msg.html

(cl:defclass <InterfaceStats> (roslisp-msg-protocol:ros-message)
  ((interface_name
    :reader interface_name
    :initarg :interface_name
    :type cl:string
    :initform "")
   (max_bits_per_second
    :reader max_bits_per_second
    :initarg :max_bits_per_second
    :type cl:integer
    :initform 0)
   (duplex
    :reader duplex
    :initarg :duplex
    :type cl:boolean
    :initform cl:nil)
   (tx_bandwidth
    :reader tx_bandwidth
    :initarg :tx_bandwidth
    :type cl:float
    :initform 0.0)
   (rx_bandwidth
    :reader rx_bandwidth
    :initarg :rx_bandwidth
    :type cl:float
    :initform 0.0)
   (peers
    :reader peers
    :initarg :peers
    :type (cl:vector nimbro_net_monitor-msg:PeerStats)
   :initform (cl:make-array 0 :element-type 'nimbro_net_monitor-msg:PeerStats :initial-element (cl:make-instance 'nimbro_net_monitor-msg:PeerStats))))
)

(cl:defclass InterfaceStats (<InterfaceStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <InterfaceStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'InterfaceStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_net_monitor-msg:<InterfaceStats> is deprecated: use nimbro_net_monitor-msg:InterfaceStats instead.")))

(cl:ensure-generic-function 'interface_name-val :lambda-list '(m))
(cl:defmethod interface_name-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:interface_name-val is deprecated.  Use nimbro_net_monitor-msg:interface_name instead.")
  (interface_name m))

(cl:ensure-generic-function 'max_bits_per_second-val :lambda-list '(m))
(cl:defmethod max_bits_per_second-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:max_bits_per_second-val is deprecated.  Use nimbro_net_monitor-msg:max_bits_per_second instead.")
  (max_bits_per_second m))

(cl:ensure-generic-function 'duplex-val :lambda-list '(m))
(cl:defmethod duplex-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:duplex-val is deprecated.  Use nimbro_net_monitor-msg:duplex instead.")
  (duplex m))

(cl:ensure-generic-function 'tx_bandwidth-val :lambda-list '(m))
(cl:defmethod tx_bandwidth-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:tx_bandwidth-val is deprecated.  Use nimbro_net_monitor-msg:tx_bandwidth instead.")
  (tx_bandwidth m))

(cl:ensure-generic-function 'rx_bandwidth-val :lambda-list '(m))
(cl:defmethod rx_bandwidth-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:rx_bandwidth-val is deprecated.  Use nimbro_net_monitor-msg:rx_bandwidth instead.")
  (rx_bandwidth m))

(cl:ensure-generic-function 'peers-val :lambda-list '(m))
(cl:defmethod peers-val ((m <InterfaceStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_net_monitor-msg:peers-val is deprecated.  Use nimbro_net_monitor-msg:peers instead.")
  (peers m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <InterfaceStats>) ostream)
  "Serializes a message object of type '<InterfaceStats>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'interface_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'interface_name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'max_bits_per_second)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'duplex) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'tx_bandwidth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'rx_bandwidth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'peers))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'peers))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <InterfaceStats>) istream)
  "Deserializes a message object of type '<InterfaceStats>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'interface_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'interface_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'max_bits_per_second)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'duplex) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'tx_bandwidth) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rx_bandwidth) (roslisp-utils:decode-double-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'peers) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'peers)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_net_monitor-msg:PeerStats))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<InterfaceStats>)))
  "Returns string type for a message object of type '<InterfaceStats>"
  "nimbro_net_monitor/InterfaceStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'InterfaceStats)))
  "Returns string type for a message object of type 'InterfaceStats"
  "nimbro_net_monitor/InterfaceStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<InterfaceStats>)))
  "Returns md5sum for a message object of type '<InterfaceStats>"
  "efabe0a10684abb74a0a689474aea600")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'InterfaceStats)))
  "Returns md5sum for a message object of type 'InterfaceStats"
  "efabe0a10684abb74a0a689474aea600")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<InterfaceStats>)))
  "Returns full string definition for message of type '<InterfaceStats>"
  (cl:format cl:nil "~%# Name of the network interface~%string interface_name~%~%# Max. available bandwidth (e.g. ethernet link speed)~%# This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.~%uint64 max_bits_per_second~%~%# Duplex?~%bool duplex~%~%# Total used TX Bandwidth in bit/s~%float64 tx_bandwidth~%~%# Total used RX Bandwidth in bit/s~%float64 rx_bandwidth~%~%PeerStats[] peers~%~%================================================================================~%MSG: nimbro_net_monitor/PeerStats~%# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'InterfaceStats)))
  "Returns full string definition for message of type 'InterfaceStats"
  (cl:format cl:nil "~%# Name of the network interface~%string interface_name~%~%# Max. available bandwidth (e.g. ethernet link speed)~%# This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.~%uint64 max_bits_per_second~%~%# Duplex?~%bool duplex~%~%# Total used TX Bandwidth in bit/s~%float64 tx_bandwidth~%~%# Total used RX Bandwidth in bit/s~%float64 rx_bandwidth~%~%PeerStats[] peers~%~%================================================================================~%MSG: nimbro_net_monitor/PeerStats~%# Describes all traffic from/to this peer to/from the local machine~%~%string host~%~%NodeStats[] nodes~%~%================================================================================~%MSG: nimbro_net_monitor/NodeStats~%~%string name~%~%ConnectionStats[] connections~%~%================================================================================~%MSG: nimbro_net_monitor/ConnectionStats~%~%uint8 DIR_IN = 0~%uint8 DIR_OUT = 1~%~%# Topic name~%string topic~%~%# Local node~%string local_node~%~%# Peer node (the other end)~%# this is a node *name*~%string destination~%~%# See DIR_IN/DIR_OUT~%uint8 direction~%~%# Used transport (e.g. 'TCPROS')~%string transport~%~%# Current bandwidth~%uint64 bits_per_second~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <InterfaceStats>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'interface_name))
     8
     1
     8
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'peers) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <InterfaceStats>))
  "Converts a ROS message object to a list"
  (cl:list 'InterfaceStats
    (cl:cons ':interface_name (interface_name msg))
    (cl:cons ':max_bits_per_second (max_bits_per_second msg))
    (cl:cons ':duplex (duplex msg))
    (cl:cons ':tx_bandwidth (tx_bandwidth msg))
    (cl:cons ':rx_bandwidth (rx_bandwidth msg))
    (cl:cons ':peers (peers msg))
))
