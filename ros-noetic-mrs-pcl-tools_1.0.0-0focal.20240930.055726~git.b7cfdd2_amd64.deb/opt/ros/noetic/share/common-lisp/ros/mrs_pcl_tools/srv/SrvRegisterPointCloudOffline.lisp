; Auto-generated. Do not edit!


(cl:in-package mrs_pcl_tools-srv)


;//! \htmlinclude SrvRegisterPointCloudOffline-request.msg.html

(cl:defclass <SrvRegisterPointCloudOffline-request> (roslisp-msg-protocol:ros-message)
  ((apply_random_transform
    :reader apply_random_transform
    :initarg :apply_random_transform
    :type cl:boolean
    :initform cl:nil)
   (init_guess_use
    :reader init_guess_use
    :initarg :init_guess_use
    :type cl:boolean
    :initform cl:nil)
   (init_guess_translation
    :reader init_guess_translation
    :initarg :init_guess_translation
    :type geometry_msgs-msg:Point
    :initform (cl:make-instance 'geometry_msgs-msg:Point))
   (init_guess_yaw
    :reader init_guess_yaw
    :initarg :init_guess_yaw
    :type cl:float
    :initform 0.0))
)

(cl:defclass SrvRegisterPointCloudOffline-request (<SrvRegisterPointCloudOffline-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SrvRegisterPointCloudOffline-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SrvRegisterPointCloudOffline-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_pcl_tools-srv:<SrvRegisterPointCloudOffline-request> is deprecated: use mrs_pcl_tools-srv:SrvRegisterPointCloudOffline-request instead.")))

(cl:ensure-generic-function 'apply_random_transform-val :lambda-list '(m))
(cl:defmethod apply_random_transform-val ((m <SrvRegisterPointCloudOffline-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:apply_random_transform-val is deprecated.  Use mrs_pcl_tools-srv:apply_random_transform instead.")
  (apply_random_transform m))

(cl:ensure-generic-function 'init_guess_use-val :lambda-list '(m))
(cl:defmethod init_guess_use-val ((m <SrvRegisterPointCloudOffline-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:init_guess_use-val is deprecated.  Use mrs_pcl_tools-srv:init_guess_use instead.")
  (init_guess_use m))

(cl:ensure-generic-function 'init_guess_translation-val :lambda-list '(m))
(cl:defmethod init_guess_translation-val ((m <SrvRegisterPointCloudOffline-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:init_guess_translation-val is deprecated.  Use mrs_pcl_tools-srv:init_guess_translation instead.")
  (init_guess_translation m))

(cl:ensure-generic-function 'init_guess_yaw-val :lambda-list '(m))
(cl:defmethod init_guess_yaw-val ((m <SrvRegisterPointCloudOffline-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:init_guess_yaw-val is deprecated.  Use mrs_pcl_tools-srv:init_guess_yaw instead.")
  (init_guess_yaw m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SrvRegisterPointCloudOffline-request>) ostream)
  "Serializes a message object of type '<SrvRegisterPointCloudOffline-request>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'apply_random_transform) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'init_guess_use) 1 0)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'init_guess_translation) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'init_guess_yaw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SrvRegisterPointCloudOffline-request>) istream)
  "Deserializes a message object of type '<SrvRegisterPointCloudOffline-request>"
    (cl:setf (cl:slot-value msg 'apply_random_transform) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'init_guess_use) (cl:not (cl:zerop (cl:read-byte istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'init_guess_translation) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'init_guess_yaw) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SrvRegisterPointCloudOffline-request>)))
  "Returns string type for a service object of type '<SrvRegisterPointCloudOffline-request>"
  "mrs_pcl_tools/SrvRegisterPointCloudOfflineRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SrvRegisterPointCloudOffline-request)))
  "Returns string type for a service object of type 'SrvRegisterPointCloudOffline-request"
  "mrs_pcl_tools/SrvRegisterPointCloudOfflineRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SrvRegisterPointCloudOffline-request>)))
  "Returns md5sum for a message object of type '<SrvRegisterPointCloudOffline-request>"
  "ae0dfaf60e414d0235dd703f8ce80168")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SrvRegisterPointCloudOffline-request)))
  "Returns md5sum for a message object of type 'SrvRegisterPointCloudOffline-request"
  "ae0dfaf60e414d0235dd703f8ce80168")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SrvRegisterPointCloudOffline-request>)))
  "Returns full string definition for message of type '<SrvRegisterPointCloudOffline-request>"
  (cl:format cl:nil "bool                apply_random_transform~%bool                init_guess_use~%geometry_msgs/Point init_guess_translation~%float64             init_guess_yaw~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SrvRegisterPointCloudOffline-request)))
  "Returns full string definition for message of type 'SrvRegisterPointCloudOffline-request"
  (cl:format cl:nil "bool                apply_random_transform~%bool                init_guess_use~%geometry_msgs/Point init_guess_translation~%float64             init_guess_yaw~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SrvRegisterPointCloudOffline-request>))
  (cl:+ 0
     1
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'init_guess_translation))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SrvRegisterPointCloudOffline-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SrvRegisterPointCloudOffline-request
    (cl:cons ':apply_random_transform (apply_random_transform msg))
    (cl:cons ':init_guess_use (init_guess_use msg))
    (cl:cons ':init_guess_translation (init_guess_translation msg))
    (cl:cons ':init_guess_yaw (init_guess_yaw msg))
))
;//! \htmlinclude SrvRegisterPointCloudOffline-response.msg.html

(cl:defclass <SrvRegisterPointCloudOffline-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform "")
   (transform
    :reader transform
    :initarg :transform
    :type geometry_msgs-msg:TransformStamped
    :initform (cl:make-instance 'geometry_msgs-msg:TransformStamped)))
)

(cl:defclass SrvRegisterPointCloudOffline-response (<SrvRegisterPointCloudOffline-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SrvRegisterPointCloudOffline-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SrvRegisterPointCloudOffline-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_pcl_tools-srv:<SrvRegisterPointCloudOffline-response> is deprecated: use mrs_pcl_tools-srv:SrvRegisterPointCloudOffline-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SrvRegisterPointCloudOffline-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:success-val is deprecated.  Use mrs_pcl_tools-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SrvRegisterPointCloudOffline-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:message-val is deprecated.  Use mrs_pcl_tools-srv:message instead.")
  (message m))

(cl:ensure-generic-function 'transform-val :lambda-list '(m))
(cl:defmethod transform-val ((m <SrvRegisterPointCloudOffline-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_pcl_tools-srv:transform-val is deprecated.  Use mrs_pcl_tools-srv:transform instead.")
  (transform m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SrvRegisterPointCloudOffline-response>) ostream)
  "Serializes a message object of type '<SrvRegisterPointCloudOffline-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'transform) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SrvRegisterPointCloudOffline-response>) istream)
  "Deserializes a message object of type '<SrvRegisterPointCloudOffline-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'transform) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SrvRegisterPointCloudOffline-response>)))
  "Returns string type for a service object of type '<SrvRegisterPointCloudOffline-response>"
  "mrs_pcl_tools/SrvRegisterPointCloudOfflineResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SrvRegisterPointCloudOffline-response)))
  "Returns string type for a service object of type 'SrvRegisterPointCloudOffline-response"
  "mrs_pcl_tools/SrvRegisterPointCloudOfflineResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SrvRegisterPointCloudOffline-response>)))
  "Returns md5sum for a message object of type '<SrvRegisterPointCloudOffline-response>"
  "ae0dfaf60e414d0235dd703f8ce80168")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SrvRegisterPointCloudOffline-response)))
  "Returns md5sum for a message object of type 'SrvRegisterPointCloudOffline-response"
  "ae0dfaf60e414d0235dd703f8ce80168")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SrvRegisterPointCloudOffline-response>)))
  "Returns full string definition for message of type '<SrvRegisterPointCloudOffline-response>"
  (cl:format cl:nil "bool success~%string message~%geometry_msgs/TransformStamped transform~%~%~%================================================================================~%MSG: geometry_msgs/TransformStamped~%# This expresses a transform from coordinate frame header.frame_id~%# to the coordinate frame child_frame_id~%#~%# This message is mostly used by the ~%# <a href=\"http://wiki.ros.org/tf\">tf</a> package. ~%# See its documentation for more information.~%~%Header header~%string child_frame_id # the frame id of the child frame~%Transform transform~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SrvRegisterPointCloudOffline-response)))
  "Returns full string definition for message of type 'SrvRegisterPointCloudOffline-response"
  (cl:format cl:nil "bool success~%string message~%geometry_msgs/TransformStamped transform~%~%~%================================================================================~%MSG: geometry_msgs/TransformStamped~%# This expresses a transform from coordinate frame header.frame_id~%# to the coordinate frame child_frame_id~%#~%# This message is mostly used by the ~%# <a href=\"http://wiki.ros.org/tf\">tf</a> package. ~%# See its documentation for more information.~%~%Header header~%string child_frame_id # the frame id of the child frame~%Transform transform~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SrvRegisterPointCloudOffline-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'transform))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SrvRegisterPointCloudOffline-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SrvRegisterPointCloudOffline-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
    (cl:cons ':transform (transform msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SrvRegisterPointCloudOffline)))
  'SrvRegisterPointCloudOffline-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SrvRegisterPointCloudOffline)))
  'SrvRegisterPointCloudOffline-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SrvRegisterPointCloudOffline)))
  "Returns string type for a service object of type '<SrvRegisterPointCloudOffline>"
  "mrs_pcl_tools/SrvRegisterPointCloudOffline")