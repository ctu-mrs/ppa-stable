(cl:in-package mrs_pcl_tools-srv)
(cl:export '(UAV_NAME-VAL
          UAV_NAME
          INIT_GUESS_USE-VAL
          INIT_GUESS_USE
          INIT_GUESS_TRANSLATION-VAL
          INIT_GUESS_TRANSLATION
          INIT_GUESS_YAW-VAL
          INIT_GUESS_YAW
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          TRANSFORM-VAL
          TRANSFORM
))