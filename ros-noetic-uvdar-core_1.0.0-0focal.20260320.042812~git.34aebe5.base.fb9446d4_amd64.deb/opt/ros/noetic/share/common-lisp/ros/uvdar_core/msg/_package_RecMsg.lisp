(cl:in-package uvdar_core-msg)
(cl:export '(ID-VAL
          ID
          MSG-VAL
          MSG
))