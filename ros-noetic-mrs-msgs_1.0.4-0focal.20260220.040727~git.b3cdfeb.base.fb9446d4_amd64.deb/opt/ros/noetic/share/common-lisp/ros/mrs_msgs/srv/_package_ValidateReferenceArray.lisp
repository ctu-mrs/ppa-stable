(cl:in-package mrs_msgs-srv)
(cl:export '(ARRAY-VAL
          ARRAY
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))