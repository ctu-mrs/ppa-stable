; Auto-generated. Do not edit!


(cl:in-package mrs_msgs-msg)


;//! \htmlinclude GpsInfo.msg.html

(cl:defclass <GpsInfo> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (fix_type
    :reader fix_type
    :initarg :fix_type
    :type cl:fixnum
    :initform 0)
   (lat
    :reader lat
    :initarg :lat
    :type cl:float
    :initform 0.0)
   (lon
    :reader lon
    :initarg :lon
    :type cl:float
    :initform 0.0)
   (alt
    :reader alt
    :initarg :alt
    :type cl:float
    :initform 0.0)
   (eph
    :reader eph
    :initarg :eph
    :type cl:fixnum
    :initform 0)
   (epv
    :reader epv
    :initarg :epv
    :type cl:fixnum
    :initform 0)
   (vel
    :reader vel
    :initarg :vel
    :type cl:float
    :initform 0.0)
   (cog
    :reader cog
    :initarg :cog
    :type cl:float
    :initform 0.0)
   (satellites_visible
    :reader satellites_visible
    :initarg :satellites_visible
    :type cl:fixnum
    :initform 0)
   (alt_ellipsoid
    :reader alt_ellipsoid
    :initarg :alt_ellipsoid
    :type cl:float
    :initform 0.0)
   (h_acc
    :reader h_acc
    :initarg :h_acc
    :type cl:float
    :initform 0.0)
   (v_acc
    :reader v_acc
    :initarg :v_acc
    :type cl:float
    :initform 0.0)
   (vel_acc
    :reader vel_acc
    :initarg :vel_acc
    :type cl:float
    :initform 0.0)
   (hdg_acc
    :reader hdg_acc
    :initarg :hdg_acc
    :type cl:float
    :initform 0.0)
   (yaw
    :reader yaw
    :initarg :yaw
    :type cl:float
    :initform 0.0)
   (dgps_num_sats
    :reader dgps_num_sats
    :initarg :dgps_num_sats
    :type cl:fixnum
    :initform 0)
   (dgps_age
    :reader dgps_age
    :initarg :dgps_age
    :type cl:float
    :initform 0.0)
   (baseline_dist
    :reader baseline_dist
    :initarg :baseline_dist
    :type cl:float
    :initform 0.0))
)

(cl:defclass GpsInfo (<GpsInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <GpsInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'GpsInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-msg:<GpsInfo> is deprecated: use mrs_msgs-msg:GpsInfo instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:stamp-val is deprecated.  Use mrs_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'fix_type-val :lambda-list '(m))
(cl:defmethod fix_type-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:fix_type-val is deprecated.  Use mrs_msgs-msg:fix_type instead.")
  (fix_type m))

(cl:ensure-generic-function 'lat-val :lambda-list '(m))
(cl:defmethod lat-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:lat-val is deprecated.  Use mrs_msgs-msg:lat instead.")
  (lat m))

(cl:ensure-generic-function 'lon-val :lambda-list '(m))
(cl:defmethod lon-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:lon-val is deprecated.  Use mrs_msgs-msg:lon instead.")
  (lon m))

(cl:ensure-generic-function 'alt-val :lambda-list '(m))
(cl:defmethod alt-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:alt-val is deprecated.  Use mrs_msgs-msg:alt instead.")
  (alt m))

(cl:ensure-generic-function 'eph-val :lambda-list '(m))
(cl:defmethod eph-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:eph-val is deprecated.  Use mrs_msgs-msg:eph instead.")
  (eph m))

(cl:ensure-generic-function 'epv-val :lambda-list '(m))
(cl:defmethod epv-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:epv-val is deprecated.  Use mrs_msgs-msg:epv instead.")
  (epv m))

(cl:ensure-generic-function 'vel-val :lambda-list '(m))
(cl:defmethod vel-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:vel-val is deprecated.  Use mrs_msgs-msg:vel instead.")
  (vel m))

(cl:ensure-generic-function 'cog-val :lambda-list '(m))
(cl:defmethod cog-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cog-val is deprecated.  Use mrs_msgs-msg:cog instead.")
  (cog m))

(cl:ensure-generic-function 'satellites_visible-val :lambda-list '(m))
(cl:defmethod satellites_visible-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:satellites_visible-val is deprecated.  Use mrs_msgs-msg:satellites_visible instead.")
  (satellites_visible m))

(cl:ensure-generic-function 'alt_ellipsoid-val :lambda-list '(m))
(cl:defmethod alt_ellipsoid-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:alt_ellipsoid-val is deprecated.  Use mrs_msgs-msg:alt_ellipsoid instead.")
  (alt_ellipsoid m))

(cl:ensure-generic-function 'h_acc-val :lambda-list '(m))
(cl:defmethod h_acc-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:h_acc-val is deprecated.  Use mrs_msgs-msg:h_acc instead.")
  (h_acc m))

(cl:ensure-generic-function 'v_acc-val :lambda-list '(m))
(cl:defmethod v_acc-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:v_acc-val is deprecated.  Use mrs_msgs-msg:v_acc instead.")
  (v_acc m))

(cl:ensure-generic-function 'vel_acc-val :lambda-list '(m))
(cl:defmethod vel_acc-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:vel_acc-val is deprecated.  Use mrs_msgs-msg:vel_acc instead.")
  (vel_acc m))

(cl:ensure-generic-function 'hdg_acc-val :lambda-list '(m))
(cl:defmethod hdg_acc-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hdg_acc-val is deprecated.  Use mrs_msgs-msg:hdg_acc instead.")
  (hdg_acc m))

(cl:ensure-generic-function 'yaw-val :lambda-list '(m))
(cl:defmethod yaw-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:yaw-val is deprecated.  Use mrs_msgs-msg:yaw instead.")
  (yaw m))

(cl:ensure-generic-function 'dgps_num_sats-val :lambda-list '(m))
(cl:defmethod dgps_num_sats-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:dgps_num_sats-val is deprecated.  Use mrs_msgs-msg:dgps_num_sats instead.")
  (dgps_num_sats m))

(cl:ensure-generic-function 'dgps_age-val :lambda-list '(m))
(cl:defmethod dgps_age-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:dgps_age-val is deprecated.  Use mrs_msgs-msg:dgps_age instead.")
  (dgps_age m))

(cl:ensure-generic-function 'baseline_dist-val :lambda-list '(m))
(cl:defmethod baseline_dist-val ((m <GpsInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:baseline_dist-val is deprecated.  Use mrs_msgs-msg:baseline_dist instead.")
  (baseline_dist m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<GpsInfo>)))
    "Constants for message type '<GpsInfo>"
  '((:GPS_FIX_TYPE_NO_GPS . 0)
    (:GPS_FIX_TYPE_NO_FIX . 1)
    (:GPS_FIX_TYPE_2D_FIX . 2)
    (:GPS_FIX_TYPE_3D_FIX . 3)
    (:GPS_FIX_TYPE_DGPS . 4)
    (:GPS_FIX_TYPE_RTK_FLOATR . 5)
    (:GPS_FIX_TYPE_RTK_FIXEDR . 6)
    (:GPS_FIX_TYPE_STATIC . 7)
    (:GPS_FIX_TYPE_PPP . 8))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'GpsInfo)))
    "Constants for message type 'GpsInfo"
  '((:GPS_FIX_TYPE_NO_GPS . 0)
    (:GPS_FIX_TYPE_NO_FIX . 1)
    (:GPS_FIX_TYPE_2D_FIX . 2)
    (:GPS_FIX_TYPE_3D_FIX . 3)
    (:GPS_FIX_TYPE_DGPS . 4)
    (:GPS_FIX_TYPE_RTK_FLOATR . 5)
    (:GPS_FIX_TYPE_RTK_FIXEDR . 6)
    (:GPS_FIX_TYPE_STATIC . 7)
    (:GPS_FIX_TYPE_PPP . 8))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <GpsInfo>) ostream)
  "Serializes a message object of type '<GpsInfo>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'fix_type)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'lat))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'lon))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'alt))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'eph)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'eph)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'epv)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'epv)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'vel))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cog))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'satellites_visible)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'alt_ellipsoid))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'h_acc))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'v_acc))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'vel_acc))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hdg_acc))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'yaw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'dgps_num_sats)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'dgps_age))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'baseline_dist))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <GpsInfo>) istream)
  "Deserializes a message object of type '<GpsInfo>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'fix_type)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'lat) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'lon) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'alt) (roslisp-utils:decode-single-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'eph)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'eph)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'epv)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'epv)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vel) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cog) (roslisp-utils:decode-single-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'satellites_visible)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'alt_ellipsoid) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'h_acc) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'v_acc) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vel_acc) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hdg_acc) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'yaw) (roslisp-utils:decode-single-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'dgps_num_sats)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'dgps_age) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'baseline_dist) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<GpsInfo>)))
  "Returns string type for a message object of type '<GpsInfo>"
  "mrs_msgs/GpsInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'GpsInfo)))
  "Returns string type for a message object of type 'GpsInfo"
  "mrs_msgs/GpsInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<GpsInfo>)))
  "Returns md5sum for a message object of type '<GpsInfo>"
  "f63b1f2ded0353fd2f8cdc25e5ad89c9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'GpsInfo)))
  "Returns md5sum for a message object of type 'GpsInfo"
  "f63b1f2ded0353fd2f8cdc25e5ad89c9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<GpsInfo>)))
  "Returns full string definition for message of type '<GpsInfo>"
  (cl:format cl:nil "time stamp~%## GPS_FIX_TYPE enum~%~%uint8 GPS_FIX_TYPE_NO_GPS     = 0    # No GPS connected~%uint8 GPS_FIX_TYPE_NO_FIX     = 1    # No position information, GPS is connected~%uint8 GPS_FIX_TYPE_2D_FIX     = 2    # 2D position~%uint8 GPS_FIX_TYPE_3D_FIX     = 3    # 3D position~%uint8 GPS_FIX_TYPE_DGPS       = 4    # DGPS/SBAS aided 3D position~%uint8 GPS_FIX_TYPE_RTK_FLOATR = 5    # TK float, 3D position~%uint8 GPS_FIX_TYPE_RTK_FIXEDR = 6    # TK Fixed, 3D position~%uint8 GPS_FIX_TYPE_STATIC     = 7    # Static fixed, typically used for base stations~%uint8 GPS_FIX_TYPE_PPP        = 8    # PPP, 3D position~%uint8 fix_type      # [GPS_FIX_TYPE] GPS fix type~%~%float64 lat              # [deg] Latitude (WGS84, EGM96 ellipsoid)~%float64 lon              # [deg] Longitude (WGS84, EGM96 ellipsoid)~%float32 alt              # [m] Altitude (MSL). Positive for up. Note that virtually all GPS modules provide the MSL altitude in addition to the WGS84 altitude.~%uint16 eph               # GPS HDOP horizontal dilution of position (unitless). If unknown, set to: UINT16_MAX~%uint16 epv               # GPS VDOP vertical dilution of position (unitless). If unknown, set to: UINT16_MAX~%float32 vel              # [m/s] GPS ground speed. If unknown, set to: UINT16_MAX~%float32 cog              # [deg] Course over ground (NOT heading, but direction of movement), 0.0..359.99 degrees. If unknown, set to: UINT16_MAX~%uint8 satellites_visible # Number of satellites visible. If unknown, set to 255~%~%float32 alt_ellipsoid    # [m] Altitude (above WGS84, EGM96 ellipsoid). Positive for up.~%float32 h_acc            # [m] Position uncertainty. Positive for up.~%float32 v_acc            # [m] Altitude uncertainty. Positive for up.~%float32 vel_acc          # [m/s] Speed uncertainty. Positive for up.~%float32 hdg_acc          # [deg] Heading / track uncertainty~%float32 yaw              # [deg] Yaw in earth frame from north.~%~%uint8 dgps_num_sats      # Number of DGPS satellites~%float32 dgps_age          # [s] Age of DGPS info~%float32 baseline_dist     # [m] distance to the basestation~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'GpsInfo)))
  "Returns full string definition for message of type 'GpsInfo"
  (cl:format cl:nil "time stamp~%## GPS_FIX_TYPE enum~%~%uint8 GPS_FIX_TYPE_NO_GPS     = 0    # No GPS connected~%uint8 GPS_FIX_TYPE_NO_FIX     = 1    # No position information, GPS is connected~%uint8 GPS_FIX_TYPE_2D_FIX     = 2    # 2D position~%uint8 GPS_FIX_TYPE_3D_FIX     = 3    # 3D position~%uint8 GPS_FIX_TYPE_DGPS       = 4    # DGPS/SBAS aided 3D position~%uint8 GPS_FIX_TYPE_RTK_FLOATR = 5    # TK float, 3D position~%uint8 GPS_FIX_TYPE_RTK_FIXEDR = 6    # TK Fixed, 3D position~%uint8 GPS_FIX_TYPE_STATIC     = 7    # Static fixed, typically used for base stations~%uint8 GPS_FIX_TYPE_PPP        = 8    # PPP, 3D position~%uint8 fix_type      # [GPS_FIX_TYPE] GPS fix type~%~%float64 lat              # [deg] Latitude (WGS84, EGM96 ellipsoid)~%float64 lon              # [deg] Longitude (WGS84, EGM96 ellipsoid)~%float32 alt              # [m] Altitude (MSL). Positive for up. Note that virtually all GPS modules provide the MSL altitude in addition to the WGS84 altitude.~%uint16 eph               # GPS HDOP horizontal dilution of position (unitless). If unknown, set to: UINT16_MAX~%uint16 epv               # GPS VDOP vertical dilution of position (unitless). If unknown, set to: UINT16_MAX~%float32 vel              # [m/s] GPS ground speed. If unknown, set to: UINT16_MAX~%float32 cog              # [deg] Course over ground (NOT heading, but direction of movement), 0.0..359.99 degrees. If unknown, set to: UINT16_MAX~%uint8 satellites_visible # Number of satellites visible. If unknown, set to 255~%~%float32 alt_ellipsoid    # [m] Altitude (above WGS84, EGM96 ellipsoid). Positive for up.~%float32 h_acc            # [m] Position uncertainty. Positive for up.~%float32 v_acc            # [m] Altitude uncertainty. Positive for up.~%float32 vel_acc          # [m/s] Speed uncertainty. Positive for up.~%float32 hdg_acc          # [deg] Heading / track uncertainty~%float32 yaw              # [deg] Yaw in earth frame from north.~%~%uint8 dgps_num_sats      # Number of DGPS satellites~%float32 dgps_age          # [s] Age of DGPS info~%float32 baseline_dist     # [m] distance to the basestation~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <GpsInfo>))
  (cl:+ 0
     8
     1
     8
     8
     4
     2
     2
     4
     4
     1
     4
     4
     4
     4
     4
     4
     1
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <GpsInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'GpsInfo
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':fix_type (fix_type msg))
    (cl:cons ':lat (lat msg))
    (cl:cons ':lon (lon msg))
    (cl:cons ':alt (alt msg))
    (cl:cons ':eph (eph msg))
    (cl:cons ':epv (epv msg))
    (cl:cons ':vel (vel msg))
    (cl:cons ':cog (cog msg))
    (cl:cons ':satellites_visible (satellites_visible msg))
    (cl:cons ':alt_ellipsoid (alt_ellipsoid msg))
    (cl:cons ':h_acc (h_acc msg))
    (cl:cons ':v_acc (v_acc msg))
    (cl:cons ':vel_acc (vel_acc msg))
    (cl:cons ':hdg_acc (hdg_acc msg))
    (cl:cons ':yaw (yaw msg))
    (cl:cons ':dgps_num_sats (dgps_num_sats msg))
    (cl:cons ':dgps_age (dgps_age msg))
    (cl:cons ':baseline_dist (baseline_dist msg))
))
