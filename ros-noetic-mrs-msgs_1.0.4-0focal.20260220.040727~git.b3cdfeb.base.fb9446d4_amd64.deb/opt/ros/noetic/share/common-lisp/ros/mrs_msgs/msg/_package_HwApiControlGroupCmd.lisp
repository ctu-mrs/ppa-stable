(cl:in-package mrs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          ROLL-VAL
          ROLL
          PITCH-VAL
          PITCH
          YAW-VAL
          YAW
          THROTTLE-VAL
          THROTTLE
))