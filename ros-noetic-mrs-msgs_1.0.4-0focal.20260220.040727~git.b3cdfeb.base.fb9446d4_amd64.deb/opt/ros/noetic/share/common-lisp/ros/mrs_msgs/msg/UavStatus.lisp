; Auto-generated. Do not edit!


(cl:in-package mrs_msgs-msg)


;//! \htmlinclude UavStatus.msg.html

(cl:defclass <UavStatus> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (uav_name
    :reader uav_name
    :initarg :uav_name
    :type cl:string
    :initform "")
   (uav_type
    :reader uav_type
    :initarg :uav_type
    :type cl:string
    :initform "")
   (uav_mass
    :reader uav_mass
    :initarg :uav_mass
    :type cl:string
    :initform "")
   (control_manager_diag_hz
    :reader control_manager_diag_hz
    :initarg :control_manager_diag_hz
    :type cl:float
    :initform 0.0)
   (control_manager_diag_color
    :reader control_manager_diag_color
    :initarg :control_manager_diag_color
    :type cl:fixnum
    :initform 0)
   (controllers
    :reader controllers
    :initarg :controllers
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (gains
    :reader gains
    :initarg :gains
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (trackers
    :reader trackers
    :initarg :trackers
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (constraints
    :reader constraints
    :initarg :constraints
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (null_tracker
    :reader null_tracker
    :initarg :null_tracker
    :type cl:boolean
    :initform cl:nil)
   (secs_flown
    :reader secs_flown
    :initarg :secs_flown
    :type cl:integer
    :initform 0)
   (odom_hz
    :reader odom_hz
    :initarg :odom_hz
    :type cl:float
    :initform 0.0)
   (odom_color
    :reader odom_color
    :initarg :odom_color
    :type cl:fixnum
    :initform 0)
   (odom_x
    :reader odom_x
    :initarg :odom_x
    :type cl:float
    :initform 0.0)
   (odom_y
    :reader odom_y
    :initarg :odom_y
    :type cl:float
    :initform 0.0)
   (odom_z
    :reader odom_z
    :initarg :odom_z
    :type cl:float
    :initform 0.0)
   (odom_hdg
    :reader odom_hdg
    :initarg :odom_hdg
    :type cl:float
    :initform 0.0)
   (odom_frame
    :reader odom_frame
    :initarg :odom_frame
    :type cl:string
    :initform "")
   (odom_estimators
    :reader odom_estimators
    :initarg :odom_estimators
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (horizontal_estimator
    :reader horizontal_estimator
    :initarg :horizontal_estimator
    :type cl:string
    :initform "")
   (vertical_estimator
    :reader vertical_estimator
    :initarg :vertical_estimator
    :type cl:string
    :initform "")
   (heading_estimator
    :reader heading_estimator
    :initarg :heading_estimator
    :type cl:string
    :initform "")
   (agl_estimator
    :reader agl_estimator
    :initarg :agl_estimator
    :type cl:string
    :initform "")
   (max_flight_z
    :reader max_flight_z
    :initarg :max_flight_z
    :type cl:float
    :initform 0.0)
   (cmd_x
    :reader cmd_x
    :initarg :cmd_x
    :type cl:float
    :initform 0.0)
   (cmd_y
    :reader cmd_y
    :initarg :cmd_y
    :type cl:float
    :initform 0.0)
   (cmd_z
    :reader cmd_z
    :initarg :cmd_z
    :type cl:float
    :initform 0.0)
   (cmd_hdg
    :reader cmd_hdg
    :initarg :cmd_hdg
    :type cl:float
    :initform 0.0)
   (cpu_load
    :reader cpu_load
    :initarg :cpu_load
    :type cl:float
    :initform 0.0)
   (cpu_load_total
    :reader cpu_load_total
    :initarg :cpu_load_total
    :type cl:float
    :initform 0.0)
   (cpu_ghz
    :reader cpu_ghz
    :initarg :cpu_ghz
    :type cl:float
    :initform 0.0)
   (cpu_temperature
    :reader cpu_temperature
    :initarg :cpu_temperature
    :type cl:float
    :initform 0.0)
   (free_ram
    :reader free_ram
    :initarg :free_ram
    :type cl:float
    :initform 0.0)
   (total_ram
    :reader total_ram
    :initarg :total_ram
    :type cl:float
    :initform 0.0)
   (free_hdd
    :reader free_hdd
    :initarg :free_hdd
    :type cl:integer
    :initform 0)
   (hw_api_hz
    :reader hw_api_hz
    :initarg :hw_api_hz
    :type cl:float
    :initform 0.0)
   (hw_api_color
    :reader hw_api_color
    :initarg :hw_api_color
    :type cl:fixnum
    :initform 0)
   (hw_api_battery_hz
    :reader hw_api_battery_hz
    :initarg :hw_api_battery_hz
    :type cl:float
    :initform 0.0)
   (hw_api_state_hz
    :reader hw_api_state_hz
    :initarg :hw_api_state_hz
    :type cl:float
    :initform 0.0)
   (hw_api_cmd_hz
    :reader hw_api_cmd_hz
    :initarg :hw_api_cmd_hz
    :type cl:float
    :initform 0.0)
   (hw_api_mode
    :reader hw_api_mode
    :initarg :hw_api_mode
    :type cl:string
    :initform "")
   (hw_api_armed
    :reader hw_api_armed
    :initarg :hw_api_armed
    :type cl:boolean
    :initform cl:nil)
   (hw_api_gnss_ok
    :reader hw_api_gnss_ok
    :initarg :hw_api_gnss_ok
    :type cl:boolean
    :initform cl:nil)
   (hw_api_gnss_qual
    :reader hw_api_gnss_qual
    :initarg :hw_api_gnss_qual
    :type cl:float
    :initform 0.0)
   (mag_norm_hz
    :reader mag_norm_hz
    :initarg :mag_norm_hz
    :type cl:float
    :initform 0.0)
   (hw_api_gnss_fix_type
    :reader hw_api_gnss_fix_type
    :initarg :hw_api_gnss_fix_type
    :type cl:fixnum
    :initform 0)
   (hw_api_gnss_num_sats
    :reader hw_api_gnss_num_sats
    :initarg :hw_api_gnss_num_sats
    :type cl:fixnum
    :initform 0)
   (hw_api_gnss_pos_acc
    :reader hw_api_gnss_pos_acc
    :initarg :hw_api_gnss_pos_acc
    :type cl:float
    :initform 0.0)
   (hw_api_gnss_status_hz
    :reader hw_api_gnss_status_hz
    :initarg :hw_api_gnss_status_hz
    :type cl:float
    :initform 0.0)
   (mag_norm
    :reader mag_norm
    :initarg :mag_norm
    :type cl:float
    :initform 0.0)
   (battery_volt
    :reader battery_volt
    :initarg :battery_volt
    :type cl:float
    :initform 0.0)
   (battery_curr
    :reader battery_curr
    :initarg :battery_curr
    :type cl:float
    :initform 0.0)
   (battery_wh_drained
    :reader battery_wh_drained
    :initarg :battery_wh_drained
    :type cl:float
    :initform 0.0)
   (thrust
    :reader thrust
    :initarg :thrust
    :type cl:float
    :initform 0.0)
   (mass_estimate
    :reader mass_estimate
    :initarg :mass_estimate
    :type cl:float
    :initform 0.0)
   (mass_set
    :reader mass_set
    :initarg :mass_set
    :type cl:float
    :initform 0.0)
   (custom_topics
    :reader custom_topics
    :initarg :custom_topics
    :type (cl:vector mrs_msgs-msg:CustomTopic)
   :initform (cl:make-array 0 :element-type 'mrs_msgs-msg:CustomTopic :initial-element (cl:make-instance 'mrs_msgs-msg:CustomTopic)))
   (custom_string_outputs
    :reader custom_string_outputs
    :initarg :custom_string_outputs
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (node_cpu_loads
    :reader node_cpu_loads
    :initarg :node_cpu_loads
    :type mrs_msgs-msg:NodeCpuLoad
    :initform (cl:make-instance 'mrs_msgs-msg:NodeCpuLoad))
   (flying_normally
    :reader flying_normally
    :initarg :flying_normally
    :type cl:boolean
    :initform cl:nil)
   (rc_mode
    :reader rc_mode
    :initarg :rc_mode
    :type cl:boolean
    :initform cl:nil)
   (have_goal
    :reader have_goal
    :initarg :have_goal
    :type cl:boolean
    :initform cl:nil)
   (tracking_trajectory
    :reader tracking_trajectory
    :initarg :tracking_trajectory
    :type cl:boolean
    :initform cl:nil)
   (callbacks_enabled
    :reader callbacks_enabled
    :initarg :callbacks_enabled
    :type cl:boolean
    :initform cl:nil)
   (collision_avoidance_enabled
    :reader collision_avoidance_enabled
    :initarg :collision_avoidance_enabled
    :type cl:boolean
    :initform cl:nil)
   (avoiding_collision
    :reader avoiding_collision
    :initarg :avoiding_collision
    :type cl:boolean
    :initform cl:nil)
   (automatic_start_can_takeoff
    :reader automatic_start_can_takeoff
    :initarg :automatic_start_can_takeoff
    :type cl:boolean
    :initform cl:nil)
   (num_other_uavs
    :reader num_other_uavs
    :initarg :num_other_uavs
    :type cl:fixnum
    :initform 0))
)

(cl:defclass UavStatus (<UavStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <UavStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'UavStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-msg:<UavStatus> is deprecated: use mrs_msgs-msg:UavStatus instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:header-val is deprecated.  Use mrs_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'uav_name-val :lambda-list '(m))
(cl:defmethod uav_name-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:uav_name-val is deprecated.  Use mrs_msgs-msg:uav_name instead.")
  (uav_name m))

(cl:ensure-generic-function 'uav_type-val :lambda-list '(m))
(cl:defmethod uav_type-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:uav_type-val is deprecated.  Use mrs_msgs-msg:uav_type instead.")
  (uav_type m))

(cl:ensure-generic-function 'uav_mass-val :lambda-list '(m))
(cl:defmethod uav_mass-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:uav_mass-val is deprecated.  Use mrs_msgs-msg:uav_mass instead.")
  (uav_mass m))

(cl:ensure-generic-function 'control_manager_diag_hz-val :lambda-list '(m))
(cl:defmethod control_manager_diag_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:control_manager_diag_hz-val is deprecated.  Use mrs_msgs-msg:control_manager_diag_hz instead.")
  (control_manager_diag_hz m))

(cl:ensure-generic-function 'control_manager_diag_color-val :lambda-list '(m))
(cl:defmethod control_manager_diag_color-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:control_manager_diag_color-val is deprecated.  Use mrs_msgs-msg:control_manager_diag_color instead.")
  (control_manager_diag_color m))

(cl:ensure-generic-function 'controllers-val :lambda-list '(m))
(cl:defmethod controllers-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:controllers-val is deprecated.  Use mrs_msgs-msg:controllers instead.")
  (controllers m))

(cl:ensure-generic-function 'gains-val :lambda-list '(m))
(cl:defmethod gains-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:gains-val is deprecated.  Use mrs_msgs-msg:gains instead.")
  (gains m))

(cl:ensure-generic-function 'trackers-val :lambda-list '(m))
(cl:defmethod trackers-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:trackers-val is deprecated.  Use mrs_msgs-msg:trackers instead.")
  (trackers m))

(cl:ensure-generic-function 'constraints-val :lambda-list '(m))
(cl:defmethod constraints-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:constraints-val is deprecated.  Use mrs_msgs-msg:constraints instead.")
  (constraints m))

(cl:ensure-generic-function 'null_tracker-val :lambda-list '(m))
(cl:defmethod null_tracker-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:null_tracker-val is deprecated.  Use mrs_msgs-msg:null_tracker instead.")
  (null_tracker m))

(cl:ensure-generic-function 'secs_flown-val :lambda-list '(m))
(cl:defmethod secs_flown-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:secs_flown-val is deprecated.  Use mrs_msgs-msg:secs_flown instead.")
  (secs_flown m))

(cl:ensure-generic-function 'odom_hz-val :lambda-list '(m))
(cl:defmethod odom_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_hz-val is deprecated.  Use mrs_msgs-msg:odom_hz instead.")
  (odom_hz m))

(cl:ensure-generic-function 'odom_color-val :lambda-list '(m))
(cl:defmethod odom_color-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_color-val is deprecated.  Use mrs_msgs-msg:odom_color instead.")
  (odom_color m))

(cl:ensure-generic-function 'odom_x-val :lambda-list '(m))
(cl:defmethod odom_x-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_x-val is deprecated.  Use mrs_msgs-msg:odom_x instead.")
  (odom_x m))

(cl:ensure-generic-function 'odom_y-val :lambda-list '(m))
(cl:defmethod odom_y-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_y-val is deprecated.  Use mrs_msgs-msg:odom_y instead.")
  (odom_y m))

(cl:ensure-generic-function 'odom_z-val :lambda-list '(m))
(cl:defmethod odom_z-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_z-val is deprecated.  Use mrs_msgs-msg:odom_z instead.")
  (odom_z m))

(cl:ensure-generic-function 'odom_hdg-val :lambda-list '(m))
(cl:defmethod odom_hdg-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_hdg-val is deprecated.  Use mrs_msgs-msg:odom_hdg instead.")
  (odom_hdg m))

(cl:ensure-generic-function 'odom_frame-val :lambda-list '(m))
(cl:defmethod odom_frame-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_frame-val is deprecated.  Use mrs_msgs-msg:odom_frame instead.")
  (odom_frame m))

(cl:ensure-generic-function 'odom_estimators-val :lambda-list '(m))
(cl:defmethod odom_estimators-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:odom_estimators-val is deprecated.  Use mrs_msgs-msg:odom_estimators instead.")
  (odom_estimators m))

(cl:ensure-generic-function 'horizontal_estimator-val :lambda-list '(m))
(cl:defmethod horizontal_estimator-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:horizontal_estimator-val is deprecated.  Use mrs_msgs-msg:horizontal_estimator instead.")
  (horizontal_estimator m))

(cl:ensure-generic-function 'vertical_estimator-val :lambda-list '(m))
(cl:defmethod vertical_estimator-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:vertical_estimator-val is deprecated.  Use mrs_msgs-msg:vertical_estimator instead.")
  (vertical_estimator m))

(cl:ensure-generic-function 'heading_estimator-val :lambda-list '(m))
(cl:defmethod heading_estimator-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:heading_estimator-val is deprecated.  Use mrs_msgs-msg:heading_estimator instead.")
  (heading_estimator m))

(cl:ensure-generic-function 'agl_estimator-val :lambda-list '(m))
(cl:defmethod agl_estimator-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:agl_estimator-val is deprecated.  Use mrs_msgs-msg:agl_estimator instead.")
  (agl_estimator m))

(cl:ensure-generic-function 'max_flight_z-val :lambda-list '(m))
(cl:defmethod max_flight_z-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:max_flight_z-val is deprecated.  Use mrs_msgs-msg:max_flight_z instead.")
  (max_flight_z m))

(cl:ensure-generic-function 'cmd_x-val :lambda-list '(m))
(cl:defmethod cmd_x-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cmd_x-val is deprecated.  Use mrs_msgs-msg:cmd_x instead.")
  (cmd_x m))

(cl:ensure-generic-function 'cmd_y-val :lambda-list '(m))
(cl:defmethod cmd_y-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cmd_y-val is deprecated.  Use mrs_msgs-msg:cmd_y instead.")
  (cmd_y m))

(cl:ensure-generic-function 'cmd_z-val :lambda-list '(m))
(cl:defmethod cmd_z-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cmd_z-val is deprecated.  Use mrs_msgs-msg:cmd_z instead.")
  (cmd_z m))

(cl:ensure-generic-function 'cmd_hdg-val :lambda-list '(m))
(cl:defmethod cmd_hdg-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cmd_hdg-val is deprecated.  Use mrs_msgs-msg:cmd_hdg instead.")
  (cmd_hdg m))

(cl:ensure-generic-function 'cpu_load-val :lambda-list '(m))
(cl:defmethod cpu_load-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cpu_load-val is deprecated.  Use mrs_msgs-msg:cpu_load instead.")
  (cpu_load m))

(cl:ensure-generic-function 'cpu_load_total-val :lambda-list '(m))
(cl:defmethod cpu_load_total-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cpu_load_total-val is deprecated.  Use mrs_msgs-msg:cpu_load_total instead.")
  (cpu_load_total m))

(cl:ensure-generic-function 'cpu_ghz-val :lambda-list '(m))
(cl:defmethod cpu_ghz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cpu_ghz-val is deprecated.  Use mrs_msgs-msg:cpu_ghz instead.")
  (cpu_ghz m))

(cl:ensure-generic-function 'cpu_temperature-val :lambda-list '(m))
(cl:defmethod cpu_temperature-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:cpu_temperature-val is deprecated.  Use mrs_msgs-msg:cpu_temperature instead.")
  (cpu_temperature m))

(cl:ensure-generic-function 'free_ram-val :lambda-list '(m))
(cl:defmethod free_ram-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:free_ram-val is deprecated.  Use mrs_msgs-msg:free_ram instead.")
  (free_ram m))

(cl:ensure-generic-function 'total_ram-val :lambda-list '(m))
(cl:defmethod total_ram-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:total_ram-val is deprecated.  Use mrs_msgs-msg:total_ram instead.")
  (total_ram m))

(cl:ensure-generic-function 'free_hdd-val :lambda-list '(m))
(cl:defmethod free_hdd-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:free_hdd-val is deprecated.  Use mrs_msgs-msg:free_hdd instead.")
  (free_hdd m))

(cl:ensure-generic-function 'hw_api_hz-val :lambda-list '(m))
(cl:defmethod hw_api_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_hz-val is deprecated.  Use mrs_msgs-msg:hw_api_hz instead.")
  (hw_api_hz m))

(cl:ensure-generic-function 'hw_api_color-val :lambda-list '(m))
(cl:defmethod hw_api_color-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_color-val is deprecated.  Use mrs_msgs-msg:hw_api_color instead.")
  (hw_api_color m))

(cl:ensure-generic-function 'hw_api_battery_hz-val :lambda-list '(m))
(cl:defmethod hw_api_battery_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_battery_hz-val is deprecated.  Use mrs_msgs-msg:hw_api_battery_hz instead.")
  (hw_api_battery_hz m))

(cl:ensure-generic-function 'hw_api_state_hz-val :lambda-list '(m))
(cl:defmethod hw_api_state_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_state_hz-val is deprecated.  Use mrs_msgs-msg:hw_api_state_hz instead.")
  (hw_api_state_hz m))

(cl:ensure-generic-function 'hw_api_cmd_hz-val :lambda-list '(m))
(cl:defmethod hw_api_cmd_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_cmd_hz-val is deprecated.  Use mrs_msgs-msg:hw_api_cmd_hz instead.")
  (hw_api_cmd_hz m))

(cl:ensure-generic-function 'hw_api_mode-val :lambda-list '(m))
(cl:defmethod hw_api_mode-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_mode-val is deprecated.  Use mrs_msgs-msg:hw_api_mode instead.")
  (hw_api_mode m))

(cl:ensure-generic-function 'hw_api_armed-val :lambda-list '(m))
(cl:defmethod hw_api_armed-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_armed-val is deprecated.  Use mrs_msgs-msg:hw_api_armed instead.")
  (hw_api_armed m))

(cl:ensure-generic-function 'hw_api_gnss_ok-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_ok-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_ok-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_ok instead.")
  (hw_api_gnss_ok m))

(cl:ensure-generic-function 'hw_api_gnss_qual-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_qual-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_qual-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_qual instead.")
  (hw_api_gnss_qual m))

(cl:ensure-generic-function 'mag_norm_hz-val :lambda-list '(m))
(cl:defmethod mag_norm_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:mag_norm_hz-val is deprecated.  Use mrs_msgs-msg:mag_norm_hz instead.")
  (mag_norm_hz m))

(cl:ensure-generic-function 'hw_api_gnss_fix_type-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_fix_type-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_fix_type-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_fix_type instead.")
  (hw_api_gnss_fix_type m))

(cl:ensure-generic-function 'hw_api_gnss_num_sats-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_num_sats-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_num_sats-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_num_sats instead.")
  (hw_api_gnss_num_sats m))

(cl:ensure-generic-function 'hw_api_gnss_pos_acc-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_pos_acc-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_pos_acc-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_pos_acc instead.")
  (hw_api_gnss_pos_acc m))

(cl:ensure-generic-function 'hw_api_gnss_status_hz-val :lambda-list '(m))
(cl:defmethod hw_api_gnss_status_hz-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:hw_api_gnss_status_hz-val is deprecated.  Use mrs_msgs-msg:hw_api_gnss_status_hz instead.")
  (hw_api_gnss_status_hz m))

(cl:ensure-generic-function 'mag_norm-val :lambda-list '(m))
(cl:defmethod mag_norm-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:mag_norm-val is deprecated.  Use mrs_msgs-msg:mag_norm instead.")
  (mag_norm m))

(cl:ensure-generic-function 'battery_volt-val :lambda-list '(m))
(cl:defmethod battery_volt-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:battery_volt-val is deprecated.  Use mrs_msgs-msg:battery_volt instead.")
  (battery_volt m))

(cl:ensure-generic-function 'battery_curr-val :lambda-list '(m))
(cl:defmethod battery_curr-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:battery_curr-val is deprecated.  Use mrs_msgs-msg:battery_curr instead.")
  (battery_curr m))

(cl:ensure-generic-function 'battery_wh_drained-val :lambda-list '(m))
(cl:defmethod battery_wh_drained-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:battery_wh_drained-val is deprecated.  Use mrs_msgs-msg:battery_wh_drained instead.")
  (battery_wh_drained m))

(cl:ensure-generic-function 'thrust-val :lambda-list '(m))
(cl:defmethod thrust-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:thrust-val is deprecated.  Use mrs_msgs-msg:thrust instead.")
  (thrust m))

(cl:ensure-generic-function 'mass_estimate-val :lambda-list '(m))
(cl:defmethod mass_estimate-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:mass_estimate-val is deprecated.  Use mrs_msgs-msg:mass_estimate instead.")
  (mass_estimate m))

(cl:ensure-generic-function 'mass_set-val :lambda-list '(m))
(cl:defmethod mass_set-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:mass_set-val is deprecated.  Use mrs_msgs-msg:mass_set instead.")
  (mass_set m))

(cl:ensure-generic-function 'custom_topics-val :lambda-list '(m))
(cl:defmethod custom_topics-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:custom_topics-val is deprecated.  Use mrs_msgs-msg:custom_topics instead.")
  (custom_topics m))

(cl:ensure-generic-function 'custom_string_outputs-val :lambda-list '(m))
(cl:defmethod custom_string_outputs-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:custom_string_outputs-val is deprecated.  Use mrs_msgs-msg:custom_string_outputs instead.")
  (custom_string_outputs m))

(cl:ensure-generic-function 'node_cpu_loads-val :lambda-list '(m))
(cl:defmethod node_cpu_loads-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:node_cpu_loads-val is deprecated.  Use mrs_msgs-msg:node_cpu_loads instead.")
  (node_cpu_loads m))

(cl:ensure-generic-function 'flying_normally-val :lambda-list '(m))
(cl:defmethod flying_normally-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:flying_normally-val is deprecated.  Use mrs_msgs-msg:flying_normally instead.")
  (flying_normally m))

(cl:ensure-generic-function 'rc_mode-val :lambda-list '(m))
(cl:defmethod rc_mode-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:rc_mode-val is deprecated.  Use mrs_msgs-msg:rc_mode instead.")
  (rc_mode m))

(cl:ensure-generic-function 'have_goal-val :lambda-list '(m))
(cl:defmethod have_goal-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:have_goal-val is deprecated.  Use mrs_msgs-msg:have_goal instead.")
  (have_goal m))

(cl:ensure-generic-function 'tracking_trajectory-val :lambda-list '(m))
(cl:defmethod tracking_trajectory-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:tracking_trajectory-val is deprecated.  Use mrs_msgs-msg:tracking_trajectory instead.")
  (tracking_trajectory m))

(cl:ensure-generic-function 'callbacks_enabled-val :lambda-list '(m))
(cl:defmethod callbacks_enabled-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:callbacks_enabled-val is deprecated.  Use mrs_msgs-msg:callbacks_enabled instead.")
  (callbacks_enabled m))

(cl:ensure-generic-function 'collision_avoidance_enabled-val :lambda-list '(m))
(cl:defmethod collision_avoidance_enabled-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:collision_avoidance_enabled-val is deprecated.  Use mrs_msgs-msg:collision_avoidance_enabled instead.")
  (collision_avoidance_enabled m))

(cl:ensure-generic-function 'avoiding_collision-val :lambda-list '(m))
(cl:defmethod avoiding_collision-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:avoiding_collision-val is deprecated.  Use mrs_msgs-msg:avoiding_collision instead.")
  (avoiding_collision m))

(cl:ensure-generic-function 'automatic_start_can_takeoff-val :lambda-list '(m))
(cl:defmethod automatic_start_can_takeoff-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:automatic_start_can_takeoff-val is deprecated.  Use mrs_msgs-msg:automatic_start_can_takeoff instead.")
  (automatic_start_can_takeoff m))

(cl:ensure-generic-function 'num_other_uavs-val :lambda-list '(m))
(cl:defmethod num_other_uavs-val ((m <UavStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:num_other_uavs-val is deprecated.  Use mrs_msgs-msg:num_other_uavs instead.")
  (num_other_uavs m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <UavStatus>) ostream)
  "Serializes a message object of type '<UavStatus>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'uav_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'uav_name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'uav_type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'uav_type))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'uav_mass))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'uav_mass))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'control_manager_diag_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'control_manager_diag_color)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'controllers))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'controllers))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'gains))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'gains))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'trackers))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'trackers))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'constraints))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'constraints))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'null_tracker) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'secs_flown)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'secs_flown)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'secs_flown)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'secs_flown)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'odom_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'odom_color)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'odom_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'odom_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'odom_z))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'odom_hdg))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'odom_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'odom_frame))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'odom_estimators))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'odom_estimators))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'horizontal_estimator))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'horizontal_estimator))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'vertical_estimator))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'vertical_estimator))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'heading_estimator))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'heading_estimator))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'agl_estimator))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'agl_estimator))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'max_flight_z))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cmd_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cmd_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cmd_z))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cmd_hdg))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_load))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_load_total))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_ghz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_temperature))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'free_ram))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'total_ram))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'free_hdd)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'hw_api_color)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_battery_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_state_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_cmd_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'hw_api_mode))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'hw_api_mode))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'hw_api_armed) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'hw_api_gnss_ok) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_gnss_qual))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mag_norm_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'hw_api_gnss_fix_type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'hw_api_gnss_num_sats)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_gnss_pos_acc))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_gnss_status_hz))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mag_norm))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_volt))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_curr))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_wh_drained))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'thrust))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mass_estimate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mass_set))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'custom_topics))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'custom_topics))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'custom_string_outputs))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'custom_string_outputs))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'node_cpu_loads) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'flying_normally) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'rc_mode) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'have_goal) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'tracking_trajectory) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'callbacks_enabled) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'collision_avoidance_enabled) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'avoiding_collision) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'automatic_start_can_takeoff) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_other_uavs)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_other_uavs)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <UavStatus>) istream)
  "Deserializes a message object of type '<UavStatus>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'uav_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'uav_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'uav_type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'uav_type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'uav_mass) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'uav_mass) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'control_manager_diag_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'control_manager_diag_color) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'controllers) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'controllers)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'gains) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'gains)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'trackers) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'trackers)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'constraints) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'constraints)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:setf (cl:slot-value msg 'null_tracker) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'secs_flown)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'secs_flown)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'secs_flown)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'secs_flown)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'odom_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'odom_color) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'odom_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'odom_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'odom_z) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'odom_hdg) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'odom_frame) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'odom_frame) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'odom_estimators) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'odom_estimators)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'horizontal_estimator) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'horizontal_estimator) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'vertical_estimator) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'vertical_estimator) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'heading_estimator) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'heading_estimator) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'agl_estimator) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'agl_estimator) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'max_flight_z) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cmd_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cmd_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cmd_z) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cmd_hdg) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_load) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_load_total) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_ghz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_temperature) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'free_ram) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'total_ram) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'free_hdd) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'hw_api_color) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_battery_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_state_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_cmd_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'hw_api_mode) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'hw_api_mode) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'hw_api_armed) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'hw_api_gnss_ok) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_gnss_qual) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mag_norm_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'hw_api_gnss_fix_type)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'hw_api_gnss_num_sats)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_gnss_pos_acc) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_gnss_status_hz) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mag_norm) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_volt) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_curr) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_wh_drained) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'thrust) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mass_estimate) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mass_set) (roslisp-utils:decode-single-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'custom_topics) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'custom_topics)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'mrs_msgs-msg:CustomTopic))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'custom_string_outputs) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'custom_string_outputs)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'node_cpu_loads) istream)
    (cl:setf (cl:slot-value msg 'flying_normally) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'rc_mode) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'have_goal) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'tracking_trajectory) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'callbacks_enabled) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'collision_avoidance_enabled) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'avoiding_collision) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'automatic_start_can_takeoff) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_other_uavs)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_other_uavs)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<UavStatus>)))
  "Returns string type for a message object of type '<UavStatus>"
  "mrs_msgs/UavStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'UavStatus)))
  "Returns string type for a message object of type 'UavStatus"
  "mrs_msgs/UavStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<UavStatus>)))
  "Returns md5sum for a message object of type '<UavStatus>"
  "4802adcdb2264a820b1be493e7502cc3")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'UavStatus)))
  "Returns md5sum for a message object of type 'UavStatus"
  "4802adcdb2264a820b1be493e7502cc3")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<UavStatus>)))
  "Returns full string definition for message of type '<UavStatus>"
  (cl:format cl:nil "# Standard ROS header with stamp and coordinate frame ID~%Header header~%~%# Unique name of the UAV~%string uav_name~%# Name of the UAV model~%string uav_type~%# The current estimated UAV's mass as a string for display purposes~%string uav_mass~%~%# Frequency of receiving the Control Manager diagnostics~%float32 control_manager_diag_hz~%# Display color (for TUI visualization purposes)~%int16 control_manager_diag_color~%# A list of the available control algorithms, the first element is the active controller~%string[] controllers~%# A list of the available control gain presets for the current controller, the first element is the active preset~%string[] gains~%# A list of the available trajectory tracking (pre-shaping) algorithms, the first element is the active algorithm~%string[] trackers~%# A list of the available dynamic constraint presets for the current tracker, the first element is the active preset~%string[] constraints~%# True if the null (no-output) tracker is active~%bool null_tracker~%# Flight time~%uint32 secs_flown~%~%# Frequency of receiving the Estimation Manager diagnostics~%float32 odom_hz~%# Display color (for TUI visualization purposes)~%int16 odom_color~%# X position of the UAV in the current estimation coordinate frame~%float32 odom_x~%# Y position of the UAV in the current estimation coordinate frame~%float32 odom_y~%# Z position of the UAV in the current estimation coordinate frame~%float32 odom_z~%# Heading of the UAV in the current estimation coordinate frame~%float32 odom_hdg~%# Name of the current estimation coordinate frame~%string odom_frame~%# A list of the available ego-state estimation sources, the first element is the active source~%string[] odom_estimators~%# Name of the current source used for estimation of the UAV's horizontal position ~%string horizontal_estimator~%# Name of the current source used for estimation of the UAV's vertical position ~%string vertical_estimator~%# Name of the current source used for estimation of the UAV's heading~%string heading_estimator~%# Name of the current source used for estimation of the UAV's above ground level~%string agl_estimator~%# Maximal allowed Z coordinate of the UAV~%float32 max_flight_z~%~%# Setpoint X position of the UAV in the current estimation coordinate frame~%float32 cmd_x~%# Setpoint Y position of the UAV in the current estimation coordinate frame~%float32 cmd_y~%# Setpoint Z position of the UAV in the current estimation coordinate frame~%float32 cmd_z~%# Setpoint heading of the UAV in the current estimation coordinate frame~%float32 cmd_hdg~%~%# Current load of the CPU in percent relative all CPU cores (i.e. a maximal load of a 2-core CPU is 100.0)~%float32 cpu_load~%# Current load of the CPU in percent relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)~%float32 cpu_load_total~%# Current average frequency of the CPU in gigahertz~%float32 cpu_ghz~%# Current temperature of the CPU in degrees Celsius (or zero if not supported by the current system)~%float32 cpu_temperature~%# The amount of free RAM in gigabytes~%float32 free_ram~%# The total available RAM in gigabytes~%float32 total_ram~%# The amount of free disk space in gigabytes~%int32 free_hdd~%~%# Frequency of receiving the Hardware API diagnostics~%float32 hw_api_hz~%# Display color (for TUI visualization purposes)~%int16 hw_api_color~%# Frequency of receiving the battery status from the Hardware API~%float32 hw_api_battery_hz~%# Frequency of receiving the Hardware API status~%float32 hw_api_state_hz~%# Frequency of receiving the Hardware API commanded setpoint~%float32 hw_api_cmd_hz~%# Name of the current mode reported by the Hardware API (e.g.: \"OFFBOARD\", \"AUTO.LAND\", etc.)~%string hw_api_mode~%# True if the vehicle is armed (actuator movement is enabled)~%bool hw_api_armed~%# True if the GPS data is being received correctly~%bool hw_api_gnss_ok~%# A measure of the GPS position quality~%float32 hw_api_gnss_qual~%# Frequency of receiving the magnetic field norm~%float32 mag_norm_hz~%~%# Gnss fix type~%# 0 -> No GPS connected~%# 1 -> No position information, GPS is connected~%# 2 -> 2D position~%# 3 -> 3D position~%# 4 -> DGPS/SBAS aided 3D position~%# 5 -> TK float, 3D position~%# 6 -> TK Fixed, 3D position~%# 7 -> Static fixed, typically used for base stations~%# 8 -> PPP, 3D position~%uint8 hw_api_gnss_fix_type~%~%# Number of satellites used for gnss solution~%uint8 hw_api_gnss_num_sats~%~%# Estimated accuracy of the gnss solution (in meters)~%float32 hw_api_gnss_pos_acc~%~%# Rate of the gnss status message~%float32 hw_api_gnss_status_hz~%~%# Norm of the  magnetic field (in Gauss, 10Gauss = 1mT)~%float32 mag_norm~%# Battery voltage in volts~%float32 battery_volt~%# Battery current in amperes~%float32 battery_curr~%# Estimate of the drained battery power in watthours~%float32 battery_wh_drained~%# Current collective thrust relative to max. thrust (i.e. between 0 and 1)~%float32 thrust~%# Current estimated mass of the vehicle~%float32 mass_estimate~%# Nominal mass of the vehicle~%float32 mass_set~%~%# A list of custom topics to be displayed in the TUI~%CustomTopic[] custom_topics~%# A list of custom strings to be displayed in the TUI~%string[] custom_string_outputs~%~%# A list of node names and a list of their corresponding CPU loads relative to a single CPU core~%NodeCpuLoad node_cpu_loads~%~%# True if the UAV is flying and there are no emergency or safety maneuvers taking place~%bool flying_normally~%# True if the UAV is currently controlled by the RC~%bool rc_mode~%# True if the UAV is currently flying to a goal waypoint~%bool have_goal~%# True if the UAV is currently following a trajectory (implies have_goal == true)~%bool tracking_trajectory~%# True if the control pipeline is ready to receive and execute waypoints and trajectories~%bool callbacks_enabled~%# True if collision avoidance with other UAVs using the NimbRo network is enabled~%bool collision_avoidance_enabled~%# True if the UAV is currently performing a maneuver to avoid a collision with another UAV~%bool avoiding_collision~%# True if the UAV is ready to take off~%bool automatic_start_can_takeoff~%~%# The number of other UAVs whose predicted trajectory is available to this one (for collision avoidance purposes)~%uint16 num_other_uavs~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/CustomTopic~%string topic_name~%float32 topic_hz~%int16 topic_color~%~%================================================================================~%MSG: mrs_msgs/NodeCpuLoad~%# A list of names of all ROS nodes running on this UAV~%string[] node_names~%# A list of the corresponding CPU loads of these nodes relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)~%float32[] cpu_loads~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'UavStatus)))
  "Returns full string definition for message of type 'UavStatus"
  (cl:format cl:nil "# Standard ROS header with stamp and coordinate frame ID~%Header header~%~%# Unique name of the UAV~%string uav_name~%# Name of the UAV model~%string uav_type~%# The current estimated UAV's mass as a string for display purposes~%string uav_mass~%~%# Frequency of receiving the Control Manager diagnostics~%float32 control_manager_diag_hz~%# Display color (for TUI visualization purposes)~%int16 control_manager_diag_color~%# A list of the available control algorithms, the first element is the active controller~%string[] controllers~%# A list of the available control gain presets for the current controller, the first element is the active preset~%string[] gains~%# A list of the available trajectory tracking (pre-shaping) algorithms, the first element is the active algorithm~%string[] trackers~%# A list of the available dynamic constraint presets for the current tracker, the first element is the active preset~%string[] constraints~%# True if the null (no-output) tracker is active~%bool null_tracker~%# Flight time~%uint32 secs_flown~%~%# Frequency of receiving the Estimation Manager diagnostics~%float32 odom_hz~%# Display color (for TUI visualization purposes)~%int16 odom_color~%# X position of the UAV in the current estimation coordinate frame~%float32 odom_x~%# Y position of the UAV in the current estimation coordinate frame~%float32 odom_y~%# Z position of the UAV in the current estimation coordinate frame~%float32 odom_z~%# Heading of the UAV in the current estimation coordinate frame~%float32 odom_hdg~%# Name of the current estimation coordinate frame~%string odom_frame~%# A list of the available ego-state estimation sources, the first element is the active source~%string[] odom_estimators~%# Name of the current source used for estimation of the UAV's horizontal position ~%string horizontal_estimator~%# Name of the current source used for estimation of the UAV's vertical position ~%string vertical_estimator~%# Name of the current source used for estimation of the UAV's heading~%string heading_estimator~%# Name of the current source used for estimation of the UAV's above ground level~%string agl_estimator~%# Maximal allowed Z coordinate of the UAV~%float32 max_flight_z~%~%# Setpoint X position of the UAV in the current estimation coordinate frame~%float32 cmd_x~%# Setpoint Y position of the UAV in the current estimation coordinate frame~%float32 cmd_y~%# Setpoint Z position of the UAV in the current estimation coordinate frame~%float32 cmd_z~%# Setpoint heading of the UAV in the current estimation coordinate frame~%float32 cmd_hdg~%~%# Current load of the CPU in percent relative all CPU cores (i.e. a maximal load of a 2-core CPU is 100.0)~%float32 cpu_load~%# Current load of the CPU in percent relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)~%float32 cpu_load_total~%# Current average frequency of the CPU in gigahertz~%float32 cpu_ghz~%# Current temperature of the CPU in degrees Celsius (or zero if not supported by the current system)~%float32 cpu_temperature~%# The amount of free RAM in gigabytes~%float32 free_ram~%# The total available RAM in gigabytes~%float32 total_ram~%# The amount of free disk space in gigabytes~%int32 free_hdd~%~%# Frequency of receiving the Hardware API diagnostics~%float32 hw_api_hz~%# Display color (for TUI visualization purposes)~%int16 hw_api_color~%# Frequency of receiving the battery status from the Hardware API~%float32 hw_api_battery_hz~%# Frequency of receiving the Hardware API status~%float32 hw_api_state_hz~%# Frequency of receiving the Hardware API commanded setpoint~%float32 hw_api_cmd_hz~%# Name of the current mode reported by the Hardware API (e.g.: \"OFFBOARD\", \"AUTO.LAND\", etc.)~%string hw_api_mode~%# True if the vehicle is armed (actuator movement is enabled)~%bool hw_api_armed~%# True if the GPS data is being received correctly~%bool hw_api_gnss_ok~%# A measure of the GPS position quality~%float32 hw_api_gnss_qual~%# Frequency of receiving the magnetic field norm~%float32 mag_norm_hz~%~%# Gnss fix type~%# 0 -> No GPS connected~%# 1 -> No position information, GPS is connected~%# 2 -> 2D position~%# 3 -> 3D position~%# 4 -> DGPS/SBAS aided 3D position~%# 5 -> TK float, 3D position~%# 6 -> TK Fixed, 3D position~%# 7 -> Static fixed, typically used for base stations~%# 8 -> PPP, 3D position~%uint8 hw_api_gnss_fix_type~%~%# Number of satellites used for gnss solution~%uint8 hw_api_gnss_num_sats~%~%# Estimated accuracy of the gnss solution (in meters)~%float32 hw_api_gnss_pos_acc~%~%# Rate of the gnss status message~%float32 hw_api_gnss_status_hz~%~%# Norm of the  magnetic field (in Gauss, 10Gauss = 1mT)~%float32 mag_norm~%# Battery voltage in volts~%float32 battery_volt~%# Battery current in amperes~%float32 battery_curr~%# Estimate of the drained battery power in watthours~%float32 battery_wh_drained~%# Current collective thrust relative to max. thrust (i.e. between 0 and 1)~%float32 thrust~%# Current estimated mass of the vehicle~%float32 mass_estimate~%# Nominal mass of the vehicle~%float32 mass_set~%~%# A list of custom topics to be displayed in the TUI~%CustomTopic[] custom_topics~%# A list of custom strings to be displayed in the TUI~%string[] custom_string_outputs~%~%# A list of node names and a list of their corresponding CPU loads relative to a single CPU core~%NodeCpuLoad node_cpu_loads~%~%# True if the UAV is flying and there are no emergency or safety maneuvers taking place~%bool flying_normally~%# True if the UAV is currently controlled by the RC~%bool rc_mode~%# True if the UAV is currently flying to a goal waypoint~%bool have_goal~%# True if the UAV is currently following a trajectory (implies have_goal == true)~%bool tracking_trajectory~%# True if the control pipeline is ready to receive and execute waypoints and trajectories~%bool callbacks_enabled~%# True if collision avoidance with other UAVs using the NimbRo network is enabled~%bool collision_avoidance_enabled~%# True if the UAV is currently performing a maneuver to avoid a collision with another UAV~%bool avoiding_collision~%# True if the UAV is ready to take off~%bool automatic_start_can_takeoff~%~%# The number of other UAVs whose predicted trajectory is available to this one (for collision avoidance purposes)~%uint16 num_other_uavs~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/CustomTopic~%string topic_name~%float32 topic_hz~%int16 topic_color~%~%================================================================================~%MSG: mrs_msgs/NodeCpuLoad~%# A list of names of all ROS nodes running on this UAV~%string[] node_names~%# A list of the corresponding CPU loads of these nodes relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)~%float32[] cpu_loads~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <UavStatus>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'uav_name))
     4 (cl:length (cl:slot-value msg 'uav_type))
     4 (cl:length (cl:slot-value msg 'uav_mass))
     4
     2
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'controllers) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'gains) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'trackers) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'constraints) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     1
     4
     4
     2
     4
     4
     4
     4
     4 (cl:length (cl:slot-value msg 'odom_frame))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'odom_estimators) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:length (cl:slot-value msg 'horizontal_estimator))
     4 (cl:length (cl:slot-value msg 'vertical_estimator))
     4 (cl:length (cl:slot-value msg 'heading_estimator))
     4 (cl:length (cl:slot-value msg 'agl_estimator))
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4
     2
     4
     4
     4
     4 (cl:length (cl:slot-value msg 'hw_api_mode))
     1
     1
     4
     4
     1
     1
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'custom_topics) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'custom_string_outputs) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'node_cpu_loads))
     1
     1
     1
     1
     1
     1
     1
     1
     2
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <UavStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'UavStatus
    (cl:cons ':header (header msg))
    (cl:cons ':uav_name (uav_name msg))
    (cl:cons ':uav_type (uav_type msg))
    (cl:cons ':uav_mass (uav_mass msg))
    (cl:cons ':control_manager_diag_hz (control_manager_diag_hz msg))
    (cl:cons ':control_manager_diag_color (control_manager_diag_color msg))
    (cl:cons ':controllers (controllers msg))
    (cl:cons ':gains (gains msg))
    (cl:cons ':trackers (trackers msg))
    (cl:cons ':constraints (constraints msg))
    (cl:cons ':null_tracker (null_tracker msg))
    (cl:cons ':secs_flown (secs_flown msg))
    (cl:cons ':odom_hz (odom_hz msg))
    (cl:cons ':odom_color (odom_color msg))
    (cl:cons ':odom_x (odom_x msg))
    (cl:cons ':odom_y (odom_y msg))
    (cl:cons ':odom_z (odom_z msg))
    (cl:cons ':odom_hdg (odom_hdg msg))
    (cl:cons ':odom_frame (odom_frame msg))
    (cl:cons ':odom_estimators (odom_estimators msg))
    (cl:cons ':horizontal_estimator (horizontal_estimator msg))
    (cl:cons ':vertical_estimator (vertical_estimator msg))
    (cl:cons ':heading_estimator (heading_estimator msg))
    (cl:cons ':agl_estimator (agl_estimator msg))
    (cl:cons ':max_flight_z (max_flight_z msg))
    (cl:cons ':cmd_x (cmd_x msg))
    (cl:cons ':cmd_y (cmd_y msg))
    (cl:cons ':cmd_z (cmd_z msg))
    (cl:cons ':cmd_hdg (cmd_hdg msg))
    (cl:cons ':cpu_load (cpu_load msg))
    (cl:cons ':cpu_load_total (cpu_load_total msg))
    (cl:cons ':cpu_ghz (cpu_ghz msg))
    (cl:cons ':cpu_temperature (cpu_temperature msg))
    (cl:cons ':free_ram (free_ram msg))
    (cl:cons ':total_ram (total_ram msg))
    (cl:cons ':free_hdd (free_hdd msg))
    (cl:cons ':hw_api_hz (hw_api_hz msg))
    (cl:cons ':hw_api_color (hw_api_color msg))
    (cl:cons ':hw_api_battery_hz (hw_api_battery_hz msg))
    (cl:cons ':hw_api_state_hz (hw_api_state_hz msg))
    (cl:cons ':hw_api_cmd_hz (hw_api_cmd_hz msg))
    (cl:cons ':hw_api_mode (hw_api_mode msg))
    (cl:cons ':hw_api_armed (hw_api_armed msg))
    (cl:cons ':hw_api_gnss_ok (hw_api_gnss_ok msg))
    (cl:cons ':hw_api_gnss_qual (hw_api_gnss_qual msg))
    (cl:cons ':mag_norm_hz (mag_norm_hz msg))
    (cl:cons ':hw_api_gnss_fix_type (hw_api_gnss_fix_type msg))
    (cl:cons ':hw_api_gnss_num_sats (hw_api_gnss_num_sats msg))
    (cl:cons ':hw_api_gnss_pos_acc (hw_api_gnss_pos_acc msg))
    (cl:cons ':hw_api_gnss_status_hz (hw_api_gnss_status_hz msg))
    (cl:cons ':mag_norm (mag_norm msg))
    (cl:cons ':battery_volt (battery_volt msg))
    (cl:cons ':battery_curr (battery_curr msg))
    (cl:cons ':battery_wh_drained (battery_wh_drained msg))
    (cl:cons ':thrust (thrust msg))
    (cl:cons ':mass_estimate (mass_estimate msg))
    (cl:cons ':mass_set (mass_set msg))
    (cl:cons ':custom_topics (custom_topics msg))
    (cl:cons ':custom_string_outputs (custom_string_outputs msg))
    (cl:cons ':node_cpu_loads (node_cpu_loads msg))
    (cl:cons ':flying_normally (flying_normally msg))
    (cl:cons ':rc_mode (rc_mode msg))
    (cl:cons ':have_goal (have_goal msg))
    (cl:cons ':tracking_trajectory (tracking_trajectory msg))
    (cl:cons ':callbacks_enabled (callbacks_enabled msg))
    (cl:cons ':collision_avoidance_enabled (collision_avoidance_enabled msg))
    (cl:cons ':avoiding_collision (avoiding_collision msg))
    (cl:cons ':automatic_start_can_takeoff (automatic_start_can_takeoff msg))
    (cl:cons ':num_other_uavs (num_other_uavs msg))
))
