(cl:in-package mrs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          CONNECTED-VAL
          CONNECTED
          ARMED-VAL
          ARMED
          OFFBOARD-VAL
          OFFBOARD
          MODE-VAL
          MODE
))