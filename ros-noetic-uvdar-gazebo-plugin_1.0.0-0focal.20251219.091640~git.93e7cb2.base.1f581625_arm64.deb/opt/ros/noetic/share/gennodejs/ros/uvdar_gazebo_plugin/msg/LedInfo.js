// Auto-generated. Do not edit!

// (in-package uvdar_gazebo_plugin.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class LedInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.seq_bitrate = null;
      this.mes_bitrate = null;
      this.ID = null;
      this.link_name = null;
      this.device_id = null;
      this.active = null;
      this.mode = null;
    }
    else {
      if (initObj.hasOwnProperty('seq_bitrate')) {
        this.seq_bitrate = initObj.seq_bitrate
      }
      else {
        this.seq_bitrate = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('mes_bitrate')) {
        this.mes_bitrate = initObj.mes_bitrate
      }
      else {
        this.mes_bitrate = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('ID')) {
        this.ID = initObj.ID
      }
      else {
        this.ID = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('link_name')) {
        this.link_name = initObj.link_name
      }
      else {
        this.link_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('device_id')) {
        this.device_id = initObj.device_id
      }
      else {
        this.device_id = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('active')) {
        this.active = initObj.active
      }
      else {
        this.active = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = new std_msgs.msg.Int32();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LedInfo
    // Serialize message field [seq_bitrate]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.seq_bitrate, buffer, bufferOffset);
    // Serialize message field [mes_bitrate]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.mes_bitrate, buffer, bufferOffset);
    // Serialize message field [ID]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.ID, buffer, bufferOffset);
    // Serialize message field [link_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.link_name, buffer, bufferOffset);
    // Serialize message field [device_id]
    bufferOffset = std_msgs.msg.String.serialize(obj.device_id, buffer, bufferOffset);
    // Serialize message field [active]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.active, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LedInfo
    let len;
    let data = new LedInfo(null);
    // Deserialize message field [seq_bitrate]
    data.seq_bitrate = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [mes_bitrate]
    data.mes_bitrate = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [ID]
    data.ID = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [link_name]
    data.link_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [device_id]
    data.device_id = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [active]
    data.active = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.link_name);
    length += std_msgs.msg.String.getMessageSize(object.device_id);
    return length + 25;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_gazebo_plugin/LedInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '54979e00e6253418143263d0883238a0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Float64 seq_bitrate
    std_msgs/Float64 mes_bitrate
    std_msgs/Int32 ID
    std_msgs/String link_name
    std_msgs/String device_id
    std_msgs/Bool active
    std_msgs/Int32 mode
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LedInfo(null);
    if (msg.seq_bitrate !== undefined) {
      resolved.seq_bitrate = std_msgs.msg.Float64.Resolve(msg.seq_bitrate)
    }
    else {
      resolved.seq_bitrate = new std_msgs.msg.Float64()
    }

    if (msg.mes_bitrate !== undefined) {
      resolved.mes_bitrate = std_msgs.msg.Float64.Resolve(msg.mes_bitrate)
    }
    else {
      resolved.mes_bitrate = new std_msgs.msg.Float64()
    }

    if (msg.ID !== undefined) {
      resolved.ID = std_msgs.msg.Int32.Resolve(msg.ID)
    }
    else {
      resolved.ID = new std_msgs.msg.Int32()
    }

    if (msg.link_name !== undefined) {
      resolved.link_name = std_msgs.msg.String.Resolve(msg.link_name)
    }
    else {
      resolved.link_name = new std_msgs.msg.String()
    }

    if (msg.device_id !== undefined) {
      resolved.device_id = std_msgs.msg.String.Resolve(msg.device_id)
    }
    else {
      resolved.device_id = new std_msgs.msg.String()
    }

    if (msg.active !== undefined) {
      resolved.active = std_msgs.msg.Bool.Resolve(msg.active)
    }
    else {
      resolved.active = new std_msgs.msg.Bool()
    }

    if (msg.mode !== undefined) {
      resolved.mode = std_msgs.msg.Int32.Resolve(msg.mode)
    }
    else {
      resolved.mode = new std_msgs.msg.Int32()
    }

    return resolved;
    }
};

module.exports = LedInfo;
