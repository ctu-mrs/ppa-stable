// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let AMISeqVariables = require('./AMISeqVariables.js');

//-----------------------------------------------------------

class AMIAllSequences {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sequences = null;
    }
    else {
      if (initObj.hasOwnProperty('sequences')) {
        this.sequences = initObj.sequences
      }
      else {
        this.sequences = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AMIAllSequences
    // Serialize message field [sequences]
    // Serialize the length for message field [sequences]
    bufferOffset = _serializer.uint32(obj.sequences.length, buffer, bufferOffset);
    obj.sequences.forEach((val) => {
      bufferOffset = AMISeqVariables.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AMIAllSequences
    let len;
    let data = new AMIAllSequences(null);
    // Deserialize message field [sequences]
    // Deserialize array length for message field [sequences]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.sequences = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.sequences[i] = AMISeqVariables.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.sequences.forEach((val) => {
      length += AMISeqVariables.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/AMIAllSequences';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8ca86b1edaa8fc473b9ded1f007b5901';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uvdar_core/AMISeqVariables[] sequences
    ================================================================================
    MSG: uvdar_core/AMISeqVariables
    time inserted_time
    int8 signal_id
    bool[] extended_search
    bool[] poly_reg_computed
    uvdar_core/Point2DWithFloat predicted_point
    uvdar_core/Point2DWithFloat confidence_interval
    float32[] x_coeff_reg
    float32[] y_coeff_reg
    uvdar_core/AMISeqPoint[] sequence
    ================================================================================
    MSG: uvdar_core/Point2DWithFloat
    float64 x
    float64 y
    float64 value
    ================================================================================
    MSG: uvdar_core/AMISeqPoint
    time insert_time
    uvdar_core/Point2DWithFloat point
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AMIAllSequences(null);
    if (msg.sequences !== undefined) {
      resolved.sequences = new Array(msg.sequences.length);
      for (let i = 0; i < resolved.sequences.length; ++i) {
        resolved.sequences[i] = AMISeqVariables.Resolve(msg.sequences[i]);
      }
    }
    else {
      resolved.sequences = []
    }

    return resolved;
    }
};

module.exports = AMIAllSequences;
