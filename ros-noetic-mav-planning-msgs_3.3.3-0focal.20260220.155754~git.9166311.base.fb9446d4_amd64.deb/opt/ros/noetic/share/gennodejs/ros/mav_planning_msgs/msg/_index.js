
"use strict";

let PolynomialSegment4D = require('./PolynomialSegment4D.js');
let PolygonWithHoles = require('./PolygonWithHoles.js');
let Polygon2D = require('./Polygon2D.js');
let PointCloudWithPose = require('./PointCloudWithPose.js');
let PolynomialTrajectory = require('./PolynomialTrajectory.js');
let PolygonWithHolesStamped = require('./PolygonWithHolesStamped.js');
let Point2D = require('./Point2D.js');
let PolynomialSegment = require('./PolynomialSegment.js');
let PolynomialTrajectory4D = require('./PolynomialTrajectory4D.js');

module.exports = {
  PolynomialSegment4D: PolynomialSegment4D,
  PolygonWithHoles: PolygonWithHoles,
  Polygon2D: Polygon2D,
  PointCloudWithPose: PointCloudWithPose,
  PolynomialTrajectory: PolynomialTrajectory,
  PolygonWithHolesStamped: PolygonWithHolesStamped,
  Point2D: Point2D,
  PolynomialSegment: PolynomialSegment,
  PolynomialTrajectory4D: PolynomialTrajectory4D,
};
