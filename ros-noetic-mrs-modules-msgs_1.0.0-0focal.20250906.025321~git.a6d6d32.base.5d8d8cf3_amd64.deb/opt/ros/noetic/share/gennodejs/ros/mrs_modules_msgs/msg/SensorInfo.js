// Auto-generated. Do not edit!

// (in-package mrs_modules_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SensorInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.topic = null;
      this.type = null;
      this.expected_rate = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('topic')) {
        this.topic = initObj.topic
      }
      else {
        this.topic = '';
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('expected_rate')) {
        this.expected_rate = initObj.expected_rate
      }
      else {
        this.expected_rate = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SensorInfo
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [topic]
    bufferOffset = _serializer.string(obj.topic, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [expected_rate]
    bufferOffset = _serializer.float32(obj.expected_rate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SensorInfo
    let len;
    let data = new SensorInfo(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [topic]
    data.topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [expected_rate]
    data.expected_rate = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    length += _getByteLength(object.topic);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_modules_msgs/SensorInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '941a2ed7a40c7cefe15477f16f455b79';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # name of the sensor
    string name
    
    string topic
    
    # sensor type
    uint8 SENSOR_TYPE_UNKNOWN  = 0
    uint8 SENSOR_TYPE_CAMERA   = 1
    uint8 SENSOR_TYPE_LIDAR_1D = 2
    uint8 SENSOR_TYPE_LIDAR_2D = 3
    uint8 SENSOR_TYPE_LIDAR_3D = 4
    uint8 type
    
    float32 expected_rate
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SensorInfo(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.topic !== undefined) {
      resolved.topic = msg.topic;
    }
    else {
      resolved.topic = ''
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.expected_rate !== undefined) {
      resolved.expected_rate = msg.expected_rate;
    }
    else {
      resolved.expected_rate = 0.0
    }

    return resolved;
    }
};

// Constants for message
SensorInfo.Constants = {
  SENSOR_TYPE_UNKNOWN: 0,
  SENSOR_TYPE_CAMERA: 1,
  SENSOR_TYPE_LIDAR_1D: 2,
  SENSOR_TYPE_LIDAR_2D: 3,
  SENSOR_TYPE_LIDAR_3D: 4,
}

module.exports = SensorInfo;
