
"use strict";

let Logger = require('./Logger.js');

module.exports = {
  Logger: Logger,
};
