; Auto-generated. Do not edit!


(cl:in-package nimbro_log_transport-msg)


;//! \htmlinclude LogBlock.msg.html

(cl:defclass <LogBlock> (roslisp-msg-protocol:ros-message)
  ((key
    :reader key
    :initarg :key
    :type cl:integer
    :initform 0)
   (msgs
    :reader msgs
    :initarg :msgs
    :type (cl:vector nimbro_log_transport-msg:LogMsg)
   :initform (cl:make-array 0 :element-type 'nimbro_log_transport-msg:LogMsg :initial-element (cl:make-instance 'nimbro_log_transport-msg:LogMsg))))
)

(cl:defclass LogBlock (<LogBlock>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LogBlock>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LogBlock)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_log_transport-msg:<LogBlock> is deprecated: use nimbro_log_transport-msg:LogBlock instead.")))

(cl:ensure-generic-function 'key-val :lambda-list '(m))
(cl:defmethod key-val ((m <LogBlock>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_log_transport-msg:key-val is deprecated.  Use nimbro_log_transport-msg:key instead.")
  (key m))

(cl:ensure-generic-function 'msgs-val :lambda-list '(m))
(cl:defmethod msgs-val ((m <LogBlock>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_log_transport-msg:msgs-val is deprecated.  Use nimbro_log_transport-msg:msgs instead.")
  (msgs m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LogBlock>) ostream)
  "Serializes a message object of type '<LogBlock>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'key)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'key)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'msgs))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'msgs))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LogBlock>) istream)
  "Deserializes a message object of type '<LogBlock>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'key)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'key)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'msgs) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'msgs)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_log_transport-msg:LogMsg))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LogBlock>)))
  "Returns string type for a message object of type '<LogBlock>"
  "nimbro_log_transport/LogBlock")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LogBlock)))
  "Returns string type for a message object of type 'LogBlock"
  "nimbro_log_transport/LogBlock")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LogBlock>)))
  "Returns md5sum for a message object of type '<LogBlock>"
  "cbc45b9d793ed6ba153682121adafa6b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LogBlock)))
  "Returns md5sum for a message object of type 'LogBlock"
  "cbc45b9d793ed6ba153682121adafa6b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LogBlock>)))
  "Returns full string definition for message of type '<LogBlock>"
  (cl:format cl:nil "~%# Random key unique for this sender~%uint64 key~%~%# List of messages in this block~%LogMsg[] msgs~%~%================================================================================~%MSG: nimbro_log_transport/LogMsg~%uint32 id~%rosgraph_msgs/Log msg~%================================================================================~%MSG: rosgraph_msgs/Log~%##~%## Severity level constants~%##~%byte DEBUG=1 #debug level~%byte INFO=2  #general level~%byte WARN=4  #warning level~%byte ERROR=8 #error level~%byte FATAL=16 #fatal/critical level~%##~%## Fields~%##~%Header header~%byte level~%string name # name of the node~%string msg # message ~%string file # file the message came from~%string function # function the message came from~%uint32 line # line the message came from~%string[] topics # topic names that the node publishes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LogBlock)))
  "Returns full string definition for message of type 'LogBlock"
  (cl:format cl:nil "~%# Random key unique for this sender~%uint64 key~%~%# List of messages in this block~%LogMsg[] msgs~%~%================================================================================~%MSG: nimbro_log_transport/LogMsg~%uint32 id~%rosgraph_msgs/Log msg~%================================================================================~%MSG: rosgraph_msgs/Log~%##~%## Severity level constants~%##~%byte DEBUG=1 #debug level~%byte INFO=2  #general level~%byte WARN=4  #warning level~%byte ERROR=8 #error level~%byte FATAL=16 #fatal/critical level~%##~%## Fields~%##~%Header header~%byte level~%string name # name of the node~%string msg # message ~%string file # file the message came from~%string function # function the message came from~%uint32 line # line the message came from~%string[] topics # topic names that the node publishes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LogBlock>))
  (cl:+ 0
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'msgs) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LogBlock>))
  "Converts a ROS message object to a list"
  (cl:list 'LogBlock
    (cl:cons ':key (key msg))
    (cl:cons ':msgs (msgs msg))
))
