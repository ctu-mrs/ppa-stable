
"use strict";

let GPSINPUT = require('./GPSINPUT.js');
let ESCStatus = require('./ESCStatus.js');
let Thrust = require('./Thrust.js');
let Trajectory = require('./Trajectory.js');
let HomePosition = require('./HomePosition.js');
let Altitude = require('./Altitude.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let RTCM = require('./RTCM.js');
let WaypointList = require('./WaypointList.js');
let ESCInfo = require('./ESCInfo.js');
let Waypoint = require('./Waypoint.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let RCOut = require('./RCOut.js');
let FileEntry = require('./FileEntry.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let HilGPS = require('./HilGPS.js');
let ParamValue = require('./ParamValue.js');
let VFR_HUD = require('./VFR_HUD.js');
let LandingTarget = require('./LandingTarget.js');
let HilSensor = require('./HilSensor.js');
let CommandCode = require('./CommandCode.js');
let HilControls = require('./HilControls.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let StatusText = require('./StatusText.js');
let TerrainReport = require('./TerrainReport.js');
let Mavlink = require('./Mavlink.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let BatteryStatus = require('./BatteryStatus.js');
let WaypointReached = require('./WaypointReached.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let Param = require('./Param.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let VehicleInfo = require('./VehicleInfo.js');
let Vibration = require('./Vibration.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let Tunnel = require('./Tunnel.js');
let GPSRTK = require('./GPSRTK.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let LogEntry = require('./LogEntry.js');
let ActuatorControl = require('./ActuatorControl.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let GPSRAW = require('./GPSRAW.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let RCIn = require('./RCIn.js');
let ManualControl = require('./ManualControl.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let LogData = require('./LogData.js');
let DebugValue = require('./DebugValue.js');
let PlayTuneV2 = require('./PlayTuneV2.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let RadioStatus = require('./RadioStatus.js');
let PositionTarget = require('./PositionTarget.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let MountControl = require('./MountControl.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let ExtendedState = require('./ExtendedState.js');
let RTKBaseline = require('./RTKBaseline.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');
let State = require('./State.js');

module.exports = {
  GPSINPUT: GPSINPUT,
  ESCStatus: ESCStatus,
  Thrust: Thrust,
  Trajectory: Trajectory,
  HomePosition: HomePosition,
  Altitude: Altitude,
  OpticalFlowRad: OpticalFlowRad,
  RTCM: RTCM,
  WaypointList: WaypointList,
  ESCInfo: ESCInfo,
  Waypoint: Waypoint,
  ESCTelemetryItem: ESCTelemetryItem,
  CamIMUStamp: CamIMUStamp,
  RCOut: RCOut,
  FileEntry: FileEntry,
  TimesyncStatus: TimesyncStatus,
  HilGPS: HilGPS,
  ParamValue: ParamValue,
  VFR_HUD: VFR_HUD,
  LandingTarget: LandingTarget,
  HilSensor: HilSensor,
  CommandCode: CommandCode,
  HilControls: HilControls,
  NavControllerOutput: NavControllerOutput,
  StatusText: StatusText,
  TerrainReport: TerrainReport,
  Mavlink: Mavlink,
  GlobalPositionTarget: GlobalPositionTarget,
  OverrideRCIn: OverrideRCIn,
  BatteryStatus: BatteryStatus,
  WaypointReached: WaypointReached,
  WheelOdomStamped: WheelOdomStamped,
  Param: Param,
  ESCStatusItem: ESCStatusItem,
  VehicleInfo: VehicleInfo,
  Vibration: Vibration,
  CompanionProcessStatus: CompanionProcessStatus,
  Tunnel: Tunnel,
  GPSRTK: GPSRTK,
  HilStateQuaternion: HilStateQuaternion,
  ESCInfoItem: ESCInfoItem,
  OnboardComputerStatus: OnboardComputerStatus,
  LogEntry: LogEntry,
  ActuatorControl: ActuatorControl,
  EstimatorStatus: EstimatorStatus,
  GPSRAW: GPSRAW,
  ADSBVehicle: ADSBVehicle,
  RCIn: RCIn,
  ManualControl: ManualControl,
  AttitudeTarget: AttitudeTarget,
  LogData: LogData,
  DebugValue: DebugValue,
  PlayTuneV2: PlayTuneV2,
  ESCTelemetry: ESCTelemetry,
  RadioStatus: RadioStatus,
  PositionTarget: PositionTarget,
  HilActuatorControls: HilActuatorControls,
  MountControl: MountControl,
  MagnetometerReporter: MagnetometerReporter,
  ExtendedState: ExtendedState,
  RTKBaseline: RTKBaseline,
  CameraImageCaptured: CameraImageCaptured,
  State: State,
};
