set(mrs_gazebo_common_resources_MESSAGE_FILES "msg/LivoxCustomPoint.msg;msg/LivoxCustomMsg.msg")
set(mrs_gazebo_common_resources_SERVICE_FILES "")
