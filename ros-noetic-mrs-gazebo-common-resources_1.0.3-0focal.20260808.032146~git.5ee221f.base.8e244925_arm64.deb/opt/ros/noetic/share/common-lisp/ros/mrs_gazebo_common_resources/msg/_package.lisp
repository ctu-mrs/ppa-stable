(cl:defpackage mrs_gazebo_common_resources-msg
  (:use )
  (:export
   "<LIVOXCUSTOMMSG>"
   "LIVOXCUSTOMMSG"
   "<LIVOXCUSTOMPOINT>"
   "LIVOXCUSTOMPOINT"
  ))

