(cl:in-package mrs_modules_msgs-msg)
(cl:export '(PRN-VAL
          PRN
          ELEVATION-VAL
          ELEVATION
          AZIMUTH-VAL
          AZIMUTH
          SNR-VAL
          SNR
))