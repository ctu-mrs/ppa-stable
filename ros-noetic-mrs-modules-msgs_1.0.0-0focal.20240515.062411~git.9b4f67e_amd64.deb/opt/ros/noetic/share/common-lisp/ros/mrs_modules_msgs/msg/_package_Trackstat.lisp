(cl:in-package mrs_modules_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          SOLUTION_STATUS-VAL
          SOLUTION_STATUS
          POSITION_TYPE-VAL
          POSITION_TYPE
          CUTOFF-VAL
          CUTOFF
          CHANNELS-VAL
          CHANNELS
))