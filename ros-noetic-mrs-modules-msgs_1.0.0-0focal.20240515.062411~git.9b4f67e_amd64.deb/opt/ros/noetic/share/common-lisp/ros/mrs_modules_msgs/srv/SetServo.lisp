; Auto-generated. Do not edit!


(cl:in-package mrs_modules_msgs-srv)


;//! \htmlinclude SetServo-request.msg.html

(cl:defclass <SetServo-request> (roslisp-msg-protocol:ros-message)
  ((servo1_val
    :reader servo1_val
    :initarg :servo1_val
    :type cl:fixnum
    :initform 0)
   (servo2_val
    :reader servo2_val
    :initarg :servo2_val
    :type cl:fixnum
    :initform 0))
)

(cl:defclass SetServo-request (<SetServo-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetServo-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetServo-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-srv:<SetServo-request> is deprecated: use mrs_modules_msgs-srv:SetServo-request instead.")))

(cl:ensure-generic-function 'servo1_val-val :lambda-list '(m))
(cl:defmethod servo1_val-val ((m <SetServo-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:servo1_val-val is deprecated.  Use mrs_modules_msgs-srv:servo1_val instead.")
  (servo1_val m))

(cl:ensure-generic-function 'servo2_val-val :lambda-list '(m))
(cl:defmethod servo2_val-val ((m <SetServo-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:servo2_val-val is deprecated.  Use mrs_modules_msgs-srv:servo2_val instead.")
  (servo2_val m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetServo-request>) ostream)
  "Serializes a message object of type '<SetServo-request>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'servo1_val)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'servo1_val)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'servo2_val)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'servo2_val)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetServo-request>) istream)
  "Deserializes a message object of type '<SetServo-request>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'servo1_val)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'servo1_val)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'servo2_val)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'servo2_val)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetServo-request>)))
  "Returns string type for a service object of type '<SetServo-request>"
  "mrs_modules_msgs/SetServoRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetServo-request)))
  "Returns string type for a service object of type 'SetServo-request"
  "mrs_modules_msgs/SetServoRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetServo-request>)))
  "Returns md5sum for a message object of type '<SetServo-request>"
  "ed8f6cd1ece4f036fb5f26c768d4c2e3")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetServo-request)))
  "Returns md5sum for a message object of type 'SetServo-request"
  "ed8f6cd1ece4f036fb5f26c768d4c2e3")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetServo-request>)))
  "Returns full string definition for message of type '<SetServo-request>"
  (cl:format cl:nil "uint16 servo1_val~%uint16 servo2_val~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetServo-request)))
  "Returns full string definition for message of type 'SetServo-request"
  (cl:format cl:nil "uint16 servo1_val~%uint16 servo2_val~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetServo-request>))
  (cl:+ 0
     2
     2
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetServo-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetServo-request
    (cl:cons ':servo1_val (servo1_val msg))
    (cl:cons ':servo2_val (servo2_val msg))
))
;//! \htmlinclude SetServo-response.msg.html

(cl:defclass <SetServo-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass SetServo-response (<SetServo-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetServo-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetServo-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-srv:<SetServo-response> is deprecated: use mrs_modules_msgs-srv:SetServo-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SetServo-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:success-val is deprecated.  Use mrs_modules_msgs-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SetServo-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:message-val is deprecated.  Use mrs_modules_msgs-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetServo-response>) ostream)
  "Serializes a message object of type '<SetServo-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetServo-response>) istream)
  "Deserializes a message object of type '<SetServo-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetServo-response>)))
  "Returns string type for a service object of type '<SetServo-response>"
  "mrs_modules_msgs/SetServoResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetServo-response)))
  "Returns string type for a service object of type 'SetServo-response"
  "mrs_modules_msgs/SetServoResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetServo-response>)))
  "Returns md5sum for a message object of type '<SetServo-response>"
  "ed8f6cd1ece4f036fb5f26c768d4c2e3")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetServo-response)))
  "Returns md5sum for a message object of type 'SetServo-response"
  "ed8f6cd1ece4f036fb5f26c768d4c2e3")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetServo-response>)))
  "Returns full string definition for message of type '<SetServo-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetServo-response)))
  "Returns full string definition for message of type 'SetServo-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetServo-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetServo-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetServo-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetServo)))
  'SetServo-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetServo)))
  'SetServo-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetServo)))
  "Returns string type for a service object of type '<SetServo>"
  "mrs_modules_msgs/SetServo")