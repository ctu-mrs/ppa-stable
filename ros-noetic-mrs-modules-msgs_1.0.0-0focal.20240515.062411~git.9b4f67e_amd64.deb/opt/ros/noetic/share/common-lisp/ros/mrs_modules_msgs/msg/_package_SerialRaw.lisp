(cl:in-package mrs_modules_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          PAYLOAD-VAL
          PAYLOAD
))