; Auto-generated. Do not edit!


(cl:in-package uvdar_core-srv)


;//! \htmlinclude SetInts-request.msg.html

(cl:defclass <SetInts-request> (roslisp-msg-protocol:ros-message)
  ((value
    :reader value
    :initarg :value
    :type (cl:vector cl:integer)
   :initform (cl:make-array 0 :element-type 'cl:integer :initial-element 0)))
)

(cl:defclass SetInts-request (<SetInts-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetInts-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetInts-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-srv:<SetInts-request> is deprecated: use uvdar_core-srv:SetInts-request instead.")))

(cl:ensure-generic-function 'value-val :lambda-list '(m))
(cl:defmethod value-val ((m <SetInts-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:value-val is deprecated.  Use uvdar_core-srv:value instead.")
  (value m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetInts-request>) ostream)
  "Serializes a message object of type '<SetInts-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let* ((signed ele) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 18446744073709551616) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) unsigned) ostream)
    ))
   (cl:slot-value msg 'value))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetInts-request>) istream)
  "Deserializes a message object of type '<SetInts-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'value) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'value)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) unsigned) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:if (cl:< unsigned 9223372036854775808) unsigned (cl:- unsigned 18446744073709551616)))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetInts-request>)))
  "Returns string type for a service object of type '<SetInts-request>"
  "uvdar_core/SetIntsRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetInts-request)))
  "Returns string type for a service object of type 'SetInts-request"
  "uvdar_core/SetIntsRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetInts-request>)))
  "Returns md5sum for a message object of type '<SetInts-request>"
  "6202770e5a3e35d8e4b9f0e599b35d9b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetInts-request)))
  "Returns md5sum for a message object of type 'SetInts-request"
  "6202770e5a3e35d8e4b9f0e599b35d9b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetInts-request>)))
  "Returns full string definition for message of type '<SetInts-request>"
  (cl:format cl:nil "int64[] value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetInts-request)))
  "Returns full string definition for message of type 'SetInts-request"
  (cl:format cl:nil "int64[] value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetInts-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'value) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetInts-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetInts-request
    (cl:cons ':value (value msg))
))
;//! \htmlinclude SetInts-response.msg.html

(cl:defclass <SetInts-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass SetInts-response (<SetInts-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetInts-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetInts-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-srv:<SetInts-response> is deprecated: use uvdar_core-srv:SetInts-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SetInts-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:success-val is deprecated.  Use uvdar_core-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SetInts-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:message-val is deprecated.  Use uvdar_core-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetInts-response>) ostream)
  "Serializes a message object of type '<SetInts-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetInts-response>) istream)
  "Deserializes a message object of type '<SetInts-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetInts-response>)))
  "Returns string type for a service object of type '<SetInts-response>"
  "uvdar_core/SetIntsResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetInts-response)))
  "Returns string type for a service object of type 'SetInts-response"
  "uvdar_core/SetIntsResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetInts-response>)))
  "Returns md5sum for a message object of type '<SetInts-response>"
  "6202770e5a3e35d8e4b9f0e599b35d9b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetInts-response)))
  "Returns md5sum for a message object of type 'SetInts-response"
  "6202770e5a3e35d8e4b9f0e599b35d9b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetInts-response>)))
  "Returns full string definition for message of type '<SetInts-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetInts-response)))
  "Returns full string definition for message of type 'SetInts-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetInts-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetInts-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetInts-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetInts)))
  'SetInts-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetInts)))
  'SetInts-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetInts)))
  "Returns string type for a service object of type '<SetInts>"
  "uvdar_core/SetInts")