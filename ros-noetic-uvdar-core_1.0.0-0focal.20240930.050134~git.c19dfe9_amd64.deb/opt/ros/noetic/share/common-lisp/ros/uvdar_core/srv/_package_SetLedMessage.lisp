(cl:in-package uvdar_core-srv)
(cl:export '(DATA_FRAME-VAL
          DATA_FRAME
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))