; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude AMISeqPoint.msg.html

(cl:defclass <AMISeqPoint> (roslisp-msg-protocol:ros-message)
  ((insert_time
    :reader insert_time
    :initarg :insert_time
    :type cl:real
    :initform 0)
   (point
    :reader point
    :initarg :point
    :type uvdar_core-msg:Point2DWithFloat
    :initform (cl:make-instance 'uvdar_core-msg:Point2DWithFloat)))
)

(cl:defclass AMISeqPoint (<AMISeqPoint>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AMISeqPoint>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AMISeqPoint)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<AMISeqPoint> is deprecated: use uvdar_core-msg:AMISeqPoint instead.")))

(cl:ensure-generic-function 'insert_time-val :lambda-list '(m))
(cl:defmethod insert_time-val ((m <AMISeqPoint>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:insert_time-val is deprecated.  Use uvdar_core-msg:insert_time instead.")
  (insert_time m))

(cl:ensure-generic-function 'point-val :lambda-list '(m))
(cl:defmethod point-val ((m <AMISeqPoint>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:point-val is deprecated.  Use uvdar_core-msg:point instead.")
  (point m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AMISeqPoint>) ostream)
  "Serializes a message object of type '<AMISeqPoint>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'insert_time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'insert_time) (cl:floor (cl:slot-value msg 'insert_time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'point) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AMISeqPoint>) istream)
  "Deserializes a message object of type '<AMISeqPoint>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'insert_time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'point) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AMISeqPoint>)))
  "Returns string type for a message object of type '<AMISeqPoint>"
  "uvdar_core/AMISeqPoint")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AMISeqPoint)))
  "Returns string type for a message object of type 'AMISeqPoint"
  "uvdar_core/AMISeqPoint")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AMISeqPoint>)))
  "Returns md5sum for a message object of type '<AMISeqPoint>"
  "e07590dc19e142a3fae21390f4e06a91")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AMISeqPoint)))
  "Returns md5sum for a message object of type 'AMISeqPoint"
  "e07590dc19e142a3fae21390f4e06a91")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AMISeqPoint>)))
  "Returns full string definition for message of type '<AMISeqPoint>"
  (cl:format cl:nil "time insert_time~%uvdar_core/Point2DWithFloat point~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AMISeqPoint)))
  "Returns full string definition for message of type 'AMISeqPoint"
  (cl:format cl:nil "time insert_time~%uvdar_core/Point2DWithFloat point~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AMISeqPoint>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'point))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AMISeqPoint>))
  "Converts a ROS message object to a list"
  (cl:list 'AMISeqPoint
    (cl:cons ':insert_time (insert_time msg))
    (cl:cons ':point (point msg))
))
