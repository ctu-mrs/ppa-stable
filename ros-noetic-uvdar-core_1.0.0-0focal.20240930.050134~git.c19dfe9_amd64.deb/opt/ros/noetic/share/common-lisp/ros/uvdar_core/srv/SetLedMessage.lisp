; Auto-generated. Do not edit!


(cl:in-package uvdar_core-srv)


;//! \htmlinclude SetLedMessage-request.msg.html

(cl:defclass <SetLedMessage-request> (roslisp-msg-protocol:ros-message)
  ((data_frame
    :reader data_frame
    :initarg :data_frame
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil)))
)

(cl:defclass SetLedMessage-request (<SetLedMessage-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetLedMessage-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetLedMessage-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-srv:<SetLedMessage-request> is deprecated: use uvdar_core-srv:SetLedMessage-request instead.")))

(cl:ensure-generic-function 'data_frame-val :lambda-list '(m))
(cl:defmethod data_frame-val ((m <SetLedMessage-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:data_frame-val is deprecated.  Use uvdar_core-srv:data_frame instead.")
  (data_frame m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetLedMessage-request>) ostream)
  "Serializes a message object of type '<SetLedMessage-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'data_frame))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetLedMessage-request>) istream)
  "Deserializes a message object of type '<SetLedMessage-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data_frame) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data_frame)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetLedMessage-request>)))
  "Returns string type for a service object of type '<SetLedMessage-request>"
  "uvdar_core/SetLedMessageRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetLedMessage-request)))
  "Returns string type for a service object of type 'SetLedMessage-request"
  "uvdar_core/SetLedMessageRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetLedMessage-request>)))
  "Returns md5sum for a message object of type '<SetLedMessage-request>"
  "48e59db0542fa3f48c3ab80989dbff97")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetLedMessage-request)))
  "Returns md5sum for a message object of type 'SetLedMessage-request"
  "48e59db0542fa3f48c3ab80989dbff97")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetLedMessage-request>)))
  "Returns full string definition for message of type '<SetLedMessage-request>"
  (cl:format cl:nil "bool[] data_frame~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetLedMessage-request)))
  "Returns full string definition for message of type 'SetLedMessage-request"
  (cl:format cl:nil "bool[] data_frame~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetLedMessage-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data_frame) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetLedMessage-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetLedMessage-request
    (cl:cons ':data_frame (data_frame msg))
))
;//! \htmlinclude SetLedMessage-response.msg.html

(cl:defclass <SetLedMessage-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass SetLedMessage-response (<SetLedMessage-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetLedMessage-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetLedMessage-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-srv:<SetLedMessage-response> is deprecated: use uvdar_core-srv:SetLedMessage-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SetLedMessage-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:success-val is deprecated.  Use uvdar_core-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SetLedMessage-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-srv:message-val is deprecated.  Use uvdar_core-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetLedMessage-response>) ostream)
  "Serializes a message object of type '<SetLedMessage-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetLedMessage-response>) istream)
  "Deserializes a message object of type '<SetLedMessage-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetLedMessage-response>)))
  "Returns string type for a service object of type '<SetLedMessage-response>"
  "uvdar_core/SetLedMessageResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetLedMessage-response)))
  "Returns string type for a service object of type 'SetLedMessage-response"
  "uvdar_core/SetLedMessageResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetLedMessage-response>)))
  "Returns md5sum for a message object of type '<SetLedMessage-response>"
  "48e59db0542fa3f48c3ab80989dbff97")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetLedMessage-response)))
  "Returns md5sum for a message object of type 'SetLedMessage-response"
  "48e59db0542fa3f48c3ab80989dbff97")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetLedMessage-response>)))
  "Returns full string definition for message of type '<SetLedMessage-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetLedMessage-response)))
  "Returns full string definition for message of type 'SetLedMessage-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetLedMessage-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetLedMessage-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetLedMessage-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetLedMessage)))
  'SetLedMessage-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetLedMessage)))
  'SetLedMessage-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetLedMessage)))
  "Returns string type for a service object of type '<SetLedMessage>"
  "uvdar_core/SetLedMessage")