; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude RecMsg.msg.html

(cl:defclass <RecMsg> (roslisp-msg-protocol:ros-message)
  ((pl_carrying
    :reader pl_carrying
    :initarg :pl_carrying
    :type cl:boolean
    :initform cl:nil)
   (uav_id
    :reader uav_id
    :initarg :uav_id
    :type cl:integer
    :initform 0)
   (heading
    :reader heading
    :initarg :heading
    :type cl:float
    :initform 0.0)
   (msg_type
    :reader msg_type
    :initarg :msg_type
    :type cl:integer
    :initform 0)
   (payload
    :reader payload
    :initarg :payload
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass RecMsg (<RecMsg>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <RecMsg>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'RecMsg)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<RecMsg> is deprecated: use uvdar_core-msg:RecMsg instead.")))

(cl:ensure-generic-function 'pl_carrying-val :lambda-list '(m))
(cl:defmethod pl_carrying-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:pl_carrying-val is deprecated.  Use uvdar_core-msg:pl_carrying instead.")
  (pl_carrying m))

(cl:ensure-generic-function 'uav_id-val :lambda-list '(m))
(cl:defmethod uav_id-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:uav_id-val is deprecated.  Use uvdar_core-msg:uav_id instead.")
  (uav_id m))

(cl:ensure-generic-function 'heading-val :lambda-list '(m))
(cl:defmethod heading-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:heading-val is deprecated.  Use uvdar_core-msg:heading instead.")
  (heading m))

(cl:ensure-generic-function 'msg_type-val :lambda-list '(m))
(cl:defmethod msg_type-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:msg_type-val is deprecated.  Use uvdar_core-msg:msg_type instead.")
  (msg_type m))

(cl:ensure-generic-function 'payload-val :lambda-list '(m))
(cl:defmethod payload-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:payload-val is deprecated.  Use uvdar_core-msg:payload instead.")
  (payload m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <RecMsg>) ostream)
  "Serializes a message object of type '<RecMsg>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'pl_carrying) 1 0)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'uav_id)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'heading))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'msg_type)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'payload))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'payload))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <RecMsg>) istream)
  "Deserializes a message object of type '<RecMsg>"
    (cl:setf (cl:slot-value msg 'pl_carrying) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'uav_id) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'heading) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'msg_type) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'payload) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'payload)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<RecMsg>)))
  "Returns string type for a message object of type '<RecMsg>"
  "uvdar_core/RecMsg")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'RecMsg)))
  "Returns string type for a message object of type 'RecMsg"
  "uvdar_core/RecMsg")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<RecMsg>)))
  "Returns md5sum for a message object of type '<RecMsg>"
  "258207300cdd4b25d2db94483c10271b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'RecMsg)))
  "Returns md5sum for a message object of type 'RecMsg"
  "258207300cdd4b25d2db94483c10271b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<RecMsg>)))
  "Returns full string definition for message of type '<RecMsg>"
  (cl:format cl:nil "#Received msg~%bool pl_carrying~%int32 uav_id~%float32 heading~%int32 msg_type~%float32[] payload~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'RecMsg)))
  "Returns full string definition for message of type 'RecMsg"
  (cl:format cl:nil "#Received msg~%bool pl_carrying~%int32 uav_id~%float32 heading~%int32 msg_type~%float32[] payload~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <RecMsg>))
  (cl:+ 0
     1
     4
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'payload) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <RecMsg>))
  "Converts a ROS message object to a list"
  (cl:list 'RecMsg
    (cl:cons ':pl_carrying (pl_carrying msg))
    (cl:cons ':uav_id (uav_id msg))
    (cl:cons ':heading (heading msg))
    (cl:cons ':msg_type (msg_type msg))
    (cl:cons ':payload (payload msg))
))
