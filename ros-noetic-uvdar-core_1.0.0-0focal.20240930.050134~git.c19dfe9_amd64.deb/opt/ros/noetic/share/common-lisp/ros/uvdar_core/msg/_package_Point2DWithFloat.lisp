(cl:in-package uvdar_core-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
          VALUE-VAL
          VALUE
))