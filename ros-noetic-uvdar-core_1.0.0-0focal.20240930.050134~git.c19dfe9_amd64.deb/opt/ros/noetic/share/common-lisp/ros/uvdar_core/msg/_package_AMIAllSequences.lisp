(cl:in-package uvdar_core-msg)
(cl:export '(SEQUENCES-VAL
          SEQUENCES
))