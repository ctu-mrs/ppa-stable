(cl:in-package uvdar_core-msg)
(cl:export '(PL_CARRYING-VAL
          PL_CARRYING
          UAV_ID-VAL
          UAV_ID
          HEADING-VAL
          HEADING
          MSG_TYPE-VAL
          MSG_TYPE
          PAYLOAD-VAL
          PAYLOAD
))