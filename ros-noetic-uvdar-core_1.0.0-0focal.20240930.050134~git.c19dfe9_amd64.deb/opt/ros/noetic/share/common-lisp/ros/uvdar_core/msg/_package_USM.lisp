(cl:in-package uvdar_core-msg)
(cl:export '(BLANK_MSG-VAL
          BLANK_MSG
          MSG_TYPE-VAL
          MSG_TYPE
          PAYLOAD-VAL
          PAYLOAD
))