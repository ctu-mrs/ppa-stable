// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FrequencySet {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.f1 = null;
      this.f2 = null;
      this.f3 = null;
      this.f4 = null;
      this.f5 = null;
      this.f6 = null;
      this.f7 = null;
      this.f8 = null;
    }
    else {
      if (initObj.hasOwnProperty('f1')) {
        this.f1 = initObj.f1
      }
      else {
        this.f1 = 0;
      }
      if (initObj.hasOwnProperty('f2')) {
        this.f2 = initObj.f2
      }
      else {
        this.f2 = 0;
      }
      if (initObj.hasOwnProperty('f3')) {
        this.f3 = initObj.f3
      }
      else {
        this.f3 = 0;
      }
      if (initObj.hasOwnProperty('f4')) {
        this.f4 = initObj.f4
      }
      else {
        this.f4 = 0;
      }
      if (initObj.hasOwnProperty('f5')) {
        this.f5 = initObj.f5
      }
      else {
        this.f5 = 0;
      }
      if (initObj.hasOwnProperty('f6')) {
        this.f6 = initObj.f6
      }
      else {
        this.f6 = 0;
      }
      if (initObj.hasOwnProperty('f7')) {
        this.f7 = initObj.f7
      }
      else {
        this.f7 = 0;
      }
      if (initObj.hasOwnProperty('f8')) {
        this.f8 = initObj.f8
      }
      else {
        this.f8 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrequencySet
    // Serialize message field [f1]
    bufferOffset = _serializer.uint8(obj.f1, buffer, bufferOffset);
    // Serialize message field [f2]
    bufferOffset = _serializer.uint8(obj.f2, buffer, bufferOffset);
    // Serialize message field [f3]
    bufferOffset = _serializer.uint8(obj.f3, buffer, bufferOffset);
    // Serialize message field [f4]
    bufferOffset = _serializer.uint8(obj.f4, buffer, bufferOffset);
    // Serialize message field [f5]
    bufferOffset = _serializer.uint8(obj.f5, buffer, bufferOffset);
    // Serialize message field [f6]
    bufferOffset = _serializer.uint8(obj.f6, buffer, bufferOffset);
    // Serialize message field [f7]
    bufferOffset = _serializer.uint8(obj.f7, buffer, bufferOffset);
    // Serialize message field [f8]
    bufferOffset = _serializer.uint8(obj.f8, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrequencySet
    let len;
    let data = new FrequencySet(null);
    // Deserialize message field [f1]
    data.f1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f2]
    data.f2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f3]
    data.f3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f4]
    data.f4 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f5]
    data.f5 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f6]
    data.f6 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f7]
    data.f7 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f8]
    data.f8 = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/FrequencySet';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b4ba54bd51af1c63e7f6d0f9d284cf29';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 f1
    uint8 f2
    uint8 f3
    uint8 f4
    uint8 f5
    uint8 f6
    uint8 f7
    uint8 f8
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrequencySet(null);
    if (msg.f1 !== undefined) {
      resolved.f1 = msg.f1;
    }
    else {
      resolved.f1 = 0
    }

    if (msg.f2 !== undefined) {
      resolved.f2 = msg.f2;
    }
    else {
      resolved.f2 = 0
    }

    if (msg.f3 !== undefined) {
      resolved.f3 = msg.f3;
    }
    else {
      resolved.f3 = 0
    }

    if (msg.f4 !== undefined) {
      resolved.f4 = msg.f4;
    }
    else {
      resolved.f4 = 0
    }

    if (msg.f5 !== undefined) {
      resolved.f5 = msg.f5;
    }
    else {
      resolved.f5 = 0
    }

    if (msg.f6 !== undefined) {
      resolved.f6 = msg.f6;
    }
    else {
      resolved.f6 = 0
    }

    if (msg.f7 !== undefined) {
      resolved.f7 = msg.f7;
    }
    else {
      resolved.f7 = 0
    }

    if (msg.f8 !== undefined) {
      resolved.f8 = msg.f8;
    }
    else {
      resolved.f8 = 0
    }

    return resolved;
    }
};

module.exports = FrequencySet;
