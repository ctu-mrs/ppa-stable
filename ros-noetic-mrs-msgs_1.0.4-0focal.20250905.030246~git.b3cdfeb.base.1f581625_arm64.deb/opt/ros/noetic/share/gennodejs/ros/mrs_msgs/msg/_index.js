
"use strict";

let UavDiagnostics = require('./UavDiagnostics.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FuturePoint = require('./FuturePoint.js');
let GimbalState = require('./GimbalState.js');
let GpsInfo = require('./GpsInfo.js');
let RtkGps = require('./RtkGps.js');
let GpsData = require('./GpsData.js');
let RtkFixType = require('./RtkFixType.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let ReferenceArray = require('./ReferenceArray.js');
let EstimatorInput = require('./EstimatorInput.js');
let UavState = require('./UavState.js');
let EulerAngles = require('./EulerAngles.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let VelocityReference = require('./VelocityReference.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let Reference = require('./Reference.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let TrackerStatus = require('./TrackerStatus.js');
let TrackerCommand = require('./TrackerCommand.js');
let ControlError = require('./ControlError.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let PathReference = require('./PathReference.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let ControllerStatus = require('./ControllerStatus.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let UavStatusShort = require('./UavStatusShort.js');
let CustomTopic = require('./CustomTopic.js');
let UavStatus = require('./UavStatus.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let Se3Gains = require('./Se3Gains.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let Path = require('./Path.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let Histogram = require('./Histogram.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let TrackStamped = require('./TrackStamped.js');
let Float64 = require('./Float64.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let RangeWithCovarianceArrayStamped = require('./RangeWithCovarianceArrayStamped.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let StringStamped = require('./StringStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let Float64Stamped = require('./Float64Stamped.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let RangeWithCovarianceIdentified = require('./RangeWithCovarianceIdentified.js');
let Sphere = require('./Sphere.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let ImageLabeled = require('./ImageLabeled.js');
let Track = require('./Track.js');
let BoolStamped = require('./BoolStamped.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');

module.exports = {
  UavDiagnostics: UavDiagnostics,
  FutureTrajectory: FutureTrajectory,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  MpcPredictionFullState: MpcPredictionFullState,
  FuturePoint: FuturePoint,
  GimbalState: GimbalState,
  GpsInfo: GpsInfo,
  RtkGps: RtkGps,
  GpsData: GpsData,
  RtkFixType: RtkFixType,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  ReferenceArray: ReferenceArray,
  EstimatorInput: EstimatorInput,
  UavState: UavState,
  EulerAngles: EulerAngles,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  ControllerDiagnostics: ControllerDiagnostics,
  VelocityReference: VelocityReference,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  EstimationDiagnostics: EstimationDiagnostics,
  EstimatorCorrection: EstimatorCorrection,
  TrajectoryReference: TrajectoryReference,
  Reference: Reference,
  EstimatorDiagnostics: EstimatorDiagnostics,
  TrackerStatus: TrackerStatus,
  TrackerCommand: TrackerCommand,
  ControlError: ControlError,
  UavManagerDiagnostics: UavManagerDiagnostics,
  PathReference: PathReference,
  VelocityReferenceStamped: VelocityReferenceStamped,
  EstimatorOutput: EstimatorOutput,
  ControllerStatus: ControllerStatus,
  GainManagerDiagnostics: GainManagerDiagnostics,
  ReferenceStamped: ReferenceStamped,
  DynamicsConstraints: DynamicsConstraints,
  UavStatusShort: UavStatusShort,
  CustomTopic: CustomTopic,
  UavStatus: UavStatus,
  NodeCpuLoad: NodeCpuLoad,
  Se3Gains: Se3Gains,
  PathWithVelocity: PathWithVelocity,
  Path: Path,
  ReferenceWithVelocity: ReferenceWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  Histogram: Histogram,
  ObstacleSectors: ObstacleSectors,
  SpeedTrackerCommand: SpeedTrackerCommand,
  TrackStamped: TrackStamped,
  Float64: Float64,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  RangeWithCovarianceArrayStamped: RangeWithCovarianceArrayStamped,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  ImageLabeledArray: ImageLabeledArray,
  StringStamped: StringStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  Float64Stamped: Float64Stamped,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  RangeWithCovarianceIdentified: RangeWithCovarianceIdentified,
  Sphere: Sphere,
  TrackArrayStamped: TrackArrayStamped,
  ImageLabeled: ImageLabeled,
  Track: Track,
  BoolStamped: BoolStamped,
  UInt16Stamped: UInt16Stamped,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiRcChannels: HwApiRcChannels,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiStatus: HwApiStatus,
  HwApiCapabilities: HwApiCapabilities,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiAltitude: HwApiAltitude,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
};
