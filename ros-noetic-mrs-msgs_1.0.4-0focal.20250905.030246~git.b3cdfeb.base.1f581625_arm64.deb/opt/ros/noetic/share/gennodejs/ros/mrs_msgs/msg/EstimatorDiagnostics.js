// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class EstimatorDiagnostics {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.estimator_name = null;
      this.estimator_type = null;
      this.estimator_sm_state = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('estimator_name')) {
        this.estimator_name = initObj.estimator_name
      }
      else {
        this.estimator_name = '';
      }
      if (initObj.hasOwnProperty('estimator_type')) {
        this.estimator_type = initObj.estimator_type
      }
      else {
        this.estimator_type = '';
      }
      if (initObj.hasOwnProperty('estimator_sm_state')) {
        this.estimator_sm_state = initObj.estimator_sm_state
      }
      else {
        this.estimator_sm_state = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EstimatorDiagnostics
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [estimator_name]
    bufferOffset = _serializer.string(obj.estimator_name, buffer, bufferOffset);
    // Serialize message field [estimator_type]
    bufferOffset = _serializer.string(obj.estimator_type, buffer, bufferOffset);
    // Serialize message field [estimator_sm_state]
    bufferOffset = _serializer.string(obj.estimator_sm_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EstimatorDiagnostics
    let len;
    let data = new EstimatorDiagnostics(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [estimator_name]
    data.estimator_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_type]
    data.estimator_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_sm_state]
    data.estimator_sm_state = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.estimator_name);
    length += _getByteLength(object.estimator_type);
    length += _getByteLength(object.estimator_sm_state);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/EstimatorDiagnostics';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e540018055e5b608a19e1a3a78e7de15';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    string estimator_name
    string estimator_type
    string estimator_sm_state
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EstimatorDiagnostics(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.estimator_name !== undefined) {
      resolved.estimator_name = msg.estimator_name;
    }
    else {
      resolved.estimator_name = ''
    }

    if (msg.estimator_type !== undefined) {
      resolved.estimator_type = msg.estimator_type;
    }
    else {
      resolved.estimator_type = ''
    }

    if (msg.estimator_sm_state !== undefined) {
      resolved.estimator_sm_state = msg.estimator_sm_state;
    }
    else {
      resolved.estimator_sm_state = ''
    }

    return resolved;
    }
};

module.exports = EstimatorDiagnostics;
