// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let CustomTopic = require('./CustomTopic.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class UavStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.uav_name = null;
      this.uav_type = null;
      this.uav_mass = null;
      this.control_manager_diag_hz = null;
      this.control_manager_diag_color = null;
      this.controllers = null;
      this.gains = null;
      this.trackers = null;
      this.constraints = null;
      this.null_tracker = null;
      this.secs_flown = null;
      this.odom_hz = null;
      this.odom_color = null;
      this.odom_x = null;
      this.odom_y = null;
      this.odom_z = null;
      this.odom_hdg = null;
      this.odom_frame = null;
      this.odom_estimators = null;
      this.horizontal_estimator = null;
      this.vertical_estimator = null;
      this.heading_estimator = null;
      this.agl_estimator = null;
      this.max_flight_z = null;
      this.cmd_x = null;
      this.cmd_y = null;
      this.cmd_z = null;
      this.cmd_hdg = null;
      this.cpu_load = null;
      this.cpu_load_total = null;
      this.cpu_ghz = null;
      this.cpu_temperature = null;
      this.free_ram = null;
      this.total_ram = null;
      this.free_hdd = null;
      this.hw_api_hz = null;
      this.hw_api_color = null;
      this.hw_api_battery_hz = null;
      this.hw_api_state_hz = null;
      this.hw_api_cmd_hz = null;
      this.hw_api_mode = null;
      this.hw_api_armed = null;
      this.hw_api_gnss_ok = null;
      this.hw_api_gnss_qual = null;
      this.mag_norm_hz = null;
      this.hw_api_gnss_fix_type = null;
      this.hw_api_gnss_num_sats = null;
      this.hw_api_gnss_pos_acc = null;
      this.hw_api_gnss_status_hz = null;
      this.mag_norm = null;
      this.battery_volt = null;
      this.battery_curr = null;
      this.battery_wh_drained = null;
      this.thrust = null;
      this.mass_estimate = null;
      this.mass_set = null;
      this.custom_topics = null;
      this.custom_string_outputs = null;
      this.node_cpu_loads = null;
      this.flying_normally = null;
      this.rc_mode = null;
      this.have_goal = null;
      this.tracking_trajectory = null;
      this.callbacks_enabled = null;
      this.collision_avoidance_enabled = null;
      this.avoiding_collision = null;
      this.automatic_start_can_takeoff = null;
      this.num_other_uavs = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('uav_name')) {
        this.uav_name = initObj.uav_name
      }
      else {
        this.uav_name = '';
      }
      if (initObj.hasOwnProperty('uav_type')) {
        this.uav_type = initObj.uav_type
      }
      else {
        this.uav_type = '';
      }
      if (initObj.hasOwnProperty('uav_mass')) {
        this.uav_mass = initObj.uav_mass
      }
      else {
        this.uav_mass = '';
      }
      if (initObj.hasOwnProperty('control_manager_diag_hz')) {
        this.control_manager_diag_hz = initObj.control_manager_diag_hz
      }
      else {
        this.control_manager_diag_hz = 0.0;
      }
      if (initObj.hasOwnProperty('control_manager_diag_color')) {
        this.control_manager_diag_color = initObj.control_manager_diag_color
      }
      else {
        this.control_manager_diag_color = 0;
      }
      if (initObj.hasOwnProperty('controllers')) {
        this.controllers = initObj.controllers
      }
      else {
        this.controllers = [];
      }
      if (initObj.hasOwnProperty('gains')) {
        this.gains = initObj.gains
      }
      else {
        this.gains = [];
      }
      if (initObj.hasOwnProperty('trackers')) {
        this.trackers = initObj.trackers
      }
      else {
        this.trackers = [];
      }
      if (initObj.hasOwnProperty('constraints')) {
        this.constraints = initObj.constraints
      }
      else {
        this.constraints = [];
      }
      if (initObj.hasOwnProperty('null_tracker')) {
        this.null_tracker = initObj.null_tracker
      }
      else {
        this.null_tracker = false;
      }
      if (initObj.hasOwnProperty('secs_flown')) {
        this.secs_flown = initObj.secs_flown
      }
      else {
        this.secs_flown = 0;
      }
      if (initObj.hasOwnProperty('odom_hz')) {
        this.odom_hz = initObj.odom_hz
      }
      else {
        this.odom_hz = 0.0;
      }
      if (initObj.hasOwnProperty('odom_color')) {
        this.odom_color = initObj.odom_color
      }
      else {
        this.odom_color = 0;
      }
      if (initObj.hasOwnProperty('odom_x')) {
        this.odom_x = initObj.odom_x
      }
      else {
        this.odom_x = 0.0;
      }
      if (initObj.hasOwnProperty('odom_y')) {
        this.odom_y = initObj.odom_y
      }
      else {
        this.odom_y = 0.0;
      }
      if (initObj.hasOwnProperty('odom_z')) {
        this.odom_z = initObj.odom_z
      }
      else {
        this.odom_z = 0.0;
      }
      if (initObj.hasOwnProperty('odom_hdg')) {
        this.odom_hdg = initObj.odom_hdg
      }
      else {
        this.odom_hdg = 0.0;
      }
      if (initObj.hasOwnProperty('odom_frame')) {
        this.odom_frame = initObj.odom_frame
      }
      else {
        this.odom_frame = '';
      }
      if (initObj.hasOwnProperty('odom_estimators')) {
        this.odom_estimators = initObj.odom_estimators
      }
      else {
        this.odom_estimators = [];
      }
      if (initObj.hasOwnProperty('horizontal_estimator')) {
        this.horizontal_estimator = initObj.horizontal_estimator
      }
      else {
        this.horizontal_estimator = '';
      }
      if (initObj.hasOwnProperty('vertical_estimator')) {
        this.vertical_estimator = initObj.vertical_estimator
      }
      else {
        this.vertical_estimator = '';
      }
      if (initObj.hasOwnProperty('heading_estimator')) {
        this.heading_estimator = initObj.heading_estimator
      }
      else {
        this.heading_estimator = '';
      }
      if (initObj.hasOwnProperty('agl_estimator')) {
        this.agl_estimator = initObj.agl_estimator
      }
      else {
        this.agl_estimator = '';
      }
      if (initObj.hasOwnProperty('max_flight_z')) {
        this.max_flight_z = initObj.max_flight_z
      }
      else {
        this.max_flight_z = 0.0;
      }
      if (initObj.hasOwnProperty('cmd_x')) {
        this.cmd_x = initObj.cmd_x
      }
      else {
        this.cmd_x = 0.0;
      }
      if (initObj.hasOwnProperty('cmd_y')) {
        this.cmd_y = initObj.cmd_y
      }
      else {
        this.cmd_y = 0.0;
      }
      if (initObj.hasOwnProperty('cmd_z')) {
        this.cmd_z = initObj.cmd_z
      }
      else {
        this.cmd_z = 0.0;
      }
      if (initObj.hasOwnProperty('cmd_hdg')) {
        this.cmd_hdg = initObj.cmd_hdg
      }
      else {
        this.cmd_hdg = 0.0;
      }
      if (initObj.hasOwnProperty('cpu_load')) {
        this.cpu_load = initObj.cpu_load
      }
      else {
        this.cpu_load = 0.0;
      }
      if (initObj.hasOwnProperty('cpu_load_total')) {
        this.cpu_load_total = initObj.cpu_load_total
      }
      else {
        this.cpu_load_total = 0.0;
      }
      if (initObj.hasOwnProperty('cpu_ghz')) {
        this.cpu_ghz = initObj.cpu_ghz
      }
      else {
        this.cpu_ghz = 0.0;
      }
      if (initObj.hasOwnProperty('cpu_temperature')) {
        this.cpu_temperature = initObj.cpu_temperature
      }
      else {
        this.cpu_temperature = 0.0;
      }
      if (initObj.hasOwnProperty('free_ram')) {
        this.free_ram = initObj.free_ram
      }
      else {
        this.free_ram = 0.0;
      }
      if (initObj.hasOwnProperty('total_ram')) {
        this.total_ram = initObj.total_ram
      }
      else {
        this.total_ram = 0.0;
      }
      if (initObj.hasOwnProperty('free_hdd')) {
        this.free_hdd = initObj.free_hdd
      }
      else {
        this.free_hdd = 0;
      }
      if (initObj.hasOwnProperty('hw_api_hz')) {
        this.hw_api_hz = initObj.hw_api_hz
      }
      else {
        this.hw_api_hz = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_color')) {
        this.hw_api_color = initObj.hw_api_color
      }
      else {
        this.hw_api_color = 0;
      }
      if (initObj.hasOwnProperty('hw_api_battery_hz')) {
        this.hw_api_battery_hz = initObj.hw_api_battery_hz
      }
      else {
        this.hw_api_battery_hz = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_state_hz')) {
        this.hw_api_state_hz = initObj.hw_api_state_hz
      }
      else {
        this.hw_api_state_hz = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_cmd_hz')) {
        this.hw_api_cmd_hz = initObj.hw_api_cmd_hz
      }
      else {
        this.hw_api_cmd_hz = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_mode')) {
        this.hw_api_mode = initObj.hw_api_mode
      }
      else {
        this.hw_api_mode = '';
      }
      if (initObj.hasOwnProperty('hw_api_armed')) {
        this.hw_api_armed = initObj.hw_api_armed
      }
      else {
        this.hw_api_armed = false;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_ok')) {
        this.hw_api_gnss_ok = initObj.hw_api_gnss_ok
      }
      else {
        this.hw_api_gnss_ok = false;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_qual')) {
        this.hw_api_gnss_qual = initObj.hw_api_gnss_qual
      }
      else {
        this.hw_api_gnss_qual = 0.0;
      }
      if (initObj.hasOwnProperty('mag_norm_hz')) {
        this.mag_norm_hz = initObj.mag_norm_hz
      }
      else {
        this.mag_norm_hz = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_fix_type')) {
        this.hw_api_gnss_fix_type = initObj.hw_api_gnss_fix_type
      }
      else {
        this.hw_api_gnss_fix_type = 0;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_num_sats')) {
        this.hw_api_gnss_num_sats = initObj.hw_api_gnss_num_sats
      }
      else {
        this.hw_api_gnss_num_sats = 0;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_pos_acc')) {
        this.hw_api_gnss_pos_acc = initObj.hw_api_gnss_pos_acc
      }
      else {
        this.hw_api_gnss_pos_acc = 0.0;
      }
      if (initObj.hasOwnProperty('hw_api_gnss_status_hz')) {
        this.hw_api_gnss_status_hz = initObj.hw_api_gnss_status_hz
      }
      else {
        this.hw_api_gnss_status_hz = 0.0;
      }
      if (initObj.hasOwnProperty('mag_norm')) {
        this.mag_norm = initObj.mag_norm
      }
      else {
        this.mag_norm = 0.0;
      }
      if (initObj.hasOwnProperty('battery_volt')) {
        this.battery_volt = initObj.battery_volt
      }
      else {
        this.battery_volt = 0.0;
      }
      if (initObj.hasOwnProperty('battery_curr')) {
        this.battery_curr = initObj.battery_curr
      }
      else {
        this.battery_curr = 0.0;
      }
      if (initObj.hasOwnProperty('battery_wh_drained')) {
        this.battery_wh_drained = initObj.battery_wh_drained
      }
      else {
        this.battery_wh_drained = 0.0;
      }
      if (initObj.hasOwnProperty('thrust')) {
        this.thrust = initObj.thrust
      }
      else {
        this.thrust = 0.0;
      }
      if (initObj.hasOwnProperty('mass_estimate')) {
        this.mass_estimate = initObj.mass_estimate
      }
      else {
        this.mass_estimate = 0.0;
      }
      if (initObj.hasOwnProperty('mass_set')) {
        this.mass_set = initObj.mass_set
      }
      else {
        this.mass_set = 0.0;
      }
      if (initObj.hasOwnProperty('custom_topics')) {
        this.custom_topics = initObj.custom_topics
      }
      else {
        this.custom_topics = [];
      }
      if (initObj.hasOwnProperty('custom_string_outputs')) {
        this.custom_string_outputs = initObj.custom_string_outputs
      }
      else {
        this.custom_string_outputs = [];
      }
      if (initObj.hasOwnProperty('node_cpu_loads')) {
        this.node_cpu_loads = initObj.node_cpu_loads
      }
      else {
        this.node_cpu_loads = new NodeCpuLoad();
      }
      if (initObj.hasOwnProperty('flying_normally')) {
        this.flying_normally = initObj.flying_normally
      }
      else {
        this.flying_normally = false;
      }
      if (initObj.hasOwnProperty('rc_mode')) {
        this.rc_mode = initObj.rc_mode
      }
      else {
        this.rc_mode = false;
      }
      if (initObj.hasOwnProperty('have_goal')) {
        this.have_goal = initObj.have_goal
      }
      else {
        this.have_goal = false;
      }
      if (initObj.hasOwnProperty('tracking_trajectory')) {
        this.tracking_trajectory = initObj.tracking_trajectory
      }
      else {
        this.tracking_trajectory = false;
      }
      if (initObj.hasOwnProperty('callbacks_enabled')) {
        this.callbacks_enabled = initObj.callbacks_enabled
      }
      else {
        this.callbacks_enabled = false;
      }
      if (initObj.hasOwnProperty('collision_avoidance_enabled')) {
        this.collision_avoidance_enabled = initObj.collision_avoidance_enabled
      }
      else {
        this.collision_avoidance_enabled = false;
      }
      if (initObj.hasOwnProperty('avoiding_collision')) {
        this.avoiding_collision = initObj.avoiding_collision
      }
      else {
        this.avoiding_collision = false;
      }
      if (initObj.hasOwnProperty('automatic_start_can_takeoff')) {
        this.automatic_start_can_takeoff = initObj.automatic_start_can_takeoff
      }
      else {
        this.automatic_start_can_takeoff = false;
      }
      if (initObj.hasOwnProperty('num_other_uavs')) {
        this.num_other_uavs = initObj.num_other_uavs
      }
      else {
        this.num_other_uavs = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UavStatus
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [uav_name]
    bufferOffset = _serializer.string(obj.uav_name, buffer, bufferOffset);
    // Serialize message field [uav_type]
    bufferOffset = _serializer.string(obj.uav_type, buffer, bufferOffset);
    // Serialize message field [uav_mass]
    bufferOffset = _serializer.string(obj.uav_mass, buffer, bufferOffset);
    // Serialize message field [control_manager_diag_hz]
    bufferOffset = _serializer.float32(obj.control_manager_diag_hz, buffer, bufferOffset);
    // Serialize message field [control_manager_diag_color]
    bufferOffset = _serializer.int16(obj.control_manager_diag_color, buffer, bufferOffset);
    // Serialize message field [controllers]
    bufferOffset = _arraySerializer.string(obj.controllers, buffer, bufferOffset, null);
    // Serialize message field [gains]
    bufferOffset = _arraySerializer.string(obj.gains, buffer, bufferOffset, null);
    // Serialize message field [trackers]
    bufferOffset = _arraySerializer.string(obj.trackers, buffer, bufferOffset, null);
    // Serialize message field [constraints]
    bufferOffset = _arraySerializer.string(obj.constraints, buffer, bufferOffset, null);
    // Serialize message field [null_tracker]
    bufferOffset = _serializer.bool(obj.null_tracker, buffer, bufferOffset);
    // Serialize message field [secs_flown]
    bufferOffset = _serializer.uint32(obj.secs_flown, buffer, bufferOffset);
    // Serialize message field [odom_hz]
    bufferOffset = _serializer.float32(obj.odom_hz, buffer, bufferOffset);
    // Serialize message field [odom_color]
    bufferOffset = _serializer.int16(obj.odom_color, buffer, bufferOffset);
    // Serialize message field [odom_x]
    bufferOffset = _serializer.float32(obj.odom_x, buffer, bufferOffset);
    // Serialize message field [odom_y]
    bufferOffset = _serializer.float32(obj.odom_y, buffer, bufferOffset);
    // Serialize message field [odom_z]
    bufferOffset = _serializer.float32(obj.odom_z, buffer, bufferOffset);
    // Serialize message field [odom_hdg]
    bufferOffset = _serializer.float32(obj.odom_hdg, buffer, bufferOffset);
    // Serialize message field [odom_frame]
    bufferOffset = _serializer.string(obj.odom_frame, buffer, bufferOffset);
    // Serialize message field [odom_estimators]
    bufferOffset = _arraySerializer.string(obj.odom_estimators, buffer, bufferOffset, null);
    // Serialize message field [horizontal_estimator]
    bufferOffset = _serializer.string(obj.horizontal_estimator, buffer, bufferOffset);
    // Serialize message field [vertical_estimator]
    bufferOffset = _serializer.string(obj.vertical_estimator, buffer, bufferOffset);
    // Serialize message field [heading_estimator]
    bufferOffset = _serializer.string(obj.heading_estimator, buffer, bufferOffset);
    // Serialize message field [agl_estimator]
    bufferOffset = _serializer.string(obj.agl_estimator, buffer, bufferOffset);
    // Serialize message field [max_flight_z]
    bufferOffset = _serializer.float32(obj.max_flight_z, buffer, bufferOffset);
    // Serialize message field [cmd_x]
    bufferOffset = _serializer.float32(obj.cmd_x, buffer, bufferOffset);
    // Serialize message field [cmd_y]
    bufferOffset = _serializer.float32(obj.cmd_y, buffer, bufferOffset);
    // Serialize message field [cmd_z]
    bufferOffset = _serializer.float32(obj.cmd_z, buffer, bufferOffset);
    // Serialize message field [cmd_hdg]
    bufferOffset = _serializer.float32(obj.cmd_hdg, buffer, bufferOffset);
    // Serialize message field [cpu_load]
    bufferOffset = _serializer.float32(obj.cpu_load, buffer, bufferOffset);
    // Serialize message field [cpu_load_total]
    bufferOffset = _serializer.float32(obj.cpu_load_total, buffer, bufferOffset);
    // Serialize message field [cpu_ghz]
    bufferOffset = _serializer.float32(obj.cpu_ghz, buffer, bufferOffset);
    // Serialize message field [cpu_temperature]
    bufferOffset = _serializer.float32(obj.cpu_temperature, buffer, bufferOffset);
    // Serialize message field [free_ram]
    bufferOffset = _serializer.float32(obj.free_ram, buffer, bufferOffset);
    // Serialize message field [total_ram]
    bufferOffset = _serializer.float32(obj.total_ram, buffer, bufferOffset);
    // Serialize message field [free_hdd]
    bufferOffset = _serializer.int32(obj.free_hdd, buffer, bufferOffset);
    // Serialize message field [hw_api_hz]
    bufferOffset = _serializer.float32(obj.hw_api_hz, buffer, bufferOffset);
    // Serialize message field [hw_api_color]
    bufferOffset = _serializer.int16(obj.hw_api_color, buffer, bufferOffset);
    // Serialize message field [hw_api_battery_hz]
    bufferOffset = _serializer.float32(obj.hw_api_battery_hz, buffer, bufferOffset);
    // Serialize message field [hw_api_state_hz]
    bufferOffset = _serializer.float32(obj.hw_api_state_hz, buffer, bufferOffset);
    // Serialize message field [hw_api_cmd_hz]
    bufferOffset = _serializer.float32(obj.hw_api_cmd_hz, buffer, bufferOffset);
    // Serialize message field [hw_api_mode]
    bufferOffset = _serializer.string(obj.hw_api_mode, buffer, bufferOffset);
    // Serialize message field [hw_api_armed]
    bufferOffset = _serializer.bool(obj.hw_api_armed, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_ok]
    bufferOffset = _serializer.bool(obj.hw_api_gnss_ok, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_qual]
    bufferOffset = _serializer.float32(obj.hw_api_gnss_qual, buffer, bufferOffset);
    // Serialize message field [mag_norm_hz]
    bufferOffset = _serializer.float32(obj.mag_norm_hz, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_fix_type]
    bufferOffset = _serializer.uint8(obj.hw_api_gnss_fix_type, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_num_sats]
    bufferOffset = _serializer.uint8(obj.hw_api_gnss_num_sats, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_pos_acc]
    bufferOffset = _serializer.float32(obj.hw_api_gnss_pos_acc, buffer, bufferOffset);
    // Serialize message field [hw_api_gnss_status_hz]
    bufferOffset = _serializer.float32(obj.hw_api_gnss_status_hz, buffer, bufferOffset);
    // Serialize message field [mag_norm]
    bufferOffset = _serializer.float32(obj.mag_norm, buffer, bufferOffset);
    // Serialize message field [battery_volt]
    bufferOffset = _serializer.float32(obj.battery_volt, buffer, bufferOffset);
    // Serialize message field [battery_curr]
    bufferOffset = _serializer.float32(obj.battery_curr, buffer, bufferOffset);
    // Serialize message field [battery_wh_drained]
    bufferOffset = _serializer.float32(obj.battery_wh_drained, buffer, bufferOffset);
    // Serialize message field [thrust]
    bufferOffset = _serializer.float32(obj.thrust, buffer, bufferOffset);
    // Serialize message field [mass_estimate]
    bufferOffset = _serializer.float32(obj.mass_estimate, buffer, bufferOffset);
    // Serialize message field [mass_set]
    bufferOffset = _serializer.float32(obj.mass_set, buffer, bufferOffset);
    // Serialize message field [custom_topics]
    // Serialize the length for message field [custom_topics]
    bufferOffset = _serializer.uint32(obj.custom_topics.length, buffer, bufferOffset);
    obj.custom_topics.forEach((val) => {
      bufferOffset = CustomTopic.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [custom_string_outputs]
    bufferOffset = _arraySerializer.string(obj.custom_string_outputs, buffer, bufferOffset, null);
    // Serialize message field [node_cpu_loads]
    bufferOffset = NodeCpuLoad.serialize(obj.node_cpu_loads, buffer, bufferOffset);
    // Serialize message field [flying_normally]
    bufferOffset = _serializer.bool(obj.flying_normally, buffer, bufferOffset);
    // Serialize message field [rc_mode]
    bufferOffset = _serializer.bool(obj.rc_mode, buffer, bufferOffset);
    // Serialize message field [have_goal]
    bufferOffset = _serializer.bool(obj.have_goal, buffer, bufferOffset);
    // Serialize message field [tracking_trajectory]
    bufferOffset = _serializer.bool(obj.tracking_trajectory, buffer, bufferOffset);
    // Serialize message field [callbacks_enabled]
    bufferOffset = _serializer.bool(obj.callbacks_enabled, buffer, bufferOffset);
    // Serialize message field [collision_avoidance_enabled]
    bufferOffset = _serializer.bool(obj.collision_avoidance_enabled, buffer, bufferOffset);
    // Serialize message field [avoiding_collision]
    bufferOffset = _serializer.bool(obj.avoiding_collision, buffer, bufferOffset);
    // Serialize message field [automatic_start_can_takeoff]
    bufferOffset = _serializer.bool(obj.automatic_start_can_takeoff, buffer, bufferOffset);
    // Serialize message field [num_other_uavs]
    bufferOffset = _serializer.uint16(obj.num_other_uavs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UavStatus
    let len;
    let data = new UavStatus(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [uav_name]
    data.uav_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [uav_type]
    data.uav_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [uav_mass]
    data.uav_mass = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [control_manager_diag_hz]
    data.control_manager_diag_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [control_manager_diag_color]
    data.control_manager_diag_color = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [controllers]
    data.controllers = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [gains]
    data.gains = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [trackers]
    data.trackers = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [constraints]
    data.constraints = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [null_tracker]
    data.null_tracker = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [secs_flown]
    data.secs_flown = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [odom_hz]
    data.odom_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_color]
    data.odom_color = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [odom_x]
    data.odom_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_y]
    data.odom_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_z]
    data.odom_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_hdg]
    data.odom_hdg = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_frame]
    data.odom_frame = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [odom_estimators]
    data.odom_estimators = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [horizontal_estimator]
    data.horizontal_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [vertical_estimator]
    data.vertical_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [heading_estimator]
    data.heading_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [agl_estimator]
    data.agl_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [max_flight_z]
    data.max_flight_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cmd_x]
    data.cmd_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cmd_y]
    data.cmd_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cmd_z]
    data.cmd_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cmd_hdg]
    data.cmd_hdg = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cpu_load]
    data.cpu_load = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cpu_load_total]
    data.cpu_load_total = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cpu_ghz]
    data.cpu_ghz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cpu_temperature]
    data.cpu_temperature = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [free_ram]
    data.free_ram = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [total_ram]
    data.total_ram = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [free_hdd]
    data.free_hdd = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [hw_api_hz]
    data.hw_api_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_color]
    data.hw_api_color = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [hw_api_battery_hz]
    data.hw_api_battery_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_state_hz]
    data.hw_api_state_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_cmd_hz]
    data.hw_api_cmd_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_mode]
    data.hw_api_mode = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [hw_api_armed]
    data.hw_api_armed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_ok]
    data.hw_api_gnss_ok = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_qual]
    data.hw_api_gnss_qual = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mag_norm_hz]
    data.mag_norm_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_fix_type]
    data.hw_api_gnss_fix_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_num_sats]
    data.hw_api_gnss_num_sats = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_pos_acc]
    data.hw_api_gnss_pos_acc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hw_api_gnss_status_hz]
    data.hw_api_gnss_status_hz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mag_norm]
    data.mag_norm = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_volt]
    data.battery_volt = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_curr]
    data.battery_curr = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_wh_drained]
    data.battery_wh_drained = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [thrust]
    data.thrust = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mass_estimate]
    data.mass_estimate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mass_set]
    data.mass_set = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [custom_topics]
    // Deserialize array length for message field [custom_topics]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.custom_topics = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.custom_topics[i] = CustomTopic.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [custom_string_outputs]
    data.custom_string_outputs = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [node_cpu_loads]
    data.node_cpu_loads = NodeCpuLoad.deserialize(buffer, bufferOffset);
    // Deserialize message field [flying_normally]
    data.flying_normally = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rc_mode]
    data.rc_mode = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [have_goal]
    data.have_goal = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [tracking_trajectory]
    data.tracking_trajectory = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [callbacks_enabled]
    data.callbacks_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [collision_avoidance_enabled]
    data.collision_avoidance_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [avoiding_collision]
    data.avoiding_collision = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [automatic_start_can_takeoff]
    data.automatic_start_can_takeoff = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [num_other_uavs]
    data.num_other_uavs = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.uav_name);
    length += _getByteLength(object.uav_type);
    length += _getByteLength(object.uav_mass);
    object.controllers.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.gains.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.trackers.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.constraints.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.odom_frame);
    object.odom_estimators.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.horizontal_estimator);
    length += _getByteLength(object.vertical_estimator);
    length += _getByteLength(object.heading_estimator);
    length += _getByteLength(object.agl_estimator);
    length += _getByteLength(object.hw_api_mode);
    object.custom_topics.forEach((val) => {
      length += CustomTopic.getMessageSize(val);
    });
    object.custom_string_outputs.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += NodeCpuLoad.getMessageSize(object.node_cpu_loads);
    return length + 221;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/UavStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4802adcdb2264a820b1be493e7502cc3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Standard ROS header with stamp and coordinate frame ID
    Header header
    
    # Unique name of the UAV
    string uav_name
    # Name of the UAV model
    string uav_type
    # The current estimated UAV's mass as a string for display purposes
    string uav_mass
    
    # Frequency of receiving the Control Manager diagnostics
    float32 control_manager_diag_hz
    # Display color (for TUI visualization purposes)
    int16 control_manager_diag_color
    # A list of the available control algorithms, the first element is the active controller
    string[] controllers
    # A list of the available control gain presets for the current controller, the first element is the active preset
    string[] gains
    # A list of the available trajectory tracking (pre-shaping) algorithms, the first element is the active algorithm
    string[] trackers
    # A list of the available dynamic constraint presets for the current tracker, the first element is the active preset
    string[] constraints
    # True if the null (no-output) tracker is active
    bool null_tracker
    # Flight time
    uint32 secs_flown
    
    # Frequency of receiving the Estimation Manager diagnostics
    float32 odom_hz
    # Display color (for TUI visualization purposes)
    int16 odom_color
    # X position of the UAV in the current estimation coordinate frame
    float32 odom_x
    # Y position of the UAV in the current estimation coordinate frame
    float32 odom_y
    # Z position of the UAV in the current estimation coordinate frame
    float32 odom_z
    # Heading of the UAV in the current estimation coordinate frame
    float32 odom_hdg
    # Name of the current estimation coordinate frame
    string odom_frame
    # A list of the available ego-state estimation sources, the first element is the active source
    string[] odom_estimators
    # Name of the current source used for estimation of the UAV's horizontal position 
    string horizontal_estimator
    # Name of the current source used for estimation of the UAV's vertical position 
    string vertical_estimator
    # Name of the current source used for estimation of the UAV's heading
    string heading_estimator
    # Name of the current source used for estimation of the UAV's above ground level
    string agl_estimator
    # Maximal allowed Z coordinate of the UAV
    float32 max_flight_z
    
    # Setpoint X position of the UAV in the current estimation coordinate frame
    float32 cmd_x
    # Setpoint Y position of the UAV in the current estimation coordinate frame
    float32 cmd_y
    # Setpoint Z position of the UAV in the current estimation coordinate frame
    float32 cmd_z
    # Setpoint heading of the UAV in the current estimation coordinate frame
    float32 cmd_hdg
    
    # Current load of the CPU in percent relative all CPU cores (i.e. a maximal load of a 2-core CPU is 100.0)
    float32 cpu_load
    # Current load of the CPU in percent relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)
    float32 cpu_load_total
    # Current average frequency of the CPU in gigahertz
    float32 cpu_ghz
    # Current temperature of the CPU in degrees Celsius (or zero if not supported by the current system)
    float32 cpu_temperature
    # The amount of free RAM in gigabytes
    float32 free_ram
    # The total available RAM in gigabytes
    float32 total_ram
    # The amount of free disk space in gigabytes
    int32 free_hdd
    
    # Frequency of receiving the Hardware API diagnostics
    float32 hw_api_hz
    # Display color (for TUI visualization purposes)
    int16 hw_api_color
    # Frequency of receiving the battery status from the Hardware API
    float32 hw_api_battery_hz
    # Frequency of receiving the Hardware API status
    float32 hw_api_state_hz
    # Frequency of receiving the Hardware API commanded setpoint
    float32 hw_api_cmd_hz
    # Name of the current mode reported by the Hardware API (e.g.: "OFFBOARD", "AUTO.LAND", etc.)
    string hw_api_mode
    # True if the vehicle is armed (actuator movement is enabled)
    bool hw_api_armed
    # True if the GPS data is being received correctly
    bool hw_api_gnss_ok
    # A measure of the GPS position quality
    float32 hw_api_gnss_qual
    # Frequency of receiving the magnetic field norm
    float32 mag_norm_hz
    
    # Gnss fix type
    # 0 -> No GPS connected
    # 1 -> No position information, GPS is connected
    # 2 -> 2D position
    # 3 -> 3D position
    # 4 -> DGPS/SBAS aided 3D position
    # 5 -> TK float, 3D position
    # 6 -> TK Fixed, 3D position
    # 7 -> Static fixed, typically used for base stations
    # 8 -> PPP, 3D position
    uint8 hw_api_gnss_fix_type
    
    # Number of satellites used for gnss solution
    uint8 hw_api_gnss_num_sats
    
    # Estimated accuracy of the gnss solution (in meters)
    float32 hw_api_gnss_pos_acc
    
    # Rate of the gnss status message
    float32 hw_api_gnss_status_hz
    
    # Norm of the  magnetic field (in Gauss, 10Gauss = 1mT)
    float32 mag_norm
    # Battery voltage in volts
    float32 battery_volt
    # Battery current in amperes
    float32 battery_curr
    # Estimate of the drained battery power in watthours
    float32 battery_wh_drained
    # Current collective thrust relative to max. thrust (i.e. between 0 and 1)
    float32 thrust
    # Current estimated mass of the vehicle
    float32 mass_estimate
    # Nominal mass of the vehicle
    float32 mass_set
    
    # A list of custom topics to be displayed in the TUI
    CustomTopic[] custom_topics
    # A list of custom strings to be displayed in the TUI
    string[] custom_string_outputs
    
    # A list of node names and a list of their corresponding CPU loads relative to a single CPU core
    NodeCpuLoad node_cpu_loads
    
    # True if the UAV is flying and there are no emergency or safety maneuvers taking place
    bool flying_normally
    # True if the UAV is currently controlled by the RC
    bool rc_mode
    # True if the UAV is currently flying to a goal waypoint
    bool have_goal
    # True if the UAV is currently following a trajectory (implies have_goal == true)
    bool tracking_trajectory
    # True if the control pipeline is ready to receive and execute waypoints and trajectories
    bool callbacks_enabled
    # True if collision avoidance with other UAVs using the NimbRo network is enabled
    bool collision_avoidance_enabled
    # True if the UAV is currently performing a maneuver to avoid a collision with another UAV
    bool avoiding_collision
    # True if the UAV is ready to take off
    bool automatic_start_can_takeoff
    
    # The number of other UAVs whose predicted trajectory is available to this one (for collision avoidance purposes)
    uint16 num_other_uavs
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mrs_msgs/CustomTopic
    string topic_name
    float32 topic_hz
    int16 topic_color
    
    ================================================================================
    MSG: mrs_msgs/NodeCpuLoad
    # A list of names of all ROS nodes running on this UAV
    string[] node_names
    # A list of the corresponding CPU loads of these nodes relative to a single CPU core (i.e. a maximal load of a 2-core CPU is 200.0)
    float32[] cpu_loads
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UavStatus(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.uav_name !== undefined) {
      resolved.uav_name = msg.uav_name;
    }
    else {
      resolved.uav_name = ''
    }

    if (msg.uav_type !== undefined) {
      resolved.uav_type = msg.uav_type;
    }
    else {
      resolved.uav_type = ''
    }

    if (msg.uav_mass !== undefined) {
      resolved.uav_mass = msg.uav_mass;
    }
    else {
      resolved.uav_mass = ''
    }

    if (msg.control_manager_diag_hz !== undefined) {
      resolved.control_manager_diag_hz = msg.control_manager_diag_hz;
    }
    else {
      resolved.control_manager_diag_hz = 0.0
    }

    if (msg.control_manager_diag_color !== undefined) {
      resolved.control_manager_diag_color = msg.control_manager_diag_color;
    }
    else {
      resolved.control_manager_diag_color = 0
    }

    if (msg.controllers !== undefined) {
      resolved.controllers = msg.controllers;
    }
    else {
      resolved.controllers = []
    }

    if (msg.gains !== undefined) {
      resolved.gains = msg.gains;
    }
    else {
      resolved.gains = []
    }

    if (msg.trackers !== undefined) {
      resolved.trackers = msg.trackers;
    }
    else {
      resolved.trackers = []
    }

    if (msg.constraints !== undefined) {
      resolved.constraints = msg.constraints;
    }
    else {
      resolved.constraints = []
    }

    if (msg.null_tracker !== undefined) {
      resolved.null_tracker = msg.null_tracker;
    }
    else {
      resolved.null_tracker = false
    }

    if (msg.secs_flown !== undefined) {
      resolved.secs_flown = msg.secs_flown;
    }
    else {
      resolved.secs_flown = 0
    }

    if (msg.odom_hz !== undefined) {
      resolved.odom_hz = msg.odom_hz;
    }
    else {
      resolved.odom_hz = 0.0
    }

    if (msg.odom_color !== undefined) {
      resolved.odom_color = msg.odom_color;
    }
    else {
      resolved.odom_color = 0
    }

    if (msg.odom_x !== undefined) {
      resolved.odom_x = msg.odom_x;
    }
    else {
      resolved.odom_x = 0.0
    }

    if (msg.odom_y !== undefined) {
      resolved.odom_y = msg.odom_y;
    }
    else {
      resolved.odom_y = 0.0
    }

    if (msg.odom_z !== undefined) {
      resolved.odom_z = msg.odom_z;
    }
    else {
      resolved.odom_z = 0.0
    }

    if (msg.odom_hdg !== undefined) {
      resolved.odom_hdg = msg.odom_hdg;
    }
    else {
      resolved.odom_hdg = 0.0
    }

    if (msg.odom_frame !== undefined) {
      resolved.odom_frame = msg.odom_frame;
    }
    else {
      resolved.odom_frame = ''
    }

    if (msg.odom_estimators !== undefined) {
      resolved.odom_estimators = msg.odom_estimators;
    }
    else {
      resolved.odom_estimators = []
    }

    if (msg.horizontal_estimator !== undefined) {
      resolved.horizontal_estimator = msg.horizontal_estimator;
    }
    else {
      resolved.horizontal_estimator = ''
    }

    if (msg.vertical_estimator !== undefined) {
      resolved.vertical_estimator = msg.vertical_estimator;
    }
    else {
      resolved.vertical_estimator = ''
    }

    if (msg.heading_estimator !== undefined) {
      resolved.heading_estimator = msg.heading_estimator;
    }
    else {
      resolved.heading_estimator = ''
    }

    if (msg.agl_estimator !== undefined) {
      resolved.agl_estimator = msg.agl_estimator;
    }
    else {
      resolved.agl_estimator = ''
    }

    if (msg.max_flight_z !== undefined) {
      resolved.max_flight_z = msg.max_flight_z;
    }
    else {
      resolved.max_flight_z = 0.0
    }

    if (msg.cmd_x !== undefined) {
      resolved.cmd_x = msg.cmd_x;
    }
    else {
      resolved.cmd_x = 0.0
    }

    if (msg.cmd_y !== undefined) {
      resolved.cmd_y = msg.cmd_y;
    }
    else {
      resolved.cmd_y = 0.0
    }

    if (msg.cmd_z !== undefined) {
      resolved.cmd_z = msg.cmd_z;
    }
    else {
      resolved.cmd_z = 0.0
    }

    if (msg.cmd_hdg !== undefined) {
      resolved.cmd_hdg = msg.cmd_hdg;
    }
    else {
      resolved.cmd_hdg = 0.0
    }

    if (msg.cpu_load !== undefined) {
      resolved.cpu_load = msg.cpu_load;
    }
    else {
      resolved.cpu_load = 0.0
    }

    if (msg.cpu_load_total !== undefined) {
      resolved.cpu_load_total = msg.cpu_load_total;
    }
    else {
      resolved.cpu_load_total = 0.0
    }

    if (msg.cpu_ghz !== undefined) {
      resolved.cpu_ghz = msg.cpu_ghz;
    }
    else {
      resolved.cpu_ghz = 0.0
    }

    if (msg.cpu_temperature !== undefined) {
      resolved.cpu_temperature = msg.cpu_temperature;
    }
    else {
      resolved.cpu_temperature = 0.0
    }

    if (msg.free_ram !== undefined) {
      resolved.free_ram = msg.free_ram;
    }
    else {
      resolved.free_ram = 0.0
    }

    if (msg.total_ram !== undefined) {
      resolved.total_ram = msg.total_ram;
    }
    else {
      resolved.total_ram = 0.0
    }

    if (msg.free_hdd !== undefined) {
      resolved.free_hdd = msg.free_hdd;
    }
    else {
      resolved.free_hdd = 0
    }

    if (msg.hw_api_hz !== undefined) {
      resolved.hw_api_hz = msg.hw_api_hz;
    }
    else {
      resolved.hw_api_hz = 0.0
    }

    if (msg.hw_api_color !== undefined) {
      resolved.hw_api_color = msg.hw_api_color;
    }
    else {
      resolved.hw_api_color = 0
    }

    if (msg.hw_api_battery_hz !== undefined) {
      resolved.hw_api_battery_hz = msg.hw_api_battery_hz;
    }
    else {
      resolved.hw_api_battery_hz = 0.0
    }

    if (msg.hw_api_state_hz !== undefined) {
      resolved.hw_api_state_hz = msg.hw_api_state_hz;
    }
    else {
      resolved.hw_api_state_hz = 0.0
    }

    if (msg.hw_api_cmd_hz !== undefined) {
      resolved.hw_api_cmd_hz = msg.hw_api_cmd_hz;
    }
    else {
      resolved.hw_api_cmd_hz = 0.0
    }

    if (msg.hw_api_mode !== undefined) {
      resolved.hw_api_mode = msg.hw_api_mode;
    }
    else {
      resolved.hw_api_mode = ''
    }

    if (msg.hw_api_armed !== undefined) {
      resolved.hw_api_armed = msg.hw_api_armed;
    }
    else {
      resolved.hw_api_armed = false
    }

    if (msg.hw_api_gnss_ok !== undefined) {
      resolved.hw_api_gnss_ok = msg.hw_api_gnss_ok;
    }
    else {
      resolved.hw_api_gnss_ok = false
    }

    if (msg.hw_api_gnss_qual !== undefined) {
      resolved.hw_api_gnss_qual = msg.hw_api_gnss_qual;
    }
    else {
      resolved.hw_api_gnss_qual = 0.0
    }

    if (msg.mag_norm_hz !== undefined) {
      resolved.mag_norm_hz = msg.mag_norm_hz;
    }
    else {
      resolved.mag_norm_hz = 0.0
    }

    if (msg.hw_api_gnss_fix_type !== undefined) {
      resolved.hw_api_gnss_fix_type = msg.hw_api_gnss_fix_type;
    }
    else {
      resolved.hw_api_gnss_fix_type = 0
    }

    if (msg.hw_api_gnss_num_sats !== undefined) {
      resolved.hw_api_gnss_num_sats = msg.hw_api_gnss_num_sats;
    }
    else {
      resolved.hw_api_gnss_num_sats = 0
    }

    if (msg.hw_api_gnss_pos_acc !== undefined) {
      resolved.hw_api_gnss_pos_acc = msg.hw_api_gnss_pos_acc;
    }
    else {
      resolved.hw_api_gnss_pos_acc = 0.0
    }

    if (msg.hw_api_gnss_status_hz !== undefined) {
      resolved.hw_api_gnss_status_hz = msg.hw_api_gnss_status_hz;
    }
    else {
      resolved.hw_api_gnss_status_hz = 0.0
    }

    if (msg.mag_norm !== undefined) {
      resolved.mag_norm = msg.mag_norm;
    }
    else {
      resolved.mag_norm = 0.0
    }

    if (msg.battery_volt !== undefined) {
      resolved.battery_volt = msg.battery_volt;
    }
    else {
      resolved.battery_volt = 0.0
    }

    if (msg.battery_curr !== undefined) {
      resolved.battery_curr = msg.battery_curr;
    }
    else {
      resolved.battery_curr = 0.0
    }

    if (msg.battery_wh_drained !== undefined) {
      resolved.battery_wh_drained = msg.battery_wh_drained;
    }
    else {
      resolved.battery_wh_drained = 0.0
    }

    if (msg.thrust !== undefined) {
      resolved.thrust = msg.thrust;
    }
    else {
      resolved.thrust = 0.0
    }

    if (msg.mass_estimate !== undefined) {
      resolved.mass_estimate = msg.mass_estimate;
    }
    else {
      resolved.mass_estimate = 0.0
    }

    if (msg.mass_set !== undefined) {
      resolved.mass_set = msg.mass_set;
    }
    else {
      resolved.mass_set = 0.0
    }

    if (msg.custom_topics !== undefined) {
      resolved.custom_topics = new Array(msg.custom_topics.length);
      for (let i = 0; i < resolved.custom_topics.length; ++i) {
        resolved.custom_topics[i] = CustomTopic.Resolve(msg.custom_topics[i]);
      }
    }
    else {
      resolved.custom_topics = []
    }

    if (msg.custom_string_outputs !== undefined) {
      resolved.custom_string_outputs = msg.custom_string_outputs;
    }
    else {
      resolved.custom_string_outputs = []
    }

    if (msg.node_cpu_loads !== undefined) {
      resolved.node_cpu_loads = NodeCpuLoad.Resolve(msg.node_cpu_loads)
    }
    else {
      resolved.node_cpu_loads = new NodeCpuLoad()
    }

    if (msg.flying_normally !== undefined) {
      resolved.flying_normally = msg.flying_normally;
    }
    else {
      resolved.flying_normally = false
    }

    if (msg.rc_mode !== undefined) {
      resolved.rc_mode = msg.rc_mode;
    }
    else {
      resolved.rc_mode = false
    }

    if (msg.have_goal !== undefined) {
      resolved.have_goal = msg.have_goal;
    }
    else {
      resolved.have_goal = false
    }

    if (msg.tracking_trajectory !== undefined) {
      resolved.tracking_trajectory = msg.tracking_trajectory;
    }
    else {
      resolved.tracking_trajectory = false
    }

    if (msg.callbacks_enabled !== undefined) {
      resolved.callbacks_enabled = msg.callbacks_enabled;
    }
    else {
      resolved.callbacks_enabled = false
    }

    if (msg.collision_avoidance_enabled !== undefined) {
      resolved.collision_avoidance_enabled = msg.collision_avoidance_enabled;
    }
    else {
      resolved.collision_avoidance_enabled = false
    }

    if (msg.avoiding_collision !== undefined) {
      resolved.avoiding_collision = msg.avoiding_collision;
    }
    else {
      resolved.avoiding_collision = false
    }

    if (msg.automatic_start_can_takeoff !== undefined) {
      resolved.automatic_start_can_takeoff = msg.automatic_start_can_takeoff;
    }
    else {
      resolved.automatic_start_can_takeoff = false
    }

    if (msg.num_other_uavs !== undefined) {
      resolved.num_other_uavs = msg.num_other_uavs;
    }
    else {
      resolved.num_other_uavs = 0
    }

    return resolved;
    }
};

module.exports = UavStatus;
