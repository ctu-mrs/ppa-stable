// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class EstimationDiagnostics {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.child_frame_id = null;
      this.pose = null;
      this.velocity = null;
      this.acceleration = null;
      this.agl_height = null;
      this.max_flight_z = null;
      this.sm_state = null;
      this.current_state_estimator = null;
      this.estimator_horizontal = null;
      this.estimator_vertical = null;
      this.estimator_heading = null;
      this.estimator_agl_height = null;
      this.estimation_rate = null;
      this.estimator_iteration = null;
      this.running_state_estimators = null;
      this.switchable_state_estimators = null;
      this.platform_config = null;
      this.custom_config = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('child_frame_id')) {
        this.child_frame_id = initObj.child_frame_id
      }
      else {
        this.child_frame_id = '';
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = new geometry_msgs.msg.Twist();
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = new geometry_msgs.msg.Accel();
      }
      if (initObj.hasOwnProperty('agl_height')) {
        this.agl_height = initObj.agl_height
      }
      else {
        this.agl_height = 0.0;
      }
      if (initObj.hasOwnProperty('max_flight_z')) {
        this.max_flight_z = initObj.max_flight_z
      }
      else {
        this.max_flight_z = 0.0;
      }
      if (initObj.hasOwnProperty('sm_state')) {
        this.sm_state = initObj.sm_state
      }
      else {
        this.sm_state = '';
      }
      if (initObj.hasOwnProperty('current_state_estimator')) {
        this.current_state_estimator = initObj.current_state_estimator
      }
      else {
        this.current_state_estimator = '';
      }
      if (initObj.hasOwnProperty('estimator_horizontal')) {
        this.estimator_horizontal = initObj.estimator_horizontal
      }
      else {
        this.estimator_horizontal = '';
      }
      if (initObj.hasOwnProperty('estimator_vertical')) {
        this.estimator_vertical = initObj.estimator_vertical
      }
      else {
        this.estimator_vertical = '';
      }
      if (initObj.hasOwnProperty('estimator_heading')) {
        this.estimator_heading = initObj.estimator_heading
      }
      else {
        this.estimator_heading = '';
      }
      if (initObj.hasOwnProperty('estimator_agl_height')) {
        this.estimator_agl_height = initObj.estimator_agl_height
      }
      else {
        this.estimator_agl_height = '';
      }
      if (initObj.hasOwnProperty('estimation_rate')) {
        this.estimation_rate = initObj.estimation_rate
      }
      else {
        this.estimation_rate = 0;
      }
      if (initObj.hasOwnProperty('estimator_iteration')) {
        this.estimator_iteration = initObj.estimator_iteration
      }
      else {
        this.estimator_iteration = 0;
      }
      if (initObj.hasOwnProperty('running_state_estimators')) {
        this.running_state_estimators = initObj.running_state_estimators
      }
      else {
        this.running_state_estimators = [];
      }
      if (initObj.hasOwnProperty('switchable_state_estimators')) {
        this.switchable_state_estimators = initObj.switchable_state_estimators
      }
      else {
        this.switchable_state_estimators = [];
      }
      if (initObj.hasOwnProperty('platform_config')) {
        this.platform_config = initObj.platform_config
      }
      else {
        this.platform_config = '';
      }
      if (initObj.hasOwnProperty('custom_config')) {
        this.custom_config = initObj.custom_config
      }
      else {
        this.custom_config = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EstimationDiagnostics
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [child_frame_id]
    bufferOffset = _serializer.string(obj.child_frame_id, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = geometry_msgs.msg.Twist.serialize(obj.velocity, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = geometry_msgs.msg.Accel.serialize(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [agl_height]
    bufferOffset = _serializer.float64(obj.agl_height, buffer, bufferOffset);
    // Serialize message field [max_flight_z]
    bufferOffset = _serializer.float64(obj.max_flight_z, buffer, bufferOffset);
    // Serialize message field [sm_state]
    bufferOffset = _serializer.string(obj.sm_state, buffer, bufferOffset);
    // Serialize message field [current_state_estimator]
    bufferOffset = _serializer.string(obj.current_state_estimator, buffer, bufferOffset);
    // Serialize message field [estimator_horizontal]
    bufferOffset = _serializer.string(obj.estimator_horizontal, buffer, bufferOffset);
    // Serialize message field [estimator_vertical]
    bufferOffset = _serializer.string(obj.estimator_vertical, buffer, bufferOffset);
    // Serialize message field [estimator_heading]
    bufferOffset = _serializer.string(obj.estimator_heading, buffer, bufferOffset);
    // Serialize message field [estimator_agl_height]
    bufferOffset = _serializer.string(obj.estimator_agl_height, buffer, bufferOffset);
    // Serialize message field [estimation_rate]
    bufferOffset = _serializer.uint32(obj.estimation_rate, buffer, bufferOffset);
    // Serialize message field [estimator_iteration]
    bufferOffset = _serializer.uint32(obj.estimator_iteration, buffer, bufferOffset);
    // Serialize message field [running_state_estimators]
    bufferOffset = _arraySerializer.string(obj.running_state_estimators, buffer, bufferOffset, null);
    // Serialize message field [switchable_state_estimators]
    bufferOffset = _arraySerializer.string(obj.switchable_state_estimators, buffer, bufferOffset, null);
    // Serialize message field [platform_config]
    bufferOffset = _serializer.string(obj.platform_config, buffer, bufferOffset);
    // Serialize message field [custom_config]
    bufferOffset = _serializer.string(obj.custom_config, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EstimationDiagnostics
    let len;
    let data = new EstimationDiagnostics(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [child_frame_id]
    data.child_frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = geometry_msgs.msg.Twist.deserialize(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = geometry_msgs.msg.Accel.deserialize(buffer, bufferOffset);
    // Deserialize message field [agl_height]
    data.agl_height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [max_flight_z]
    data.max_flight_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sm_state]
    data.sm_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_state_estimator]
    data.current_state_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_horizontal]
    data.estimator_horizontal = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_vertical]
    data.estimator_vertical = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_heading]
    data.estimator_heading = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimator_agl_height]
    data.estimator_agl_height = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [estimation_rate]
    data.estimation_rate = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [estimator_iteration]
    data.estimator_iteration = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [running_state_estimators]
    data.running_state_estimators = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [switchable_state_estimators]
    data.switchable_state_estimators = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [platform_config]
    data.platform_config = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [custom_config]
    data.custom_config = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.child_frame_id);
    length += _getByteLength(object.sm_state);
    length += _getByteLength(object.current_state_estimator);
    length += _getByteLength(object.estimator_horizontal);
    length += _getByteLength(object.estimator_vertical);
    length += _getByteLength(object.estimator_heading);
    length += _getByteLength(object.estimator_agl_height);
    object.running_state_estimators.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.switchable_state_estimators.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.platform_config);
    length += _getByteLength(object.custom_config);
    return length + 220;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/EstimationDiagnostics';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e9ba1fde107f8b68c78c54d71f754aa4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    # frame of velocities and accelerations
    string child_frame_id
    
    # current estimated state (corresponds to uav_state msg)
    geometry_msgs/Pose pose
    geometry_msgs/Twist velocity
    geometry_msgs/Accel acceleration
    
    # agl height (above ground level)
    float64 agl_height
    
    # max allowed flight height (defined by safety area and available sensors)
    float64 max_flight_z
    
    # current state machine state
    string sm_state
    
    # current state estimator used for control
    string current_state_estimator
    
    # current subestimators used for control
    string estimator_horizontal
    string estimator_vertical
    string estimator_heading
    
    # current agl height estimator
    string estimator_agl_height
    
    # rate of estimation prediction and uav_state publishing
    uint32 estimation_rate
    
    # number of performed estimators switches
    uint32 estimator_iteration
    
    # estimators that are running
    string[] running_state_estimators
    
    # estimators that are healthy and ready to be switch into
    string[] switchable_state_estimators
    
    # loaded platform config file
    string platform_config
    
    # loaded custom config file
    string custom_config
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Twist
    # This expresses velocity in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Accel
    # This expresses acceleration in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EstimationDiagnostics(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.child_frame_id !== undefined) {
      resolved.child_frame_id = msg.child_frame_id;
    }
    else {
      resolved.child_frame_id = ''
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = geometry_msgs.msg.Twist.Resolve(msg.velocity)
    }
    else {
      resolved.velocity = new geometry_msgs.msg.Twist()
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = geometry_msgs.msg.Accel.Resolve(msg.acceleration)
    }
    else {
      resolved.acceleration = new geometry_msgs.msg.Accel()
    }

    if (msg.agl_height !== undefined) {
      resolved.agl_height = msg.agl_height;
    }
    else {
      resolved.agl_height = 0.0
    }

    if (msg.max_flight_z !== undefined) {
      resolved.max_flight_z = msg.max_flight_z;
    }
    else {
      resolved.max_flight_z = 0.0
    }

    if (msg.sm_state !== undefined) {
      resolved.sm_state = msg.sm_state;
    }
    else {
      resolved.sm_state = ''
    }

    if (msg.current_state_estimator !== undefined) {
      resolved.current_state_estimator = msg.current_state_estimator;
    }
    else {
      resolved.current_state_estimator = ''
    }

    if (msg.estimator_horizontal !== undefined) {
      resolved.estimator_horizontal = msg.estimator_horizontal;
    }
    else {
      resolved.estimator_horizontal = ''
    }

    if (msg.estimator_vertical !== undefined) {
      resolved.estimator_vertical = msg.estimator_vertical;
    }
    else {
      resolved.estimator_vertical = ''
    }

    if (msg.estimator_heading !== undefined) {
      resolved.estimator_heading = msg.estimator_heading;
    }
    else {
      resolved.estimator_heading = ''
    }

    if (msg.estimator_agl_height !== undefined) {
      resolved.estimator_agl_height = msg.estimator_agl_height;
    }
    else {
      resolved.estimator_agl_height = ''
    }

    if (msg.estimation_rate !== undefined) {
      resolved.estimation_rate = msg.estimation_rate;
    }
    else {
      resolved.estimation_rate = 0
    }

    if (msg.estimator_iteration !== undefined) {
      resolved.estimator_iteration = msg.estimator_iteration;
    }
    else {
      resolved.estimator_iteration = 0
    }

    if (msg.running_state_estimators !== undefined) {
      resolved.running_state_estimators = msg.running_state_estimators;
    }
    else {
      resolved.running_state_estimators = []
    }

    if (msg.switchable_state_estimators !== undefined) {
      resolved.switchable_state_estimators = msg.switchable_state_estimators;
    }
    else {
      resolved.switchable_state_estimators = []
    }

    if (msg.platform_config !== undefined) {
      resolved.platform_config = msg.platform_config;
    }
    else {
      resolved.platform_config = ''
    }

    if (msg.custom_config !== undefined) {
      resolved.custom_config = msg.custom_config;
    }
    else {
      resolved.custom_config = ''
    }

    return resolved;
    }
};

module.exports = EstimationDiagnostics;
