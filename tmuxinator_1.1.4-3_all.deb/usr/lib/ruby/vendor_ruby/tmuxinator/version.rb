module Tmuxinator
  VERSION = "1.1.4".freeze
end
