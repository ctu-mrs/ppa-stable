
"use strict";

let UavDiagnostics = require('./UavDiagnostics.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FuturePoint = require('./FuturePoint.js');
let GimbalState = require('./GimbalState.js');
let RtkFixType = require('./RtkFixType.js');
let GpsData = require('./GpsData.js');
let RtkGps = require('./RtkGps.js');
let GpsInfo = require('./GpsInfo.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let EulerAngles = require('./EulerAngles.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let PathReference = require('./PathReference.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let TrackerStatus = require('./TrackerStatus.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let ControlError = require('./ControlError.js');
let VelocityReference = require('./VelocityReference.js');
let TrackerCommand = require('./TrackerCommand.js');
let UavState = require('./UavState.js');
let EstimatorInput = require('./EstimatorInput.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let ReferenceArray = require('./ReferenceArray.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let ControllerStatus = require('./ControllerStatus.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let Reference = require('./Reference.js');
let CustomTopic = require('./CustomTopic.js');
let UavStatusShort = require('./UavStatusShort.js');
let UavStatus = require('./UavStatus.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let Se3Gains = require('./Se3Gains.js');
let Path = require('./Path.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let Histogram = require('./Histogram.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let Sphere = require('./Sphere.js');
let RangeWithCovarianceArrayStamped = require('./RangeWithCovarianceArrayStamped.js');
let Float64Stamped = require('./Float64Stamped.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let StringStamped = require('./StringStamped.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let Track = require('./Track.js');
let RangeWithCovarianceIdentified = require('./RangeWithCovarianceIdentified.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let ImageLabeled = require('./ImageLabeled.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let Float64 = require('./Float64.js');
let TrackStamped = require('./TrackStamped.js');
let BoolStamped = require('./BoolStamped.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');
let HwApiStatus = require('./HwApiStatus.js');

module.exports = {
  UavDiagnostics: UavDiagnostics,
  FutureTrajectory: FutureTrajectory,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  MpcPredictionFullState: MpcPredictionFullState,
  FuturePoint: FuturePoint,
  GimbalState: GimbalState,
  RtkFixType: RtkFixType,
  GpsData: GpsData,
  RtkGps: RtkGps,
  GpsInfo: GpsInfo,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  EulerAngles: EulerAngles,
  EstimationDiagnostics: EstimationDiagnostics,
  TrajectoryReference: TrajectoryReference,
  EstimatorOutput: EstimatorOutput,
  PathReference: PathReference,
  VelocityReferenceStamped: VelocityReferenceStamped,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  GainManagerDiagnostics: GainManagerDiagnostics,
  TrackerStatus: TrackerStatus,
  EstimatorCorrection: EstimatorCorrection,
  EstimatorDiagnostics: EstimatorDiagnostics,
  ControlError: ControlError,
  VelocityReference: VelocityReference,
  TrackerCommand: TrackerCommand,
  UavState: UavState,
  EstimatorInput: EstimatorInput,
  DynamicsConstraints: DynamicsConstraints,
  ReferenceArray: ReferenceArray,
  ReferenceStamped: ReferenceStamped,
  ControllerStatus: ControllerStatus,
  ControllerDiagnostics: ControllerDiagnostics,
  UavManagerDiagnostics: UavManagerDiagnostics,
  Reference: Reference,
  CustomTopic: CustomTopic,
  UavStatusShort: UavStatusShort,
  UavStatus: UavStatus,
  NodeCpuLoad: NodeCpuLoad,
  Se3Gains: Se3Gains,
  Path: Path,
  ReferenceWithVelocity: ReferenceWithVelocity,
  PathWithVelocity: PathWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  ObstacleSectors: ObstacleSectors,
  Histogram: Histogram,
  SpeedTrackerCommand: SpeedTrackerCommand,
  Sphere: Sphere,
  RangeWithCovarianceArrayStamped: RangeWithCovarianceArrayStamped,
  Float64Stamped: Float64Stamped,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  StringStamped: StringStamped,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  Track: Track,
  RangeWithCovarianceIdentified: RangeWithCovarianceIdentified,
  Float64ArrayStamped: Float64ArrayStamped,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  ImageLabeled: ImageLabeled,
  TrackArrayStamped: TrackArrayStamped,
  ImageLabeledArray: ImageLabeledArray,
  Float64: Float64,
  TrackStamped: TrackStamped,
  BoolStamped: BoolStamped,
  UInt16Stamped: UInt16Stamped,
  HwApiAltitude: HwApiAltitude,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
  HwApiRcChannels: HwApiRcChannels,
  HwApiCapabilities: HwApiCapabilities,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
  HwApiStatus: HwApiStatus,
};
