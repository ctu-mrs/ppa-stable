// Auto-generated. Do not edit!

// (in-package nimbro_topic_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ReceiverStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.node = null;
      this.protocol = null;
      this.label = null;
      this.host = null;
      this.remote = null;
      this.local_port = null;
      this.remote_port = null;
      this.fec = null;
      this.bandwidth = null;
      this.drop_rate = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('node')) {
        this.node = initObj.node
      }
      else {
        this.node = '';
      }
      if (initObj.hasOwnProperty('protocol')) {
        this.protocol = initObj.protocol
      }
      else {
        this.protocol = '';
      }
      if (initObj.hasOwnProperty('label')) {
        this.label = initObj.label
      }
      else {
        this.label = '';
      }
      if (initObj.hasOwnProperty('host')) {
        this.host = initObj.host
      }
      else {
        this.host = '';
      }
      if (initObj.hasOwnProperty('remote')) {
        this.remote = initObj.remote
      }
      else {
        this.remote = '';
      }
      if (initObj.hasOwnProperty('local_port')) {
        this.local_port = initObj.local_port
      }
      else {
        this.local_port = 0;
      }
      if (initObj.hasOwnProperty('remote_port')) {
        this.remote_port = initObj.remote_port
      }
      else {
        this.remote_port = 0;
      }
      if (initObj.hasOwnProperty('fec')) {
        this.fec = initObj.fec
      }
      else {
        this.fec = false;
      }
      if (initObj.hasOwnProperty('bandwidth')) {
        this.bandwidth = initObj.bandwidth
      }
      else {
        this.bandwidth = 0.0;
      }
      if (initObj.hasOwnProperty('drop_rate')) {
        this.drop_rate = initObj.drop_rate
      }
      else {
        this.drop_rate = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ReceiverStats
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [node]
    bufferOffset = _serializer.string(obj.node, buffer, bufferOffset);
    // Serialize message field [protocol]
    bufferOffset = _serializer.string(obj.protocol, buffer, bufferOffset);
    // Serialize message field [label]
    bufferOffset = _serializer.string(obj.label, buffer, bufferOffset);
    // Serialize message field [host]
    bufferOffset = _serializer.string(obj.host, buffer, bufferOffset);
    // Serialize message field [remote]
    bufferOffset = _serializer.string(obj.remote, buffer, bufferOffset);
    // Serialize message field [local_port]
    bufferOffset = _serializer.uint16(obj.local_port, buffer, bufferOffset);
    // Serialize message field [remote_port]
    bufferOffset = _serializer.uint16(obj.remote_port, buffer, bufferOffset);
    // Serialize message field [fec]
    bufferOffset = _serializer.bool(obj.fec, buffer, bufferOffset);
    // Serialize message field [bandwidth]
    bufferOffset = _serializer.float32(obj.bandwidth, buffer, bufferOffset);
    // Serialize message field [drop_rate]
    bufferOffset = _serializer.float32(obj.drop_rate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ReceiverStats
    let len;
    let data = new ReceiverStats(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [node]
    data.node = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [protocol]
    data.protocol = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [label]
    data.label = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [host]
    data.host = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [remote]
    data.remote = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [local_port]
    data.local_port = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [remote_port]
    data.remote_port = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [fec]
    data.fec = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [bandwidth]
    data.bandwidth = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [drop_rate]
    data.drop_rate = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.node);
    length += _getByteLength(object.protocol);
    length += _getByteLength(object.label);
    length += _getByteLength(object.host);
    length += _getByteLength(object.remote);
    return length + 33;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_topic_transport/ReceiverStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c542f1d59c474dba7ffccf1c3fa1ceab';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    
    # Node name
    string node
    
    # Protocol ("TCP" or "UDP")
    string protocol
    
    # Connection label
    string label
    
    # Local hostname
    string host
    
    # Remote hostname (if resolvable, otherwise IP)
    string remote
    
    # Port
    uint16 local_port
    
    # Port
    uint16 remote_port
    
    # is Forward Error Correction enabled?
    bool fec
    
    # Bandwidth in bit/s
    float32 bandwidth
    
    # Drop rate (estimated, percentage of missing packets in a fixed time interval)
    float32 drop_rate
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ReceiverStats(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.node !== undefined) {
      resolved.node = msg.node;
    }
    else {
      resolved.node = ''
    }

    if (msg.protocol !== undefined) {
      resolved.protocol = msg.protocol;
    }
    else {
      resolved.protocol = ''
    }

    if (msg.label !== undefined) {
      resolved.label = msg.label;
    }
    else {
      resolved.label = ''
    }

    if (msg.host !== undefined) {
      resolved.host = msg.host;
    }
    else {
      resolved.host = ''
    }

    if (msg.remote !== undefined) {
      resolved.remote = msg.remote;
    }
    else {
      resolved.remote = ''
    }

    if (msg.local_port !== undefined) {
      resolved.local_port = msg.local_port;
    }
    else {
      resolved.local_port = 0
    }

    if (msg.remote_port !== undefined) {
      resolved.remote_port = msg.remote_port;
    }
    else {
      resolved.remote_port = 0
    }

    if (msg.fec !== undefined) {
      resolved.fec = msg.fec;
    }
    else {
      resolved.fec = false
    }

    if (msg.bandwidth !== undefined) {
      resolved.bandwidth = msg.bandwidth;
    }
    else {
      resolved.bandwidth = 0.0
    }

    if (msg.drop_rate !== undefined) {
      resolved.drop_rate = msg.drop_rate;
    }
    else {
      resolved.drop_rate = 0.0
    }

    return resolved;
    }
};

module.exports = ReceiverStats;
