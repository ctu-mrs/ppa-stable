# - Config file for the OpticalFlow package
# It defines the following variables
#  OpticalFlow_INCLUDE_DIRS - include directories
#  OpticalFlow_LIBRARIES    - libraries to link against
 
set(OpticalFlow_INCLUDE_DIRS "/opt/ros/noetic/include")
#set(OpticalFlow_LIBRARY_DIR "/opt/ros/noetic/lib")
FIND_LIBRARY(OpticalFlow_LIBRARIES OpticalFlow PATHS "/opt/ros/noetic/lib" NO_DEFAULT_PATH)
