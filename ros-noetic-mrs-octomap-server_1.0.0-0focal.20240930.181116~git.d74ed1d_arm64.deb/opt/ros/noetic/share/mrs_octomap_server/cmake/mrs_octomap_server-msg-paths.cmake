# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_octomap_server_DIR}/.." "msg" mrs_octomap_server_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_octomap_server_MSG_DEPENDENCIES std_msgs;geometry_msgs)
