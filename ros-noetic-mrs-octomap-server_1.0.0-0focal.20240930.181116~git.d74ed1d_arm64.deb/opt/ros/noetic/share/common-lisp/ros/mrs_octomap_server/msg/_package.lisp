(cl:defpackage mrs_octomap_server-msg
  (:use )
  (:export
   "<POSEWITHSIZE>"
   "POSEWITHSIZE"
  ))

