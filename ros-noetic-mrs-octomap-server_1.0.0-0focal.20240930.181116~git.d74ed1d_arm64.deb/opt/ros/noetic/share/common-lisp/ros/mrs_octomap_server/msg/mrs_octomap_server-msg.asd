
(cl:in-package :asdf)

(defsystem "mrs_octomap_server-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "PoseWithSize" :depends-on ("_package_PoseWithSize"))
    (:file "_package_PoseWithSize" :depends-on ("_package"))
  ))